IP = "https://www.jkjrj.com";//正式环境
PORT = ":443";//正式环境
//IP = "http://60.191.5.133";//测试环境
//PORT = ":82";//测试环境
IFS_URL = IP + PORT + "/WAserver/";

var loadi; // 等待层

//var baseUrl = "http://192.168.1.105:8080/usermanager/";
//var baseUrl = "http://zhu.hunme.net:8080/";
//var baseUrl = "http://slb.openhunme.com/";
var baseUrl = "http://slave.openhunme.com/";
//var baseUrl = "http://master.openhunme.com/";

bankClassMap = {1001:"icbc",1002 :"abc",1004:"ccb",1012:"psbc",1011:"cmb",1009:"gdb",
    1007:"cebb",1008:"cmbc",1010:"cib",1000:"psbc", 1003: "boc", 1006: "ecitic", 1012 :"cib", 1013 : "pingan"};


/**
 *
 *保存 营业员编号
 */
function getPno(){

    TF.Dialog.cfg.btn = ["确定"];
    TF.Dialog.show();
    var oBtn = $(".kDlgBtn>a");
    $(TF.Dialog.cfg.box)
        .html(
            '<div class="panel">'+
            '	<div class="item">'+
            '		<span class="title">营业员编号</span>'+
            '		<input type="tel" class="txt_m Jpno" value="" maxlength="16" placeholder="请输入营业员编号(默认s999)" />'+
            '	</div>'+
            '</div">'
    );
    oBtn.eq(0).click(function(){
        var name = $(".Jpno").val();
        if(name && name.Trim() != "" && name.Trim().length <= 16 && name.Trim().length >= 3) {
            $.cookie("pno", name.Trim());
        } else {
            if(name && name.Trim() != "") {
                alertError("营业员编号3-16位");
            } else {
                $.cookie("pno", "s999");
            }
        }
        showPno();
        TF.Dialog.hide();
    });
}

function showPno() {

    var pno = $.cookie("pno");
    if(!pno || pno.Trim() == "") {
        pno = "s999";
        $.cookie("pno", pno);
    }
    $(".Jpno_name").html("营业员编号：" + pno);
    $(".Jpno_del").show();
    return true;

}

function delPno(){
    $.cookie("pno",  "", { expires: -1 });
    getPno();
}

/**
 *
 * @param type 0 不显示默认营业员
 */
function toIndex(){
    var indexUrl = $.cookie("indexUrl");
    window.location.href= indexUrl;
}

/**
 * 获取渠道号
 */
function getChannelNo(){

    var channelNo = getUrlParam("channelNo");
    if(channelNo && channelNo.Trim() != "") {
        $.cookie("channelNo", channelNo);
        return channelNo;
    } else {
        alertError("链接请加上渠道号参数[channelNo]!");
    }
    return false;

}

function getPhoneId(){

    var phoneId = getUrlParam("phoneId");
    if(phoneId && phoneId.Trim() != "") {
        $.cookie("phoneId", phoneId);
        return phoneId;
    } else {
        alertError("链接请加上机型编号[phoneId]!");
    }
    return false;

}

/**
 * 保存用户信息
 */
function saveUserInfo(client_id){
    if(client_id && client_id != ""){
        $.cookie("client_id", client_id);
    }

}

/**
 * 删除用户信息
 */
function deleteInfo(){

    $.cookie("tno",  "", { expires: -1 });
    $.cookie("freeze",  "", { expires: -1 });
    $.cookie("phoneId",  "", { expires: -1 });

}

String.prototype.Trim = function(){
    return this.replace(/(^\s*)|(\s*$)/g, "");
};


function getUrlParam(name){
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    //if (r!=null) return unescape(r[2]); return null;
    if (r!=null) return decodeURI(r[2]); return null;
}

function showRight(e, msg){
    e.html(msg);
    var img = e.parent().children()[0];
    img.alt = "right";
    img.src = "../img/zero/right.png";
    e.parent().css("visibility","visible");
}

function showError(e, msg){
    e.html(msg);
    var img = e.parent().children()[0];
    img.alt = "error";
    img.src = "../img/zero/error.png";
    e.parent().css("visibility","visible");
}

function hiddenError(e){
    e.html("");
    e.parent().css("visibility","hidden");
}

function alertError(msg) {
    TF.Loading.hide();
    TF.Bubble.show(msg);
}



function ajax(url, data, success, error, cache, type){
    var rurl = url + "?" + new Date().getTime();
    if(cache) {
        rurl = url;
    }
    $.ajax({
        url: rurl,
        data: data,
        success: success,
        type: type || 'post',
        dataType: "json",
        error: error || function() {
            alertError(url +"调用失败");
        }
    });
}
function post(url, data, success, error, cache){
    ajax(url, data, success, error, cache);
}

function get(url, data, success, error, cache){
    ajax(url, data, success, error, cache, "get");
}

function ifs_gc(fno, data, success, error){
    var url = IFS_URL + fno;
    post(url, data, success, error, true, "get");
}

/**
 * ifs 调用
 * @param fno
 * @param data
 * @param succes
 * @param error
 */
function ifs(fno, data, success, error){
    var url = IFS_URL + fno;
    post(url, data, success, error);
}


function ifs_c(fno, data, success, error){
    var url = IFS_URL + fno;
    post(url, data, success, error, true);
}

/**
 * 登录
 * @param mobile_tel
 * @param password
 * @param succes
 * @param error
 */
function login(mobile_tel, password, succes, error){
    var input_content;
    if(mobile_tel && mobile_tel.length == 11) {
        input_content = 'b'; //手机号
    } else {
        input_content = 6; //客户号
    }

    $.ajax({
        url: IFS_URL + "s/json/HS831000?" + new Date().getTime(),
        data: { account_content :mobile_tel, input_content : input_content,
            password : password},
        success: succes,
        type: 'post',
        dataType: "json",
        error:  error || function() {
            alertError("登录调用失败");
        }
    });



}


/**
 * 通过身份证判断是男是女
 * @param idCard 15/18位身份证号码
 * @return 'female'-女、'male'-男
 */
function maleOrFemalByIdCard(idCard){
    idCard = idCard.replace(/ /g, "").Trim();        // 对身份证号码做处理。包括字符间有空格。
    if(idCard.length==15){
        if(idCard.substring(14,15)%2==0){
            return 'F';
        }else{
            return 'M';
        }
    }else if(idCard.length ==18){
        if(idCard.substring(14,17)%2==0){
            return 'F';
        }else{
            return 'M';
        }
    }else{
        return null;
    }
}

/**
 * 身份证验证
 * @param num
 * @returns {boolean}
 */
function checkIdcard(num){

    var bdate; // 生日

    num = num.toUpperCase();
    //身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X。
    if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(num)))
    {
        //alert('输入的身份证号长度不对，或者号码不符合规定！\n15位号码应全为数字，18位号码末位可以为数字或X。');
        return false;
    }
    //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
    //下面分别分析出生日期和校验位
    var len, re;
    len = num.length;
    if (len == 15)
    {
        re = new RegExp(/^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/);
        var arrSplit = num.match(re);
        //检查生日日期是否正确
        var dtmBirth = new Date('19' + arrSplit[2] + '/' + arrSplit[3] + '/' + arrSplit[4]);
        var bGoodDay;
        bGoodDay = (dtmBirth.getYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
        if (!bGoodDay){
            //alert('输入的身份证号里出生日期不对！');
            return false;
        } else{

            bdate = '19' + arrSplit[2]  + arrSplit[3]  + arrSplit[4];


            //将15位身份证转成18位
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
            var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
            var nTemp = 0, i;
            num = num.substr(0, 6) + '19' + num.substr(6, num.length - 6);
            for(i = 0; i < 17; i ++)
            {
                nTemp += num.substr(i, 1) * arrInt[i];
            }
            num += arrCh[nTemp % 11];
            return bdate;
        }
    }
    if (len == 18)
    {
        re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
        var arrSplit = num.match(re);

        //检查生日日期是否正确
        var dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
        var bGoodDay;
        bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
        if (!bGoodDay)
        {
            //alert(dtmBirth.getYear());
            //alert(arrSplit[2]);
            //alert('输入的身份证号里出生日期不对！');
            return false;
        }
        else
        {
            bdate = arrSplit[2] + arrSplit[3] + arrSplit[4];

            //检验18位身份证的校验码是否正确。
            //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
            var valnum;
            var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
            var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
            var nTemp = 0, i;
            for(i = 0; i < 17; i ++)
            {
                nTemp += num.substr(i, 1) * arrInt[i];
            }
            valnum = arrCh[nTemp % 11];
            if (valnum != num.substr(17, 1))
            {
                //alert('18位身份证的校验码不正确！应该为：' + valnum);
                return false;
            }
            return bdate;
        }
    }
    return false;
}


function jsGetAge(strBirthday){
    var returnAge;
    var birthYear = strBirthday.substr(0,4);
    var birthMonth = strBirthday.substr(4,2);
    var birthDay = strBirthday.substr(6,8);

    d = new Date();
    var nowYear = d.getFullYear();
    var nowMonth = d.getMonth() + 1;
    var nowDay = d.getDate();

    if(nowYear == birthYear)
    {
        returnAge = 0;//同年 则为0岁
    }
    else
    {
        var ageDiff = nowYear - birthYear ; //年之差
        if(ageDiff > 0)
        {
            if(nowMonth == birthMonth)
            {
                var dayDiff = nowDay - birthDay;//日之差
                if(dayDiff < 0)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff ;
                }
            }
            else
            {
                var monthDiff = nowMonth - birthMonth;//月之差
                if(monthDiff < 0)
                {
                    returnAge = ageDiff - 1;
                }
                else
                {
                    returnAge = ageDiff ;
                }
            }
        }
        else
        {
            returnAge = -1;//返回-1 表示出生日期输入错误 晚于今天
        }
    }

    return returnAge;//返回周岁年龄

}
