var CLIENT_ID;var FUND_ACCOUNT;var CLIENT_NAME;var ID_NO;var ID_KIND;var MOBILE_TEL;var ADDRESS;var FULL_NAME;var CCID;
(function($){
	CLIENT_ID= $.cookie("client_id");
    ifs("s/json/HS831003",{ client_id :CLIENT_ID },function(clientinfo){
           // alert(JSON.stringify(clientinfo)+'aaaaaaaaaaaaaa');
           // alert(CLIENT_ID+'CLIENT_IDCLIENT_ID');
            if(clientinfo.error_no == 0) {
                CCID = clientinfo.client_id;
                FUND_ACCOUNT=clientinfo.fund_account;
                CLIENT_NAME=clientinfo.client_name;
                ID_NO=clientinfo.id_no;
                ID_KIND=clientinfo.id_kind;
                MOBILE_TEL=clientinfo.mobile_tel;
                ADDRESS = clientinfo.address;
                FULL_NAME = clientinfo.full_name;
                if( typeof getUserInfoSuccess === 'function') {
                    getUserInfoSuccess();
                }
            } else {
                if(typeof getUserInfoFail=== 'function') {
                    getUserInfoFail();
                } else {
                    alertError(clientinfo.error_info+'!=0');
                }
            }
        }, function() {
            alertError("查询用户信息失败");
        }
    );   
})(jQuery);
