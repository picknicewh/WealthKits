/**
 * Created by wang on 2015-11-20.
 */
define(['angular', 'store'], function (angular, store) {
    "use strict";

    var factory = function ($location, $http, $q, WT_BASE_PATH, WZ_BASE_PATH, CommonService, LocalCacheService) {

        return {

            saveUserInfo:function(){
                console.log(LocalCacheService);
            },
            getCurrentOpenUser: function () { //获取当前开户用户
                var params = {};
                params.url = "/open/get_open_user";
                params.isReject = true; //是否会覆盖错误提示 默认是弹窗
                params.type = "get";
                return CommonService.ajax(params);
            },
            sendCheckCode : function(data){
                data.op_station = LocalCacheService.get("op_station");
                var params = {};
                params.isReject = true;
                params.url="/open/send_check_code";
                params.data=data;
                return CommonService.ajax(params);
            },
            checkMobileCode : function(data){
                var params = {};
                params.isReject = true;
                params.url="/open/check_mobile_code";
                params.data=data;
                return CommonService.ajax(params);
            },
            msgVerify : function(data){
                var params = {};
                params.isReject = true;
                params.url="/open/msg_verify";
                params.data=data;
                return CommonService.ajax(params);
            },
            selectBranch : function(data){
                var params = {};
                params.url="/open/select_branch";
                params.data=data;
                return CommonService.ajax(params);
            },
            uploadID : function(data){
                var params = {};
                params.url="/open/upload_ID";
                params.isReject = true;
                params.data=data;
                return CommonService.ajax(params);
            },
            open : function(data){
                var params = {};
                params.url="/open/open";
                params.data=data;
                params.isReject = true;
                return CommonService.ajax(params);
            },
            certInstall : function(){
                var params = {};
                params.isReject = true;
                params.url="/open/zj_install";
                params.data={source:CommonService.getSource()};
                return CommonService.ajax(params);
            },
            openSubmitPaper : function(data){
                var params = {};
                params.url="/open/submit_paper";
                params.data = data;
                return CommonService.ajax(params);
            },
            setPwd : function(data){
                var params = {};
                params.url="/open/set_pwd";
                params.data=data;
                return CommonService.ajax(params);
            },
            openBankAccount : function(data){
                var params = {};
                params.isReject = true;
                params.url="/open/open_bank_account";
                params.data = data;
                return CommonService.ajax(params);
            },
            saveEcontract : function(){
                var params = {};
                params.url="/open/save_econtract";
                params.data={source:CommonService.getSource()};
                return CommonService.ajax(params);
            },
            qryRevisitPaper : function(){
                var params = {};
                params.url="/open/revisit_paper";
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            submitRevisitPaper : function(data){
                var params = {};
                params.url="/open/submit_revisit_paper";
                params.data=data;
                return CommonService.ajax(params);
            },
            qryOpenResult : function(){
                var params = {};
                params.url="/open/qry_open_result";
                return CommonService.ajax(params);
            },
            open0 : function(data){
                var params = {};
                params.url="/open/open0";
                params.data=data;
                return CommonService.ajax(params);
            },
            checkIdNo : function(data){
                var params = {};
                params.url="/open/check_id_no";
                params.data=data;
                return CommonService.ajax(params);
            },

            querySellInfo : function(prod_code){
                var params = {};
                params.url = "/common/prod/qry_secum";
                params.data =  {prod_code:prod_code};
                params.type = "get";
                return CommonService.ajax(params);
            },
            queryIFSProdInfo : function(prodCode,prodSource){
                var params = {};
                if(prodSource=='0'){
                    params.data={prod_code:prodCode};
                    params.url="/common/prod/qry_bankm";
                }else if(prodSource=='1'){
                    params.data={prod_code:prodCode};
                    params.url="/common/prod/qry_trade";
                }else if(prodSource=='2'){
                    params.data={fund_code:prodCode};
                    params.url="/common/prod/qry_uf";
                }
                params.type = "get";
                return CommonService.ajax(params);
            },
            getEncontractList : function(econtract_type) {
                var params = {};
                params.url = "/common/encontract/list";
                params.type = "get";
                params.data = {econtract_type : econtract_type};
                params.cache = true;
                return CommonService.ajax(params);
            },
            getEncontract : function(id) {
                var params = {};
                params.url = "/common/encontract/content/" + id;
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            qryDjTa : function(){
                var params = {};
                params.url="/common/fund/qry_dj_ta";
                params.type = "get";
                return CommonService.ajax(params);
            },
            getRiskPaper : function(){
                var params = {};
                params.url="/common/risk_paper";
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },

            qeyAllPayBank : function(){
                var params = {};
                params.url="/boss/qry_pay_banks";
                params.data={conduit_no:LocalCacheService.getRecommendInfos()};
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            qryAllDepositBank : function(){
                var params = {};
                params.url="/boss/qry_deposit_banks";
                params.data={conduit_no:LocalCacheService.getRecommendInfos()};
                params.cache = true;
                params.type = "get";
                return CommonService.ajax(params);
            },
            qryProdWhite : function(){
                var params = {};
                params.url="/boss/check_prod_white";
                params.data={source_id:LocalCacheService.get("UUID")};
                params.cache = true;
                params.type = "get";
                return CommonService.ajax(params);
            },
            qryBranch : function(){
                var params = {};
                params.url="/boss/qry_branch";
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            qryProvince : function(){
                var params = {};
                params.url="/boss/qry_province";
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            qryDictInfo : function(data){
                var params = {};
                params.url="/boss/qry_dict_info";
                params.data=data;
                params.type = "get";
                return CommonService.ajax(params);
            },
            qryConduitInfo : function(data){
                var params = {};
                params.url="/boss/qry_conduit_info";
                params.data=data;
                params.type = "get";
                return CommonService.ajax(params);
            },
            qryBindConduitInfo : function(data){
                var params = {};
                params.url="/boss/qry_bind_conduit";
                params.data=data;
                params.type = "get";
                return CommonService.ajax(params);
            },
            getNotice : function(type){
                var params = {};
                params.url = "/boss/get_notice";
                params.styleType = 1;
                params.data =  {type : type};
                params.type = "get";
                return CommonService.ajax(params);
            },
            activate : function(data){
                var params = {};
                params.url = "/boss/activate";
                params.data =  data;
                return CommonService.ajax(params);
            },
            channelStep : function(step){
                var params = {};
                params.url="/boss/get_channel_step";
                params.data={conduit_no: LocalCacheService.getRecommendInfos(),source: CommonService.getSource(),step: step};
                return CommonService.ajax(params);
            },
            openActChannelInfo : function(){
                var params = {};
                params.url = "/boss/get_channel_info";
                params.data =  {conduit_no: LocalCacheService.getRecommendInfos(), source: CommonService.getSource()};
                params.type = "get";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            getChannelPaper : function(prodCode, entrust_balance){
                var params = {};
                params.url = "/boss/get_channel_info";
                params.type = "get";
                params.isReject = true;
                params.data = {conduit_no:LocalCacheService.getRecommendInfos(),source:CommonService.getSource(),
                    product_no:prodCode,entrust_balance:entrust_balance};
                params.cache = true;
                return CommonService.ajax(params);
            },
            qryChannelRiskPaper : function(data){
                var params = {};
                params.url="/boss/channel_risk_paper";
                params.data=data;
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            submitChannelRiskPaper : function(data){
                var params = {};
                params.url="/boss/submit_channel_risk_paper";
                params.data=data;
                return CommonService.ajax(params);
            },

            login : function(data){
                var params = {};
                data.op_station = LocalCacheService.get("op_station");
                console.log(data.op_station+':::data.op_station');
                params.url = "/trade/user/login";
                params.styleType = 1;
                params.data = data;
                return CommonService.ajax(params);
            },
            login2 : function(data){
                var params = {};
                data.op_station = LocalCacheService.get("op_station");
//                console.log(data.op_station+':::data.op_station');
                params.url = "/trade/user/login";
                params.styleType = 1;
                params.data = data;
                return CommonService.ajax(params);
            },
            logout : function(){
                var params = {};
                params.url="/trade/user/logout";
                return CommonService.ajax(params);
            },
            getUserInfo : function(){
                var params = {};
                params.url = "/trade/user/get_user";
                params.isReject = true; //是否会覆盖错误提示 默认是弹窗
                params.type = "get";
                return CommonService.ajax(params);
            },
            syncUserCare : function(){
                var params = {};
                params.url = "/trade/user/sync_user_care";
                return CommonService.ajax(params);
            },
            modifyUserInfo : function(profession_code, degree_code){
                var params = {};
                params.url="/trade/user/modify_user_info";
                params.styleType = 1;
                params.data = {profession_code: profession_code,degree_code: degree_code};
                return CommonService.ajax(params);
            },
            modifyPwd : function(new_pwd, old_pwd, pwd_type){
                var params = {};
                params.isReject = true;
                params.url= "/trade/user/modify_pwd";
                params.styleType = 1;
                params.data = {password:new_pwd,password_old: old_pwd,password_type: pwd_type};
                return CommonService.ajax(params);
            },
            checkMobile : function(mobile_tel){
                var params = {};
                params.type = "get";
                params.isReject = true;
                params.url="/trade/user/check_mobile";
                params.data = {mobile_tel: mobile_tel};
                return CommonService.ajax(params);
            },
            modifyMobile : function(new_mobile_tel, check_code, password){
                var params = {};
                params.styleType = 1;
                params.url="/trade/user/modify_mobile";
                params.data = {new_mobile_tel:new_mobile_tel,check_code: check_code,password: password};
                return CommonService.ajax(params);
            },
            submitPaper : function(data){
                var params = {};
                params.url="/trade/user/submit_paper";
                params.data = data;
                return CommonService.ajax(params);
            },

            queryTotalIncome : function(){
                var params = {};
                params.url="/trade/account/total_income";
                return CommonService.ajax(params);
            },
            getAllShares : function(){
                var params = {};
                params.url="/trade/account/total_shares";
                return CommonService.ajax(params);
            },
            getBankByTransAccount : function(trans_account){
                var params = {};
                params.url="/trade/account/get_bank_by_transAccount";
                params.data={trans_account: trans_account};
                return CommonService.ajax(params);
            },
            queryCurOrders : function(){
                var params = {};
                params.url="/trade/account/total_current_orders";
                params.type = "get";
                return CommonService.ajax(params);
            },
            queryHisOrders : function(){
                var params = {};
                params.url="/trade/account/total_history_orders";
                params.type = "get";
                return CommonService.ajax(params);
            },
            queryOrdersByProd : function(prod_code, prod_source, trans_account){
                var params = {};
                params.data = {prod_code: prod_code, prod_source: prod_source, trans_account:trans_account};
                params.url="/trade/account/total_prod_orders";
                params.type = "get";
                return CommonService.ajax(params);
            },
            getOrderDetail : function(allotNo, prodSource, isCurrent){
                var params = {};
                params.url="/trade/account/order_detail";
                params.data={allot_no:allotNo,prod_source:prodSource,is_current:isCurrent};
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            queryBalance : function(){
                var params = {};
                params.url="/trade/account/balance";
                return CommonService.ajax(params);
            },
            getShares : function(prodSource, allotNo, prodCode){
                var params = {};
                if(prodSource=="1"){
                    params.url="/trade/account/shares";
                    params.data={allot_no:allotNo};
                }else if(prodSource=="2"){
                    params.url="/trade/account/uf_shares";
                    params.data={fund_code:prodCode};
                } else {
                    params.url="/trade/account/bankm_shares";
                    params.data={fund_code:allotNo};
                }
                return CommonService.ajax(params);
            },
            getOrders : function(prodSource, prodCode, trans_account){
                var params = {};
                if(prodSource=="1"){
                    params.url="/trade/account/orders";
                    params.data={current_sell:0, prod_code:prodCode, trans_account: trans_account};
                }else if(prodSource=="2"){
                    params.url="/trade/account/uf_orders";
                    params.data={current_sell:0, fund_code:prodCode};
                }
                params.type = "get";
                return CommonService.ajax(params);
            },

            getUserQuickBankCards : function(){
                var params = {};
                params.url = "/trade/bank/quick_bank_cards";
                params.type = "get";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            getUserDepositBankCards : function(){
                var params = {};
                params.url = "/trade/bank/deposit_bank_cards";
                params.type = "get";
                params.data = {conduit_no:LocalCacheService.getRecommendInfos()};
                params.isReject = true;
                params.cache = true;
                return CommonService.ajax(params);
            },
            unbindBank : function(bank_no, bank_account, password){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/unbind";
                params.data = {bank_no: bank_no, bank_account: bank_account, password: password};
                return CommonService.ajax(params);
            },
            checkPayStatus : function(entrust_balance){
                var params = {};
                params.url = "/trade/bank/check_pay_status";
                params.data = {balance:  entrust_balance};
                return CommonService.ajax(params);
            },
            bankTransfer : function(bank_password, occur_balance, bank_no){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/transfer";
                params.data = {bank_password: bank_password, occur_balance: occur_balance,
                    transfer_direction: "1", bank_no: bank_no};
                return CommonService.ajax(params);
            },
            bankWithdraw : function(fund_password, occur_balance, bank_no){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/transfer";
                params.data = {fund_password: fund_password, occur_balance: occur_balance,
                    transfer_direction:"2",bank_no: bank_no};
                return CommonService.ajax(params);
            },
            queryBankTransfer : function(co_serial_no, isCurrent){
                var params = {};
                params.url="/trade/bank/qry_bank_transfer";
                params.data={co_serial_no: co_serial_no, isCurrent : isCurrent};
                params.cache = true;
                return CommonService.ajax(params);
            },
            queryTransferDetails : function(){
                var params = {};
                params.url="/trade/bank/fund_jour";
                return CommonService.ajax(params);
            },
            queryBankBanlance : function(bank_password, bank_no){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/qry_banlance";
                params.data = {bank_password: bank_password ,money_type:"0",bank_no: bank_no};
                return CommonService.ajax(params);
            },
            reopenBankAccount : function(data){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/reopen_bank_account";
                params.data = data;
                return CommonService.ajax(params);
            },
            signBankMsg : function(data){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/sign";
                if('open' == data.from){
                    params.url="/open/bank_sign";
                }
                params.data = data;
                return CommonService.ajax(params);
            },
            signSuccess : function(data){
                var params = {};
                params.isReject = true;
                params.url="/trade/bank/signSuccess";
                if('open' == data.from){
                    params.url="/open/sign_success";
                }
                params.data = data;
                return CommonService.ajax(params);
            },

            buyDjProduct : function(prod_code, password, entrust_balance, pay_kind, bank_no,
                                    pay_account, prodta_no, prod_name, prod_begin_date){
                var params = {};
                params.data={password:password,entrust_balance:entrust_balance,pay_kind:pay_kind,bank_no:bank_no,
                    conduit_no : LocalCacheService.getRecommendInfos(),
                    pay_account:pay_account,prodta_no:prodta_no,prod_code:prod_code,prod_name:prod_name,
                    prod_begin_date:prod_begin_date};
                params.url="/trade/trade/subscribe";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            redeemDjProduct : function(prod_code, prodta_no, amount, allot_no, prod_name, bank_name, pay_account){
                var params = {};
                params.data={prod_code:prod_code,prodta_no:prodta_no,amount:amount,allot_no: allot_no, exceedflag:"1",
                    prod_name: prod_name, bank_name:bank_name,pay_account:pay_account,
                    conduit_no : LocalCacheService.getRecommendInfos()};
                params.url="/trade/trade/redeem";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            buyUfProduct : function(fund_code, fund_company, password, entrust_balance, charge_type,
                                    prod_name, prod_begin_date){
                var params = {};
                params.data={password:password,balance:entrust_balance,fund_company:fund_company,
                    fund_code:fund_code,charge_type:charge_type,prod_name: prod_name,
                    prod_begin_date:prod_begin_date};
                params.url="/trade/trade/uf_subscribe";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            redeemUfProduct : function(fund_code, fund_company, amount, prod_name){
                var params = {};
                params.data={fund_code:fund_code,fund_company:fund_company,amount:amount,exceedflag:"1",prod_name:prod_name};
                params.url="/trade/trade/uf_redeem";
                params.isReject = true;
                return CommonService.ajax(params);
            },
            buyBankProduct : function(prod_code, password, entrust_balance, pay_kind, bank_no,
                                       pay_account, prodta_no, prod_name, prod_begin_date){
                var params = {};
                params.data={password: password ,entrust_balance:entrust_balance,pay_kind:pay_kind,
                    bank_no:bank_no,pay_account:pay_account,prodta_no:prodta_no,prod_code:prod_code,
                    prod_name:prod_name,prod_begin_date:prod_begin_date};
                params.url="/trade/trade/bankm_subscribe";
                params.isReject = true;
                return CommonService.ajax(params);
            },

            wtAddAccessRecord : function(source_url, key, remark){
                var params = {};
                params.url="/web/conduit/addCrmAccessRecord";
                params.isReject = true;
                var mobile_tel = null;
                var user = LocalCacheService.getUser();
                if(user) {
                    mobile_tel = user.mobile_tel;
                }
                params.type = "get";
                params.data={conduit_no:LocalCacheService.getRecommendInfos(), mobile_tel: mobile_tel,
                    source_url: "tap#" + source_url, access_type:key, remark: remark};
                params.basePath = WT_BASE_PATH;
                return CommonService.ajax(params);
            },
            wtAd : function(ad_board_code){
                var params = {};
                params.url="/web/advertising/getAdListByCondition";
                params.isReject = true;
                params.type = "get";
                params.cache = true;
                var user = LocalCacheService.getUser();
                params.data={conduit_no:LocalCacheService.getRecommendInfos(), logged_in: user ? 'y' : 'n',
                    client_code : LocalCacheService.get("UUID"), ad_board_code : ad_board_code};
                params.basePath = WT_BASE_PATH;
                return CommonService.ajax(params);
            },
            wtAddClientOpinion : function(opinion_content, mobile_tel){
                var params = {};
                params.url="/web/subsidiary/saveClientOpinion";
                params.data={opinion_content : opinion_content, business_type: 'xcmtz'};
                var user = LocalCacheService.getUser();
                if(user) {
                    params.data.mobile_tel = user.mobile_tel;
                    params.data.client_name = user.client_name;
                    params.data.client_id = user.client_id;
                }
                if(mobile_tel){
                    params.data.mobile_tel = mobile_tel;
                }
                params.basePath = WT_BASE_PATH;
                return CommonService.ajax(params);
            },
            wzChannels : function(parentId){
                var params = {};
                params.url="searchChannelsByParentId.jspx?parentId=" + parentId;
                params.basePath = WZ_BASE_PATH;
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            wzContents : function(channelId,type){ //type 1 包含内容 0 不包含内容
                var params = {};
                params.url="searchContentsByChannelId.jspx?channelId=" + channelId + "&type=" + type;
                params.basePath = WZ_BASE_PATH;
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            },
            wzContent : function(contentId){
                var params = {};
                params.url="searchContentsById.jspx?id=" + contentId;
                params.basePath = WZ_BASE_PATH;
                params.type = "get";
                params.cache = true;
                return CommonService.ajax(params);
            }
        }
    };

    factory.$inject = ['$location', '$http', '$q','WT_BASE_PATH','WZ_BASE_PATH','CommonService', 'LocalCacheService'];
    return factory;
});