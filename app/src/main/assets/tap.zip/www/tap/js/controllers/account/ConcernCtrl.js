define(function () {
    'use strict';

    function ctrl($scope,ConcernService,CommonService,InfoService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            $scope.userCareFunds = new Array();
            $scope.otherFunds = new Array();

            //获取推荐关注列表
            othersCareList();
            //用户关注列表
            userCareList();
        }

        function userCareList(){
            var prodCodes= ConcernService.getConcernList();
            $scope.concernSize = prodCodes.length;
            if(prodCodes != "") {
                InfoService.getProdBriefs(prodCodes).then(
                    function(data){
                        if(data){
                            $scope.userCareFunds = data;
                            perfectFunds($scope.userCareFunds);
                        }
                    }
                );
            }
        }

        function othersCareList(){
            InfoService.getOthersCare().then(
                function(data){
                    if(data){
                        $scope.otherFunds = data;
                        perfectFunds( $scope.otherFunds);
                    }
                }
            );
        }

        $scope.unCare = function(prodCode){
            ConcernService.concern(prodCode);
            var list = $scope.userCareFunds;
            for(var i=0;i<list.length;i++){
                if(prodCode == list[i].prodCode){
                    list.splice(i,1);
                    $scope.concernSize = list.length;
                }
            }
        };

        function perfectFunds(funds){
            for(var i=0;i < funds.length; i++) {
                var fund = funds[i];
                //0 万份收益 1 单位净值 2 预期收益 3 券商资管
                if("0,3".indexOf(fund.prodProfitMode) > -1){
                    fund.url = "tab/product-item";
                }else if("1"==fund.prodProfitMode){
                    fund.url = "tab/product-item-QDII";
                }else if("2"==fund.prodProfitMode){
                    fund.url = "tab/product-item";
                    if("1"==fund.prodSource){
                        fund.url = "tab/product-item-otc";
                    }
                }else{
                    CommonService.showConfig({message: "产品收益模式未配置:" + fund.prodCode});
                }
            }
        }
    }

    ctrl.$inject = ['$scope','ConcernService','CommonService','InfoService'];
    return ctrl;
});