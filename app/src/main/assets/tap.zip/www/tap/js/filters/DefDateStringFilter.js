/**
 * Created by wang on 2015-9-22.
 * 日期转换显示
 */
define(['angular'], function (angular) {
    "use strict";

    var filter = function () {
        /**
         * 原值 转换类型 默认值
         * type = 1   yyyyMMdd   --> yyyy-MM-dd
         *
         */
        return function (date, type, def) {
            if (null == date || "" == date || "undefined" == typeof(date)) {
                return '--';
            } else {
                var show;
                if(type == 1 || (date && date.length == 8)) {
                    show = date.substr(0, 4) + "-" + date.substr(4, 2) + "-" + date.substr(6, 2);
                } else {
                    show = date.substr(0, 4) + "-" + date.substr(4, 2) + "-" + date.substr(6, 2) + " "
                        + date.substr(8, 2) + ":" + date.substr(10, 2) + ":" + date.substr(12, 2);

                }
                return show;
            }
        };
    };

    filter.$inject = [];
    return filter;
});