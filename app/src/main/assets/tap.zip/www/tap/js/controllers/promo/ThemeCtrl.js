define(function () {
    'use strict';

    function ctrl($scope, $filter, InfoService) {
        $scope.theme = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            InfoService.getProdBriefs($scope.theme.prodCodes).then(function(data){
                if(data){
                    $scope.funds = data;
                    for(var i=0;i<$scope.funds.length;i++){
                        var fund = $scope.funds[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$filter', 'InfoService'];
    return ctrl;
});