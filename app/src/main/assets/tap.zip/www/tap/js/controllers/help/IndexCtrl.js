define(function () {
    'use strict';

    function ctrl($scope, WebService, HELP_CHANNEL_ID) {

        init();

        $scope.doRefresh = function () {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init() {
            WebService.wzChannels(HELP_CHANNEL_ID).then(function (data) {
                $scope.items = data;
                if ($scope.items) {
                    WebService.wzContents($scope.items[0].id, 0).then(function (d) {
                        $scope.items[0].contents = d;
                    });
                }
            });
        }
    }

    ctrl.$inject = ['$scope', 'WebService', 'HELP_CHANNEL_ID'];
    return ctrl;
});