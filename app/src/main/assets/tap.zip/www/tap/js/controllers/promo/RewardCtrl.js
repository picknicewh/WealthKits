/**
 * Created by wang on 2015-10-28.
 */
define(function () {
    'use strict';

    function ctrl($scope,$state,LocalCacheService,CommonService,WebService) {

        var user = LocalCacheService.getUser();
        if(user){
            $scope.user = user;
        }

        $scope.next = function() {
            if ($scope.user) {
                WebService.openActChannelInfo().then(
                    function (data) {
                        if(data && data.paper_id) { //有活动
                            if (data.remaining_number > 0) {
                                $state.go("tab.product-index");
                            } else {
                                CommonService.showAlert({message: "您已参加过该活动，谢谢您的参与"});
                            }
                        } else {
                            CommonService.showAlert({message: "抱歉，本活动仅限于活动期间初次开户客户，且每个客户只能参加一次。"});
                        }
                    },
                    function (result) {
                        CommonService.showAlert({message: "抱歉，本活动仅限于活动期间初次开户客户，且每个客户只能参加一次。"});
                    }
                );
            } else{
                $state.go("open-prepare");
            }
        }
    }

    ctrl.$inject = ['$scope','$state','LocalCacheService','CommonService','WebService'];
    return ctrl;
});