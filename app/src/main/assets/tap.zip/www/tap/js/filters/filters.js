/*global define */

define(['angular', 'filters/InterpolateFilter','filters/DefNumberFilter','filters/ProdMinSubscribeFilter',
        'filters/DefStringFilter', 'filters/DefDateStringFilter','filters/BankAccountFilter', 'services/services'],
    function (angular, InterpolateFilter, DefNumberFilter, ProdMinSubscribeFilter, DefStringFilter, DefDateStringFilter, BankAccountFilter) {

        'use strict';
        var filters = angular.module('app.filters', ['app.services']);
        filters.filter('interpolate', InterpolateFilter);
        filters.filter('defNumber', DefNumberFilter);
        filters.filter('defString', DefStringFilter);
        filters.filter('defDateString', DefDateStringFilter);
        filters.filter('prodMinSubscribe', ProdMinSubscribeFilter);
        filters.filter('bankAccount', BankAccountFilter);
        return filters;
 
    });