/*global define, console */

define(['angular', 'require', 'base'], function (angular, require, base) {
    "use strict";

    var factory = function ($rootScope, $http,$ionicLoading, CommonService, LocalCacheService) {

        return {
            /**
             * 查询栏目
             */
            getChannelInfos : function(channel_ids){
                return _ajax("/funds/"+channel_ids+"/channels");
            },
            /**
             * 查询子栏目
             */
            getChildChannelInfos : function(channel_id){
                return _ajax("/funds/"+channel_id+"/child_channels");
            },
            /**
             * 查询广告
             */
            getAds : function(ad_ids){
                return _ajax("/funds/"+ad_ids+"/advertisings");
            },
            /**
             * 查询广告位
             */
            getAdSpace : function(adspace_id){
                return _ajax("/funds/"+adspace_id+"/child_advertisings");
            },
            /**
             * 批量产品概要 栏目ID查询
             */
            getContentBriefs:function(contentIds, qry_top){
                return _ajax("/funds/"+contentIds+"/" + qry_top +"/briefs");
            },
            /**
             * 批量产品概要 产品代码查询
             */
            getProdBriefs:function(prodCodes){
                return _ajax("/funds/"+prodCodes+"/prod_briefs");
            },
            /**
             * 查询批量OTC概况
             */
            getOTCBriefs:function(contentIds,qry_top){
                return _ajax("/funds/"+contentIds+"/" + qry_top + "/otc_briefs");
            },
            /**
             * 根据内容ID获取OTC产品概况
             */
            getOTCGeneral: function (contentId) {
                return _ajax("/funds/"+contentId+"/otc_general");
            },
            /**
             * 根据内容ID获取产品概况
             */
            getFundGeneral: function (contentId) {
                return _ajax("/funds/"+contentId+"/general");
            },
            /**
             * 查询OTC明细
             */
            getOTCDetail:function (contentId){
                return _ajax("/funds/"+contentId+"/otc_detail");
            },
            /**
             * 查询cms基金明细
             */
            getContentDetail:function (contentId){
                return _ajax("/funds/"+contentId+"/detail");
            },
            /**
             * 查询基金历史净值数据
             */
            getHistoryNav:function (code,count){
                return _ajax("/funds/"+code+"/history_nav",{count:count});
            },
            /**
             * 查询货基七日年化
             */
            getHistoryYield:function (code,count){
                return _ajax("/funds/"+code+"/history_yield",{count:count});
            },
            /**
             * 基金净值，沪深300指数历史数据
             */
            getComparisonData:function (code,count){
                return _ajax("/funds/"+code+"/comparison_data",{count:count});
            },
            /**
             * 查询指数历史数据
             */
            getHistoryIndex:function(indexCode,count){
                return _ajax("/funds/"+indexCode+"/history_index",{count:count});
            },
            /**
             * 查询指数收益
             */
            getIndexProfit:function(indexCodes){
                return _ajax("/funds/"+indexCodes+"/index_profit");
            },
            /**
             * 根据产品代码获取产品栏目及属性信息
             */
            getChannelByProdCode: function (prodCode) {
                return _ajax("/funds/" + prodCode + "/channel_fund");
            },
            /**
             * 获取推荐的关注列表
             */
            getOthersCare:function(){
                return _ajax("/funds/others_care");
            },
            /**
             * 短债产品可赎回查询
             */
            getShortTermFund:function(fundCode,transactionAccountId){
                return _ajax("/funds/"+fundCode+"/short_term?transactionAccountId="+transactionAccountId);
            },
            /**
             * 根据输入日期查询相关收益日期
             */
            getProfitDate:function(prodCode,prodIncomeDate){
                return _ajax("/funds/"+prodCode+"/profit_date?entrust_date="+prodIncomeDate);
            }
        };

        /**
         * 内部调用ajax方法
         * @param url
         * @private
         */
        function _ajax(url,data){
            var params = {};
            params.url = url;
            params.type = "get";
            params.cache = true;
            if(data) {
                params.data = data;
            }
            return CommonService.ajax(params);
        }
    };

    factory.$inject = ['$rootScope', '$http','$ionicLoading', 'CommonService', 'LocalCacheService'];
    return factory;
});