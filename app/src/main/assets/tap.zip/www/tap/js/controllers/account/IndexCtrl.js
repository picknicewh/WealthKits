define(function () {
    'use strict';

    function ctrl($scope,$state,$rootScope,LocalCacheService,CommonService,WebService,$ionicPopup){

        var par = $scope.param = new Array();

        var urlParams = CommonService.getUrlParams();
        var close = urlParams['close'];
        var from = urlParams['from']; // from=2 for hunme 隐藏4个按钮 隐藏密码类型 安全退出app
        if("2" == from) {
            sessionStorage["tf_hunme_from"] = 2;
            sessionStorage["tf_hunme_close"] = close;
            $.cookie("back_url_2", window.location.href, {path: '/'});
            $.cookie("back_url","",{path: '/',expires:-1});
            $rootScope.hideTabs = true;
        }

        $scope.onBackKeyDown = function(){
            if(sessionStorage["tf_hunme_close"]) {
                Messenger.send("close");
            } else if(CommonService.isBuyExperience()){ //理财体验活动
                window.location.href= $.cookie("back_url");
            } else {
                $state.go("tab.index");
            }
        };

        $scope.showIllustration = function(){
            var alertPopup = $ionicPopup.alert({
                title: null,
                template: "<p>本账户数据暂只包含小财迷平台理财产品的资产数据，不含股票资产。</p><br \>"+
                "<p>持仓盈亏是指目前持有产品的合计总盈亏；</p><br \>"+
                "<p>总投资额是指目前持有产品的总金额，含产品盈亏；</p><br \>"+
                "<p>账户余额是指本账户内供投资人用于购买产品的资金金额，投资者可以通过充值提现功能将银行卡中的资金转账到账户余额中，也可以将可取余额提现到银行卡。</p><br \>"+
                "<p>账户中显示的收益数据未扣除手续费，实际收益以基金公司实际到账金额为准。</p><br \>"+
                "<p>如有疑问，请咨询客服：400-800-5000。</p>",
                buttons:[{
                    text: '我知道了',
                    type: 'button-default'
                }]
            });
            alertPopup.then(function(res) {
                console.log('Thank you for not eating my delicious ice cream cone');
            });
        };

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            $scope.user = LocalCacheService.getUser();

            //获取存管银行信息
            WebService.getUserDepositBankCards().then(
                function (data) {
                    if(data.length > 0 && "1,2".indexOf(data[0].bkaccount_regflag) > -1){
                        par.show_recharge = true;
                        //查询保证金余额
                        queryBalance();
                    }
                }
            );

            //查询收益信息
            WebService.queryTotalIncome().then(
                function (data) {
                    if(data){
                        par.total_income = data.total_income;
                        par.total_invest = data.total_invest;
                    }
                }
            );
        }

        function queryBalance(){
            WebService.queryBalance().then(
                function(data){
                    par.enable_balance = data.enable_balance;
                }
            );
        }
    }

    ctrl.$inject = ['$scope','$state','$rootScope','LocalCacheService','CommonService','WebService','$ionicPopup'];
    return ctrl;
});
