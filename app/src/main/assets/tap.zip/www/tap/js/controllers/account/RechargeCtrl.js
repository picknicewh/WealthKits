define(function () {
    'use strict';

    function ctrl($scope,$ionicLoading,$ionicHistory,WebService,CommonService) {
        $scope.recharge = {};
        $scope.bank = {};

        init();

        function init(){
            //查询存管信息
            WebService.getUserDepositBankCards().then(
                function (data){
                    if(data.length != 0){
                        $scope.bank = data[0];
                        if("1" != $scope.bank.bkaccount_regflag){
                            var bankAccount = $scope.bank.bank_account;
                            $scope.bank.bank_account_show = bankAccount.substr(bankAccount.length-4);
                        }
                    }
                },
                function (result){
                    CommonService.showAlert({message:CommonService.getErrorInfo(result),onUnblock:function (){
                        $ionicHistory.goBack();
                    }});
                }
            )
        }

        $scope.fixBalance = function(){
            var v = $scope.recharge.occur_balance;
            if (!angular.isNumber(v)) {
                $scope.recharge.occur_balance = 0.00;
            } else {
                $scope.recharge.occur_balance = parseFloat(v.toFixed(2));
            }
        };

        $scope.rechargeClick = function () {
            if (checkInput()) {
                $ionicLoading.show();
                WebService.bankTransfer($scope.recharge.bank_password, $scope.recharge.occur_balance, $scope.bank.bank_no)
                    .then(function (data) {
                        $ionicLoading.hide();
                        switch (data){
                            case "2":showResult("充值成功",true);break;
                            case "3":showResult("充值失败",false);break;
                            case "4":showResult("查询存管银行失败。",false);break;
                            case "5":showResult("您的存管银行卡还未激活，请激活后再进行充值提现。</br>" + $scope.bank.remark,true);break;
                            default:showResult("充值请求已提交，请于下个交易日9:00后确认结果。",false);break;
                        }
                    },
                    function (error){
                        $ionicLoading.hide();
                        if(error.error_no == "IFS--61"){//银行非工作时间
                            if(error.error_info.indexOf("转账金额超出")  != -1) {
                                var s = error.error_info.split("v_bkinterfacelimit=");
                                showResult("您的充值金额超出银行卡限制金额"+ s[1].split("]")[0]+"元，请重新输入！",false);
                            } else  if(error.error_info.indexOf("转入金额超出限制")  != -1) {
                                var s = error.error_info.split("p_bk_upper_limit_in=");
                                showResult("您的充值金额超出单笔限额"+ s[1].split(",")[0]+"元，请重新输入！",false);
                            } else {
                                showResult("充值失败：请在工作日的9:00-16:00进行充值",true);
                            }
                        } else if(error.error_no == "IFS--57"){//银行非工作时间
                            showResult("充值银行卡余额不足：您的银行卡余额不足！",true);
                        } else if(error.error_no == "IFS--63"){//银行非工作时间
                            showResult("输入的银行卡密码不正确！请重新输入。",false);
                        } else {
                            showResult("充值失败:"+error.error_info,false);
                        }
                    }
                );
            }
        };

        var showResult = function (info,flag){
            CommonService.showConfig({title: "充值结果",message : info}).then(function(res) {
                if(flag){
                    $ionicHistory.goBack();
                }
            });

        };

        var checkInput = function (){
            if(!CommonService.checkRegex("^[0-9]+(.[0-9]{1,2})?$",$scope.recharge.occur_balance)){
                CommonService.showAlert({message:"请输入正确的金额,支持两位小数"});
                return false;
            }
            if(0==$scope.recharge.occur_balance){
                CommonService.showAlert({message:"输入金额必须大于零"});
                return false;
            }
            if(!CommonService.checkRegex("^[0-9]{6}$",$scope.recharge.bank_password)){
                CommonService.showAlert({message:"请输入6位银行卡密码"});
                return false;
            }
            return true;
        };
    }

    ctrl.$inject = ['$scope','$ionicLoading','$ionicHistory','WebService','CommonService'];
    return ctrl;
});