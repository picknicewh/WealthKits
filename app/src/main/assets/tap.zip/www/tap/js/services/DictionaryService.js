/**
 * Created by wang on 2015-11-4.
 * 字典
 */
define(['angular'], function (angular) {
    "use strict";

    var factory = function () {

        var profession_ads = [
            {"text":"文教科卫专业人员","val":"01"},
            {"text":"党政 ( 在职，离退休 ) 机关干部","val":"02"},
            {"text":"企事业单位干部","val":"03"},
            {"text":"行政企事业单位工人","val":"04"},
            {"text":"农民","val":"05"},
            {"text":"个体","val":"06"},
            {"text":"无业","val":"07"},
            {"text":"军人","val":"08"},
            {"text":"学生","val":"09"},
            {"text":"证券从业人员","val":"10"},
            {"text":"其他","val":"99"}
        ];

        var degree_ads = [
            {"text":"博士","val":"1"},
            {"text":"硕士","val":"2"},
            {"text":"学士","val":"3"},
            {"text":"大专","val":"4"},
            {"text":"中专","val":"5"},
            {"text":"高中","val":"6"},
            {"text":"初中及其以下","val":"7"},
            {"text":"其他","val":"8"}
        ];

        var weeks = {"1":"星期一","2":"星期二","3":"星期三","4":"星期四","5":"星期五","6":"星期六","0":"星期日"};

        var branchs = "1000,2,3,8,15,16,17,19,20,21,22,25,26,27,28,31,32,33,35,36,37,38,39,58,59,61,63,66,67,68,81,82,";

        var base64StrHead = "data:image/jpg;base64,";

        var defEndtime = "30001231";

        return {
            getProfessionAds : function(){
                return profession_ads;
            },
            getDegreeAds : function(){
                return degree_ads;
            },
            getWeeks : function(){
                return weeks;
            },
            getBranchs : function(){
                return branchs;
            },
            getBase64StrHead : function(){
                return base64StrHead;
            },
            getEndtime : function(endtime){
                return (!endtime || "长期" == endtime) ? this.getDefEndtime() : endtime;
            },
            getDefEndtime : function(){
                return defEndtime;
            }

        }


    };

    factory.$inject = [];
    return factory;
});