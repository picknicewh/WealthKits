define(function () {
    'use strict';

    function ctrl(LocalCacheService,$scope,$timeout,CommonService,WebService) {

        var par = $scope.param = {};
        par.step1=true;
        par.step2=false;
        par.step3=false;

        $scope.$on('$ionicView.beforeEnter', function() {
            //alert('页面刚加载');
            init();
        });

        $scope.$on('$ionicView.loaded', function() {
            //alert('页面加载中');
            // init();
        });

        $scope.$on('$ionicView.afterEnter',function(){
            //alert('页面加载完成');
        });
        function init(){
            //数字证书协议id特殊标识
            var agreement_no = 'cert';
            WebService.getEncontract(agreement_no).then(
                function(data){
                    par.econtract_name = data.econtract_name;
                    par.econtract_content = data.econtract_content;
                }
            );
        }

        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };

        $scope.agree = function(){
            par.step1=false;
            par.step2=true;
            WebService.certInstall().then(
                function(data){
                    $timeout(function (){
                        par.step2=false;
                        par.step3=true;
                    },2000);
                },
                function(result){
                    CommonService.showAlert({message: "证书安装失败，请重试"});
                    par.step1=true;
                    par.step2=false;
                }
            );
        };
    }

    ctrl.$inject = ['LocalCacheService','$scope','$timeout','CommonService','WebService'];
    return ctrl;
});