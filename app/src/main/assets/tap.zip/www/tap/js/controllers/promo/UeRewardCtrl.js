/**
 *  otc、银行理财 营销活动
 */
define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$state,WebService) {
        var par = $scope.param = new Array();


        $scope.$on('$ionicView.beforeEnter', function() {
            par.theme_id = $stateParams["id"];
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            WebService.channelStep("date").then(function(data){
                if(data && data.length > 0) {
                    var result = data[0];
                    par.beginDate = new Date(Number(result.beginDate));
                    par.endDate = new Date(Number(result.endDate));
                }
            })
        }

        $scope.onBackKeyDown = function(){
            $state.go("tab.index");
        };
    }

    ctrl.$inject = ['$scope','$stateParams','$state','WebService'];
    return ctrl;
});