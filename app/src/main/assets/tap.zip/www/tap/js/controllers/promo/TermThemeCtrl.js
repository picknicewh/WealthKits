define(function () {
    'use strict';

    function ctrl($scope, $filter, InfoService) {
        $scope.term = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init() {
            $scope.funds = new Array();
            //获取营地基金概况并添加事件
            queryContentBriefs();
        }

        function queryContentBriefs(){
            //0: 栏目ID 1：产品分级 2：留取条数
            var str = ($scope.term.channel).split(',');
            //查询并处理产品信息
            InfoService.getContentBriefs(str[0], str[1]).then(function(data){
                if(data){
                    for(var i=0;i<data.length && i< str[2];i++){
                        var fund = data[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                        $scope.funds.push(fund);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$filter', 'InfoService'];
    return ctrl;
});