/**
 * Created by wang on 2015-10-15.
 * 关注按钮
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function (CommonService, ConcernService) {
        return {
            restrict: "E",
            template: '<a id="jConcern" ng-click="operUserCare()" ng-class="{icon_concern:isCare,icon_concern_:!isCare}">关注</a>',
            replace: true,
            link: function( scope, element, attrs) {
                scope.$watch("fund.prodCode", function(newValue, oldValue){
                    if(newValue) {
                        scope.isCare = ConcernService.isConcern(newValue);
                    }
                });

                scope.operUserCare = function(){
                    scope.isCare = ConcernService.concern(scope.fund.prodCode);
                }
            }
        };

    };

    directive.$inject = ['CommonService', 'ConcernService'];
    return directive;
});