define(function () {
    'use strict';

    function ctrl($scope,WebService) {

        $scope.subjectData = new Array();

        $scope.$on('$ionicView.loaded', function() {
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            WebService.wtAd("xcm_history").then(function(data){
                $scope.subjectData = data;
            });
        }
    }

    ctrl.$inject = ['$scope','WebService'];
    return ctrl;
});