define(function () {
    'use strict';

    function ctrl($scope,$ionicHistory,$ionicLoading,CommonService,WebService) {

        $scope.withdraw = {};
        $scope.bank = {};

        init();

        function init(){
            //查询存管银行
            WebService.getUserDepositBankCards().then(
                function (data){
                    if(data.length != 0){
                        $scope.bank = data[0];
                        if("1" != $scope.bank.bkaccount_regflag){
                            var bankAccount = $scope.bank.bank_account;
                            $scope.bank.bank_account_show = bankAccount.substr(bankAccount.length-4);
                        }
                        //查询余额
                        queryBalance();
                    }
                },
                function (result){
                    CommonService.showAlert({message:CommonService.getErrorInfo(result),onUnblock:function (){
                        $ionicHistory.goBack();
                    }});
                }
            );
        }

        $scope.fixBalance = function(){
            var v = $scope.withdraw.occur_balance;
            if (!angular.isNumber(v)) {
                $scope.withdraw.occur_balance = 0.00;
            } else {
                $scope.withdraw.occur_balance = parseFloat(v.toFixed(2));
            }
        };

        function queryBalance(){
            WebService.queryBalance().then(
                function (data){
                    $scope.amount = data.fetch_balance;
                }
            );
        }

        $scope.withdrawClick = function(){
            if(checkInput()){
                $ionicLoading.show();
                WebService.bankWithdraw($scope.withdraw.fund_password, $scope.withdraw.occur_balance,
                    $scope.bank.bank_no).then(
                    function (data){
                        $ionicLoading.hide();
                        switch (data){
                            case "2": queryBalance();showResult("提现成功",true);break;
                            case "3":showResult("提现失败",false);break;
                            case "4":showResult("查询存管银行失败。",false);break;
                            case "5":showResult("您的存管银行卡还未激活，请激活后再进行充值提现。",true);break;
                            default:showResult("提现请求已提交，请于下个交易日9:00后确认结果。",false);break;
                        }
                    },
                    function (result){
                        $ionicLoading.hide();
                        if(result.error_no == "IFS--61"){//银行非工作时间
                            if(result.error_info.indexOf("转出金额超出限制") != -1) {
                                var s = result.error_info.split("v_bk_one_upper_limit_out=");
                                showResult("您的转出金额超出单笔限额"+ s[1].split("]")[0]+"元，请重新输入！",false);
                            } else {
                                showResult("取现失败：请在工作日的9:00-16:00进行取现",true);
                            }
                        } else if(result.error_no == "IFS--63"){//银行非工作时间
                            showResult("输入的资金密码不正确！请重新输入。",false);
                        } else {
                            showResult("取现失败："+result.error_info,false);
                        }
                    }
                );
            }
        };

        var showResult = function (info,flag){
            CommonService.showConfig({title: "取现结果",message : info}).then(
                function(res) {
                    if(flag){
                        $ionicHistory.goBack();
                    }
                }
            );
        };

        var checkInput = function (){
            if(!CommonService.checkRegex("^[0-9]+(.[0-9]{1,2})?$",$scope.withdraw.occur_balance)){
                CommonService.showAlert({message:"请输入正确的金额,支持两位小数"});
                return false;
            }
            if(0==$scope.withdraw.occur_balance){
                CommonService.showAlert({message:"输入金额必须大于零"});
                return false;
            }
            if(CommonService.controlNum($scope.withdraw.occur_balance,2) > CommonService.controlNum($scope.amount,2)){
                CommonService.showAlert({message:"输入金额不能大于可提现金额"});
                return false;
            }
            if(!CommonService.checkRegex("^[0-9]{6}$",$scope.withdraw.fund_password)){
                CommonService.showAlert({message:"请输入6位银行卡密码"});
                return false;
            }
            return true;
        };
    }

    ctrl.$inject = ['$scope','$ionicHistory','$ionicLoading','CommonService','WebService'];
    return ctrl;
});