define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$filter,$ionicHistory,LocalCacheService,CommonService,InfoService,WebService) {

        $scope.channel = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.from = $stateParams['from'];
            $scope.close = $stateParams['close'];
            $scope.redirect_url=$stateParams['redirect_url'];//更多的链接
            $scope.branch_no = $stateParams['branch_no'];// 营业部编号

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            WebService.getNotice('system').then(
                function (notice) {
                    if(notice.title && notice.content) {
                        CommonService.showNotice(notice.title + "&&" + notice.content);
                    } else {
                        //理财体验渠道号
                        if($scope.branch_no) {
                            WebService.qryBranch().then(
                                function (data){
                                    for(var i=0;i<data.length;i++){
                                        var branch = data[i];
                                        if(branch.branch_no == $scope.branch_no) {
                                            LocalCacheService.set("lcyt_branch_no", $scope.branch_no);
                                            break;
                                        }
                                    }
                                    if(!LocalCacheService.get("lcyt_branch_no")){
                                        CommonService.showAlert({message: "营业部编号[" + $scope.branch_no + "]不存在"});
                                    }
                                    queryContentBriefs();
                                }
                            );
                        } else {
                            queryContentBriefs();
                        }
                    }
                }
            );

            if($scope.from == '1') { //理财体验活动新增 可以直接买基金
                LocalCacheService.set("lcty_state", $ionicHistory.currentView());
                //理财体验活动 设置渠道
                LocalCacheService.setRecommendInfos();
            } else {

            }
            if($scope.redirect_url && CommonService.trim($scope.redirect_url) != "") {
                LocalCacheService.set("redirect_url",CommonService.trim($scope.redirect_url));
            }
        }

        ionic.Platform.ready(function(){
            if(close && !ionic.Platform.isIOS()) {
                setTimeout(function() {
                    navigator.splashscreen.hide();
                }, 1000);
            }
        });

        $scope.onBackKeyDown = function(){
            if($scope.close) {
                Messenger.send("close");
            } else {
//                $ionicHistory.goBack();
            }
        };

        function queryContentBriefs(){
            InfoService.getContentBriefs($scope.channel.channelId, 1).then(
                function(data){
                    if(data){
                        $scope.items = data;
                        for(var i=0;i<$scope.items.length;i++){
                            var fund = $scope.items[i];
                            fund.prodMinSubscribe =
                                (fund.cmsMinSubscribe && fund.cmsMinSubscribe>fund.prodMinSubscribe)? fund.cmsMinSubscribe: fund.prodMinSubscribe;
                            fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                        }
                    }
                }
            );
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$filter','$ionicHistory','LocalCacheService','CommonService','InfoService','WebService'];
    return ctrl;
});