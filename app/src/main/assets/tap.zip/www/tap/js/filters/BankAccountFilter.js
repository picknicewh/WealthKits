/**
 * Created by wang on 2015-9-22.
 * 银行卡显示后四位
 */
define(['angular'], function (angular) {
    "use strict";

    var filter = function () {
        /**
         * 原值 转换类型 默认值
         * type = 1   yyyyMMdd   --> yyyy-MM-dd
         *
         */
        return function (data, type, def) {
            if (null == data || "" == data || "undefined" == typeof(data)) {
                return '--';
            } else {
            return data.substring(data.length-3);
            }
        };
    };

    filter.$inject = [];
    return filter;
});