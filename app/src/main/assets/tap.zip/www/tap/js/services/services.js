define(function (require) {
    
    'use strict';
    
    var angular = require('angular'),
        config = require('config'),
        base = require ('base'),
        jqueryCookie = require ('jqueryCookie'),
        services = angular.module('app.services', ['app.config']);

    services.factory('DictionaryService', require('services/DictionaryService'));
    services.factory('LocalCacheService', require('services/LocalCacheService'));
    services.factory('CommonService', require('services/CommonService'));
    services.factory('InfoService', require('services/InfoService'));
    services.factory('HistoryNavChartService', require('services/HistoryNavChartService'));
    services.factory('ConcernService', require('services/ConcernService'));
    services.factory('WebService', require('services/WebService'));

    return services;

});