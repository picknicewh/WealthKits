define(function () {
    'use strict';

    function ctrl($scope,$state,$ionicLoading,$timeout,$ionicPopup,LocalCacheService,CommonService,WebService) {

        var timer = 180;
        var intervaltime;
        var par = $scope.param = {};
        $scope.from_dbgj = false;
        par.send_code_class = 'security-code jSecurityCode';
        par.send_code_msg = '获取验证码';
        par.input_check_code = false;
        par.input_check_code1 = false;
        $scope.$on('$ionicView.beforeEnter', function() {
            init();
            LocalCacheService.remove("img_base64_6a"); //清楚上传身份证图片
            LocalCacheService.remove("img_base64_6b");
            if($.trim(LocalCacheService.get('from_open_name'))!=undefined&&$.trim(LocalCacheService.get('from_open_name')).length>0){
                par.mobile_tel = $.trim(LocalCacheService.get('from_open_name'));
                par.input_check_code1 = true;
            }
        });
        //



        function init(){
            //理财体验活动新增 可以直接买基金
            if(CommonService.isBuyExperience()) {
                par.project='4';
            }else{
                par.project='2';
            }
            if('dbgj'==LocalCacheService.get('source')){
                $scope.from_dbgj = true;
                $scope.param.input_check_code = true;
            }
            //渠道统计相关
            par.source = CommonService.getSource();
        }

        $scope.sendCheckCode = function(){
            sendCheckCode();
        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };
        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };
        $scope.checkMobile = function(){

            if(checkInput()){
                $ionicLoading.show();
                var mobile_tel = CommonService.trim(par.mobile_tel);
                //验证手机验证码
                var params1 = {mobile_tel: mobile_tel, mobile_code: par.check_code};
                var params2 = {mobile_tel: mobile_tel, mobile_code: par.check_code, project: par.project,
                    recommendInfos: par.recommendInfos, source: par.source};
                WebService.checkMobileCode(params1).then(
                    function(){
                        WebService.msgVerify(params2).then(
                            function(data){
                                if(data.url.path == "open-msgVerify") {
                                    //b=1 存管绑定成功，b=2 存管绑定受理，b=3 正在处理
                                    var b = data.params.b;
                                    if(!CommonService.isStrEmpty(b)){
                                        if('1'== b){
                                            openAccountSus();
                                        }else if('2,3'.indexOf( b) > -1){
                                            CommonService.showConfig({message:"您的存管银行绑定申请正在受理中，请稍候处理结果。"});
                                        }else{
                                            CommonService.showConfig({message:"您的存管银行绑定异常，请联系客服400-800-5000。"});
                                        }
                                    }
                                } else{
                                    WebService.getCurrentOpenUser().then(
                                        function(result){
                                            $ionicLoading.hide();
                                            LocalCacheService.setOpenUser(result);
                                            if('open-bindOpenDeposit'==data.url.path){
                                                $state.go('open-bindOpenQuick',angular.fromJson(data.params));
                                            }else{
                                                $state.go(data.url.path,angular.fromJson(data.params));
                                            }

                                        }
                                    )
                                }
                            },
                            function(result){
                                $ionicLoading.hide();
                                CommonService.showAlert({message: CommonService.getErrorInfo(result)});
                            }
                        )
                    },
                    function(result){
                        CommonService.showAlert({message: result.error_info});
                        $ionicLoading.hide();
                    }
                );
            }
        };

        function sendCheckCode(){

            if(checkMobile() && par.send_code_class.indexOf("countdown") < 0){
                par.send_code_class = 'security-code countdown';
                //查询是否有手机号的渠道信息
                var mobile_tel = CommonService.trim(par.mobile_tel);
                var params1 = {mobile_tel: mobile_tel};
                WebService.qryBindConduitInfo(params1).then(
                    function(data){
                        //用户有渠道信息 包没渠道号
                        if(!CommonService.isStrEmpty(data.conduit_no)){
                            LocalCacheService.setRecommendInfos(data.conduit_no);
                        }
                        par.recommendInfos = LocalCacheService.getRecommendInfos();
                        var params2 = {mobile_tel: mobile_tel, recommendInfos: par.recommendInfos, source: par.source};
                        WebService.sendCheckCode(params2).then(
                            function(data){
                               // alert(JSON.stringify(data));
                                timer = 180;
                                par.send_code_msg = timer + '秒后重发';
                                $scope.sendCheckCode = function(){};
                                par.input_check_code = true;
                                intervaltime = $timeout(showCountDown,1000);
                            },
                            function(result){
                               // alert(JSON.stringify(result));
                                par.send_code_class = 'security-code jSecurityCode';
                                par.send_code_msg = '获取验证码';
                                if("XCM-300002" == result.error_no){
                                    openAccountSus();
                                }else{
                                    if(result.error_info){
                                        result.error_info = result.error_info.replace("参数传入错误,", "");
                                    }
                                    CommonService.showConfig({message:result.error_info});
                                }
                            }
                        )
                    }
                );
            }
        }

        function showCountDown(){
            var currentTime = --timer;
            if(currentTime >=0){
                par.send_code_msg = currentTime + '秒后重发';
                $timeout(showCountDown,1000);
            }else{
                if(intervaltime){
                    $timeout.cancel(intervaltime);
                }
                par.send_code_class = 'security-code jSecurityCode';
                par.send_code_msg = '获取验证码';
                $scope.sendCheckCode = function(){
                    sendCheckCode();
                };
                par.input_check_code = false;
            }
        }

        function checkMobile() {
            if(CommonService.isStrEmpty(par.mobile_tel)){
                CommonService.showAlert({message: "请输入手机号"});
                return false;
            }
            if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$", CommonService.trim(par.mobile_tel))) {
                CommonService.showAlert({message: "手机号格式错误"});
                return false;
            }
            return true;
        }

        function checkInput() {
            checkMobile();
            if(CommonService.isStrEmpty(par.check_code)){
                if(par.input_check_code){
                    CommonService.showAlert({message: "请输入验证码"});
                }else{
                    CommonService.showAlert({message: "请点击获取验证码"});
                }
                return false;
            }
            return true;
        }

        function openAccountSus(){
            $ionicPopup.confirm({
                title: "提示",
                template: "您已是天风证券客户，请直接登录",
                okText:"去登录",
                cancelText:"取消"
            }).then(function(res) {
                if(res) {
                    window.location.href = "../../tap_1/view/index_android.html#/tab/login_android/"+$.trim(LocalCacheService.get('from_open_name'))+"/"+$.trim(LocalCacheService.get('from_open_token'))+"/"+$.trim( LocalCacheService.get('from_open_key'));
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$state','$ionicLoading','$timeout','$ionicPopup','LocalCacheService','CommonService','WebService'];
    return ctrl;
});