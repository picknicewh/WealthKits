define(function () {
    'use strict';

    function ctrl($scope,$state,$ionicLoading,$stateParams,$ionicScrollDelegate,
                  CommonService,WebService,DictionaryService,LocalCacheService) {

        var par=$scope.param = {};
        par.info = {};
        par.info.branch_no = ($stateParams['branch_no'] ? $stateParams['branch_no'] : null);

        $scope.$on('$ionicView.beforeEnter', function(){
            var img_base64 =  LocalCacheService.get("img_base64_6a");
            if(img_base64) {
                par.front_img = DictionaryService.getBase64StrHead() + img_base64;
            } else {
                par.front_img = null;
            }
            img_base64 =  LocalCacheService.get("img_base64_6b");
            if(img_base64) {
                par.reverse_img = DictionaryService.getBase64StrHead() + img_base64;
            } else {
                par.reverse_img = null;
            }

        });

       // {base64str: 图片base64， type：正反面类型(1:正面 0:反面), code: 身份证号，name:姓名，gender:性别,
       // nation：名族， address：住址， 签发机关：issue，valid:有效期, starttime: 起始时间；endtime: 结束时间}； yyyyMMdd
        $scope.uploadID = function(){
            //点击拍照
            if(typeof IDCardScanner !== 'undefined'){
                IDCardScanner.popScanner(function(data){
                    if(data.error_no == 0) {
                        if(data.type == 1){
                            par.info.id_no = data.code;
                            par.info.client_gender = (data.gender == "男" ? "0" : "1");//男：0，女：1;
                            par.info.nation = data.nation;
                            par.info.address = data.address;
                            par.info.name = data.name;
                            LocalCacheService.set("img_base64_6a", data.base64str);
                            LocalCacheService.set("info_6a", par.info);

                            par.front_img = DictionaryService.getBase64StrHead() + data.base64str;

                        } else {
                            par.info.issue = data.issue;
                            par.info.valid = data.valid;
                            par.info.starttime = data.starttime;
                            par.info.endtime = DictionaryService.getEndtime(data.endtime);
                            LocalCacheService.set("img_base64_6b", data.base64str);
                            LocalCacheService.set("info_6b", par.info);

                            par.reverse_img = DictionaryService.getBase64StrHead() + data.base64str;

                        }

                        $ionicScrollDelegate.resize();
                    }
                });
            } else {
                $ionicLoading.hide();
                CommonService.showAlert({message:"控件检测失败，请重新下载app"});
            }
        };

        $scope.nextClick = function(){
            if(checkIdImg()){
                $ionicLoading.show();
                par.info.source = CommonService.getSource();
                par.info.img_base64_6a = LocalCacheService.get("img_base64_6a");
                par.info.img_base64_6b = LocalCacheService.get("img_base64_6b");
                var info = LocalCacheService.get("info_6a");
                par.info.id_no = info.id_no;
                par.info.client_gender = info.client_gender;
                par.info.nation = info.nation;
                par.info.address = info.address;
                par.info.name = info.name;
                info = LocalCacheService.get("info_6b");
                par.info.issue = info.issue;
                par.info.valid = info.valid;
                par.info.starttime = info.starttime;
                par.info.endtime = info.endtime;

                WebService.uploadID(par.info).then(
                    function(data){
                        $ionicLoading.hide();
                        $state.go('open-personInfo');
                    },
                    function(data){
                        $ionicLoading.hide();
                        showFailInfo();
                    }
                );
            }
        };


        function showFailInfo(){
            var html='抱歉！身份证未能识别，请重新拍摄。<ol>' +
                        '<li>手动对焦，确保拍摄证件文字、头像清晰</li>' +
                        '<li>在光线充足环境拍摄，避免反光（将证件放在角落拍摄可避免反光）</li>' +
                        '<li>确保身份证四角都能在拍摄框内</li>' +
                        '<li>请将手机横过来拍摄</li>' +
                    '</ol>';
            CommonService.showConfig({okText:"我知道了", message : html});
        }


        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };
        
        function checkIdImg(){
            if(!par.front_img && !par.reverse_img) {
                CommonService.showAlert({message:"请上传身份证正反面后再提交"});
                return false;
            }
            if(!par.front_img){
                CommonService.showAlert({message:"请上传身份证正面"});
                return false;
            }
            if(!par.reverse_img){
                CommonService.showAlert({message:"请上传身份证反面"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$state','$ionicLoading','$stateParams','$ionicScrollDelegate',
        'CommonService','WebService','DictionaryService','LocalCacheService'];
    return ctrl;
});