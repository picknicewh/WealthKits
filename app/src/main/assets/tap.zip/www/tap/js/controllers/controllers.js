/*global define, require */

define(function (require, exports, module) {

    'use strict';

    var angular = require('angular'),
        services = require('services/services'),
        config = require('config'),
        controllers = angular.module('app.controllers', ['app.services', 'app.config']);

    controllers.controller('IndexCtrl', require('controllers/IndexCtrl'));
    controllers.controller('LoginCtrl', require('controllers/LoginCtrl'));

    controllers.controller('product_ItemCtrl', require('controllers/product/ItemCtrl'));
    controllers.controller('product_DetailCtrl', require('controllers/product/DetailCtrl'));
    controllers.controller('product_ItemOtcCtrl', require('controllers/product/ItemOtcCtrl'));
    controllers.controller('product_DetailOtcCtrl', require('controllers/product/DetailOtcCtrl'));
    controllers.controller('product_ItemQDIICtrl', require('controllers/product/ItemQDIICtrl'));

    controllers.controller('product_IndexCtrl', require('controllers/product/IndexCtrl'));
    controllers.controller('product_CurrentTermCtrl', require('controllers/product/CurrentTermCtrl'));
    controllers.controller('product_MoreCtrl', require('controllers/product/MoreCtrl'));
    controllers.controller('product_StarTermCtrl', require('controllers/product/StarTermCtrl'));
    controllers.controller('product_ShortTermCtrl', require('controllers/product/ShortTermCtrl'));
    controllers.controller('product_TFTermCtrl', require('controllers/product/TFTermCtrl'));
    controllers.controller('product_LongTermCtrl', require('controllers/product/LongTermCtrl'));
    controllers.controller('product_GoldTermCtrl', require('controllers/product/GoldTermCtrl'));
    controllers.controller('product_QDIITermCtrl', require('controllers/product/QDIITermCtrl'));
    controllers.controller('product_IndexTermCtrl', require('controllers/product/IndexTermCtrl'));
    controllers.controller('product_StockTermCtrl', require('controllers/product/StockTermCtrl'));

    controllers.controller('account_ConcernCtrl', require('controllers/account/ConcernCtrl'));
    controllers.controller('account_IndexCtrl', require('controllers/account/IndexCtrl'));

    controllers.controller('account_ManagerCtrl', require('controllers/account/ManagerCtrl'));
    controllers.controller('account_UserInfoCtrl', require('controllers/account/UserInfoCtrl'));
    controllers.controller('account_ModifyPhoneCtrl', require('controllers/account/ModifyPhoneCtrl'));
    controllers.controller('account_ModifyPwdCtrl', require('controllers/account/ModifyPwdCtrl'));
    controllers.controller('account_RiskCtrl', require('controllers/account/RiskCtrl'));
    controllers.controller('account_BankCtrl', require('controllers/account/BankCtrl'));
    controllers.controller('help_IndexCtrl', require('controllers/help/IndexCtrl'));
    controllers.controller('help_ItemCtrl', require('controllers/help/ItemCtrl'));

    controllers.controller('open_PrepareCtrl', require('controllers/open/PrepareCtrl'));
    controllers.controller('open_MsgVerifyCtrl', require('controllers/open/MsgVerifyCtrl'));
    controllers.controller('open_SelectBranchCtrl', require('controllers/open/SelectBranchCtrl'));
    controllers.controller('open_UploadIDCtrl', require('controllers/open/UploadIDCtrl'));
    controllers.controller('open_PersonInfoCtrl', require('controllers/open/PersonInfoCtrl'));
    controllers.controller('open_InstallCertCtrl', require('controllers/open/InstallCertCtrl'));
    controllers.controller('open_RiskAssessCtrl', require('controllers/open/RiskAssessCtrl'));
    controllers.controller('open_SetPwdCtrl', require('controllers/open/SetPwdCtrl'));
    controllers.controller('open_SignAgreementCtrl', require('controllers/open/SignAgreementCtrl'));
    controllers.controller('open_RevisitPaperCtrl', require('controllers/open/RevisitPaperCtrl'));
    controllers.controller('open_OpenResultCtrl', require('controllers/open/OpenResultCtrl'));
    controllers.controller('open_ChannelRiskCtrl', require('controllers/open/ChannelRiskCtrl'));

    controllers.controller('open_BindDepositBankCtrl', require('controllers/open/BindDepositBankCtrl'));
    controllers.controller('open_BindQuickBankCtrl', require('controllers/open/BindQuickBankCtrl'));
    controllers.controller('account_UnbindBankCtrl', require('controllers/account/UnbindBankCtrl'));

    controllers.controller('account_SharesCtrl', require('controllers/account/SharesCtrl'));
    controllers.controller('account_OrdersCtrl', require('controllers/account/OrdersCtrl'));
    controllers.controller('account_OrderProdHistoryCtrl', require('controllers/account/OrderProdHistoryCtrl'));
    controllers.controller('account_ShareDetailCtrl', require('controllers/account/ShareDetailCtrl'));
    controllers.controller('account_ShareDetailShortCtrl', require('controllers/account/ShareDetailShortCtrl'));
    controllers.controller('account_ShareDetailBankCtrl', require('controllers/account/ShareDetailBankCtrl'));
    controllers.controller('account_ShareDetailGatherCtrl', require('controllers/account/ShareDetailGatherCtrl'));
    controllers.controller('account_ShareDetailQDIICtrl', require('controllers/account/ShareDetailQDIICtrl'));
    controllers.controller('account_OrderDetailCtrl', require('controllers/account/OrderDetailCtrl'));
    controllers.controller('account_RechargeCtrl', require('controllers/account/RechargeCtrl'));
    controllers.controller('account_QueryBalanceCtrl', require('controllers/account/QueryBalanceCtrl'));
    controllers.controller('account_WithdrawCtrl', require('controllers/account/WithdrawCtrl'));
    controllers.controller('account_TransferDetailsCtrl', require('controllers/account/TransferDetailsCtrl'));
    controllers.controller('account_RechargeAndWithdrawCtrl', require('controllers/account/RechargeAndWithdrawCtrl'));


    controllers.controller('trade_BuyCtrl', require('controllers/trade/BuyCtrl'));
    controllers.controller('trade_AgreementListCtrl', require('controllers/trade/AgreementListCtrl'));
    controllers.controller('trade_AgreementCtrl', require('controllers/trade/AgreementCtrl'));
    controllers.controller('trade_SelectPayWayCtrl', require('controllers/trade/SelectPayWayCtrl'));
    controllers.controller('trade_SellCtrl', require('controllers/trade/SellCtrl'));

    controllers.controller('promo_UeRewardCtrl', require('controllers/promo/UeRewardCtrl'));
    controllers.controller('promo_SubjectCtrl', require('controllers/promo/SubjectCtrl'));
    controllers.controller('promo_PastSubjectCtrl', require('controllers/promo/PastSubjectCtrl'));
    controllers.controller('promo_OtcCtrl', require('controllers/promo/OtcCtrl'));
    controllers.controller('promo_WxQuestionCtrl', require('controllers/promo/WxQuestionCtrl'));
    controllers.controller('promo_ThemeCtrl', require('controllers/promo/ThemeCtrl'));
    controllers.controller('promo_TermThemeCtrl', require('controllers/promo/TermThemeCtrl'));
    controllers.controller('promo_BankThemeCtrl', require('controllers/promo/BankThemeCtrl'));
    controllers.controller('promo_RewardCtrl', require('controllers/promo/RewardCtrl'));
    controllers.controller('promo_PracticeCtrl', require('controllers/promo/PracticeCtrl'));
    controllers.controller('open_FillCustomerInfoCtrl', require('controllers/open/FillCustomerInfoCtrl'));

    controllers.controller('us_IndexCtrl', require('controllers/us/IndexCtrl'));
    controllers.controller('us_FeedbackCtrl', require('controllers/us/FeedbackCtrl'));

    //初始化
    controllers.run(['$rootScope','$state', '$ionicHistory', 'LocalCacheService','IP','BASE_PATH',
        '$http','offline','CacheFactory','$cordovaNetwork','PULLING_TEXT','REFRESHING_TEXT',
        function ($rootScope, $state, $ionicHistory, LocalCacheService, IP,BASE_PATH, $http, offline,
                  CacheFactory, $cordovaNetwork, PULLING_TEXT, REFRESHING_TEXT) {

            $http.defaults.cache = CacheFactory.createCache('offlineCache', {deleteOnExpire: 'none',
                maxAge: 0,storageMode: 'localStorage',storagePrefix : "tfzq."});

            offline.start($http);

            $rootScope.basePath = BASE_PATH;
            $rootScope.ip = IP;
            $rootScope.PULLING_TEXT = PULLING_TEXT;
            $rootScope.REFRESHING_TEXT = REFRESHING_TEXT;
            $rootScope.isOffline = false;
            $rootScope.$on('$cordovaNetwork:online', function(event, networkState){
                $rootScope.isOffline = false;
            });
            $rootScope.$on('$cordovaNetwork:offline', function(event, networkState){
                console.log("got offline");
                $rootScope.isOffline = true;

            });
//            $rootScope.log_out1 = function(){
//            //    alert(333333333355555555555+'kkkkkkkk');
//            };
            $rootScope.closeDigitalKeyboard = function(){ //关闭数字键盘
                if(typeof DigitalKeyboard !== 'undefined') {
                    DigitalKeyboard.close(function(status){});
                }
            };

            $rootScope.goProductIndex = function(){
                $state.go("tab.product-index");
            };

            $rootScope.goAccountIndex= function(){
                //获取缓存的用户信息
                var user = LocalCacheService.getUser();
                if(!user){
                    //取消默认跳转行为
                    event.preventDefault();
                    //跳转到登陆界面
                    var currentView = $ionicHistory.currentView();
                    $state.go("login",{from:currentView.stateName, fromParams: angular.toJson(currentView.stateParams),
                        w:'notLogin',to: "tab.account-index", toParams: ""});
                } else {
                    //取消默认跳转行为
                    event.preventDefault();
                    $state.go("tab.account-index");
                }

            };

            $rootScope.$on('$ionicView.beforeEnter', function () {
                var stateName = $state.current.name;
                $rootScope.hideTabs = false;
                if (stateName === 'tab.index' || stateName === 'tab.product-index'
                    || stateName === 'tab.account-index') {
                    $rootScope.hideTabs = false;
                } else {
                    $rootScope.hideTabs = true;
                }
            });

            //拦截
            $rootScope.$on('$stateChangeStart',function(event, toState, toParams, fromState, fromParams){

                if(typeof Messenger != 'undefined') {
                    if(fromState && fromState.name != "") {
                        Messenger.sendMsg("ym_endLogPageView",{pageID:fromState.url} ,null,null);
                    }
                    Messenger.sendMsg("ym_beginLogPageView",{pageID:toState.url} ,null,null);
                }

                if(typeof DigitalKeyboard != 'undefined') {
                    DigitalKeyboard.close(function(status){});
                }

                if(!toState.loginStatus && !toState.openStatus){ //未设置登录拦截、开户拦截的请求，直接跳转
                    return;
                }
                if(toState.loginStatus && !LocalCacheService.getUser()){ //登陆拦截
                    //取消默认跳转行为
                    event.preventDefault();
                    //跳转到登陆界面
                    $state.go("login",{from:fromState.name, fromParams: angular.toJson(fromParams),
                        w:'notLogin',to: toState.name, toParams: angular.toJson(toParams)});
                }
                if(toState.openStatus && !LocalCacheService.getOpenUser()){ //开户拦截
                    //取消默认跳转行为
                    event.preventDefault();
                    //跳转到手机验证页
                    $state.go("open-msgVerify");
                }
            });

            $rootScope.$on('userIntercepted',function(errorType, data){
                // 跳转到登录界面
                $state.go("login",{from:$state.current.name,w:data});
            });
            $rootScope.$on('openUserIntercepted',function(errorType, data){
                // 跳转到手机号验证界面
                $state.go("open-msgVerify");
            });
            var onReceiveMessage = function (event) {
                var message;
                if (device.platform == "Android") {
                    message = window.plugins.PushPlugin.receiveMessage.message;
                } else {
                    message = event.message;
                } if(typeof message != 'undefined') {
                    var bToObj = JSON.parse(message);
                    //var extras = window.plugins.PushPlugin.extras
                    var toView = bToObj.value.view;
                    if(typeof toView != 'undefined') {
                        var params = bToObj.value.params;
                        $state.go(toView,params);
                    }
                }
            };
            //APP在后台中，获取点击通知内容
            var onOpenNotification = function (event) {
                var alertContent;
                if (device.platform == "Android") {
                    alertContent = window.plugins.PushPlugin.openNotification.alert;
                } else {
                    alertContent = event.aps.alert;
                }
                console.log("open Notificaiton:" + alertContent);
            };
            //APP在运行状态中，获取通知内容
            var onReceiveNotification = function (event) {
                var alertContent;
                if (device.platform == "Android") {
                    alertContent = window.plugins.PushPlugin.receiveNotification.alert;
                } else {
                    alertContent = event.aps.alert;
                }
                console.log("Receive Notificaiton:" + alertContent);
            };

            var log_out = function(){
                //alert(1111111111);
                LocalCacheService.removeUser();
            };

            document.addEventListener("push.receiveMessage", onReceiveMessage, false);
            document.addEventListener("push.openNotification", onOpenNotification, false);
            document.addEventListener("push.receiveNotification", onReceiveNotification, false);

            document.addEventListener("event.user.log_out", log_out, false);
        }]);
    
    return controllers;
});