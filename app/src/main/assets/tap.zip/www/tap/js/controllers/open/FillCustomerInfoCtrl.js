define(function () {
    'use strict';

    function ctrl($scope,$state,$stateParams,$ionicLoading,LocalCacheService,CommonService,WebService) {
        $scope.info = {};
        $scope.idNoFlag = true;//身份证可用
        $scope.birthday = null; //生日

        $scope.agreeAgreements = LocalCacheService.get("agreeAgreements");
        if($scope.agreeAgreements) {
            if($scope.agreeAgreements.indexOf("2011")!=-1){
                $scope.agreement2011 = true;
            }
            if($scope.agreeAgreements.indexOf("2012")!=-1){
                $scope.agreement2011 = true;
            }
            if($scope.agreeAgreements.indexOf("2010")!=-1){
                $scope.agreement2011 = true;
            }
        }
        var b = $stateParams["b"]; //继续开户 不验证身份证

        $scope.$on('$ionicView.loaded', function() {
            init();
        });

        function init (){
            if("1" != b) {
                $scope.checkIdNo = function(){
                    if(checkIdNo()) {
                        var params = {id_no: $scope.info.id_no};
                        WebService.checkIdNo(params).then(
                            function(data){
                                if(!data) {
                                    $scope.idNoFlag = false;
                                    CommonService.showAlert({message:"身份证号已注册！"});
                                } else {
                                    $scope.idNoFlag = true;
                                }
                            }
                        );
                    }    
                }
            }
        }

        $scope.next = function (){
            if(checkForm()){
                var id_no = CommonService.trim($scope.info.id_no);
                var address = "中华人民共和国家";
                var password = CommonService.trim($scope.info.password);
                var client_gender = maleOrFemalByIdCard(id_no);
                var client_name =  CommonService.trim($scope.info.client_name);
                var lcyt_branch_no = LocalCacheService.get("lcyt_branch_no") ?  LocalCacheService.get("lcyt_branch_no") : null;
                $ionicLoading.show();
                var params = {client_name : client_name,id_no : id_no,address :address, password : password,birthday : $scope.birthday,
                    client_gender : client_gender,id_address : address,source:CommonService.getSource(), branch_no: lcyt_branch_no };
                WebService.open0(params).then(
                    function(data){
                        $ionicLoading.hide();
                        $state.go("open-bindOpenBank", {b:2});
                    }
                );
            }
        };

        function checkForm(){
            return  checkClientName() && checkIdNo(true)
                && checkPassword() && checkRePassword() && checkProtocol();
        }

        function checkProtocol() {
            var agreeAgreements = $scope.agreeAgreements = LocalCacheService.get("agreeAgreements");
            if(agreeAgreements.indexOf("2011") != -1 && agreeAgreements.indexOf("2012") != -1
                && agreeAgreements.indexOf("2010") != -1){
                return true;
            }
            CommonService.showAlert({message: "请选中相关协议"});
            return false;
        }

        function checkRePassword() {
            var utel = angular.element(document.querySelector('#repassword'));
            if($scope.info.repassword != $scope.info.password){
                CommonService.showAlert({message:"两次输入的密码不一致！"});
                utel.focus();
                return false;
            }
            return true;
        }

        function checkPassword() {
            var utel = angular.element(document.querySelector('#password'));
            var str = $scope.info.password;
            if(!str || str==null || CommonService.trim(str) == ""){
                CommonService.showAlert({message:"交易密码必填！"});
                utel.focus();
                return false;
            }
            str = CommonService.trim(str);
            if(!/^\d{6}$/.test(str)){
                CommonService.showAlert({message:"交易密码为6位数字！"});
                utel.focus();
                return false;
            }
            return true;
        }

        function checkIdNo(next) {
            var str = $scope.info.id_no;
            var utel = angular.element(document.querySelector('#id_no'));
            if(!str || str==null || CommonService.trim(str) == ""){
                CommonService.showAlert({message:"身份证号码必填！"});
                if(next) utel.focus();
                return false;
            }
            str = CommonService.trim(str);
            $scope.birthday = CommonService.checkIdCard(str);
            if(!$scope.birthday){
                CommonService.showAlert({message: "身份证号码输入有误！"});
                if(next)  utel.focus();
                return false;
            }
            var age = CommonService.jsGetAge($scope.birthday);
            if(age < 18 || age > 70) {
                CommonService.showAlert({message:"您的年龄不符合开户要求，18岁--88岁之间可正常开户。"});
                if(next) utel.focus();
                return false;
            }
            if(next && !$scope.idNoFlag) {
                utel.focus();
                return false;
            }
            return true;
        }

        function checkClientName(){
            var utel = angular.element(document.querySelector('#client_name'));
            var str = $scope.info.client_name;
            if(!str || str==null || CommonService.trim(str) == ""){
                CommonService.showAlert({message:"真实姓名必填！"});
                utel.focus();
                return false;
            }
            str = CommonService.trim(str);
            if(str.length > 6){
                CommonService.showAlert({message:"真实姓名长度不能大于6！"});
                utel.focus();
                return false;
            }
            return true;
        }

        /**
         * 通过身份证判断是男是女
         * @param idCard 15/18位身份证号码
         * @return 'female'-女、'male'-男
         */
        function maleOrFemalByIdCard(idCard){
            idCard = CommonService.trim(idCard.replace(/ /g, ""));        // 对身份证号码做处理。包括字符间有空格。
            if(idCard.length==15){
                if(idCard.substring(14,15)%2==0){
                    return 'F';
                }else{
                    return 'M';
                }
            }else if(idCard.length ==18){
                if(idCard.substring(14,17)%2==0){
                    return 'F';
                }else{
                    return 'M';
                }
            }else{
                return null;
            }
        }

    }

    ctrl.$inject = ['$scope','$state','$stateParams','$ionicLoading','LocalCacheService','CommonService','WebService'];
    return ctrl;
});