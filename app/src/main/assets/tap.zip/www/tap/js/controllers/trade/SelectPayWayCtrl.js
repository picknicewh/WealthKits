define(function () {
    'use strict';

    function ctrl($scope,$ionicHistory,LocalCacheService,WebService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            $scope.pay = LocalCacheService.get("BuyCtrl_pay");
            $scope.quickBankData = LocalCacheService.get("BuyCtrl_quickBankData");
            $scope.selectPayWay =  $scope.pay.pay_kind == 1 ? $scope.pay.pay_kind + "_" + $scope.pay.pay_account : $scope.pay.pay_kind;

            var forwardView = $ionicHistory.forwardView();
            if(forwardView){
                if(forwardView.stateName == "recharge-and-withdraw"){
                    WebService.queryBalance().then(
                        function (data){
                            var amount = data.fetch_balance;
                            var buy = LocalCacheService.get("BuyCtrl_buy");
                            if(parseFloat(amount) >= buy.entrust_balance) {
                                $scope.pay.payAccountStatus=1;
                            }
                        }
                    );
                } else if(forwardView.stateName =="tab.account-bindQuickBank"){
                    WebService.getUserQuickBankCards().then(
                        function (data){
                            var quickBankData = data;
                            LocalCacheService.set("BuyCtrl_quickBankData", quickBankData);
                            $scope.quickBankData = data;
                        }
                    )
                }
            }
        }

        $scope.changPayWay = function(data){
            var pay = {};
            if(data == 0) {
                pay.pay_kind=0;
                pay.bank_no=0;
                pay.pay_account="";
                pay.html = '<span class="txt">保证金账户余额支付</span>';
                pay.full=true;
            } else {
                pay.pay_kind=1;
                pay.bank_no=data.bank_no;
                pay.pay_account=data.bank_account;
                pay.html= '<span class="title">快捷支付</span><span class="txt_m">' + data.bank_name + ' 尾号'
                    + data.bank_account.substring(data.bank_account.length-3) + '</span>';
            }
            pay.payAccountStatus = $scope.pay.payAccountStatus;
            LocalCacheService.set("SelectPayWayCtrl_pay", pay);
            $ionicHistory.goBack();
        }
    }

    ctrl.$inject = ['$scope','$ionicHistory','LocalCacheService','WebService'];
    return ctrl;
});
