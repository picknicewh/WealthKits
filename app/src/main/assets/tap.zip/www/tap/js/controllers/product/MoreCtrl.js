define(function () {
    'use strict';

    function ctrl($scope, CommonService) {

        $scope.tfdzhDownLoad = function(){
            var downloadUrl;
            if(ionic.Platform.isAndroid()){
                downloadUrl = "http://wap.tfzq.com/2014/download/1.apk";

            }else if(ionic.Platform.isIOS()){
                downloadUrl = "https://itunes.apple.com/cn/app/id948164343?mt=8";

            }else{
                CommonService.showAlert({message:"客户端类型检测失败"});
                return;
            }
            Messenger.sendMsg("updateApp", {"type":3,
                    "title":"下载中",
                    "appName":"天风同花顺",
                    "versionName": 1.1,
                    "versionCode": 2057,
                    "content":"",
                    "downloadUrl": downloadUrl},
                onUpdateExit, null);
        };

        function onUpdateExit(){

        }
    }

    ctrl.$inject = ['$scope', 'CommonService'];
    return ctrl;

});