define(function () {
    'use strict';

    function ctrl($scope,$state,$ionicLoading,LocalCacheService,CommonService,DictionaryService,WebService) {

        $scope.profession_ads = DictionaryService.getProfessionAds();
        $scope.degree_ads =  DictionaryService.getDegreeAds();

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.user = LocalCacheService.getUser();
        });

        $scope.changeSel = function(){
            $ionicLoading.show();
            WebService.modifyUserInfo($scope.user.profession_code, $scope.user.degree_code).then(
                function(){
                    WebService.getUserInfo().then(
                        function (result) {
                            LocalCacheService.setUser(result);
                            $ionicLoading.hide();
                            CommonService.showAlert({message: "修改成功"});
                        }
                    )
                }
            )
        };

        //退出
        $scope.exitClick = function(){
            WebService.logout().then(
                function(data){
                    if(typeof Messenger != 'undefined') {
                        Messenger.sendMsg("ym_profileSignOff",null ,null,null);
                    }
                    LocalCacheService.removeUser();
                    if("2" == sessionStorage["tf_hunme_from"]) {
                        Messenger.send("close");
                    } else {
                        $state.go("tab.index");
                    }
                }
            );
        };
    }

    ctrl.$inject = ['$scope','$state','$ionicLoading','LocalCacheService','CommonService','DictionaryService','WebService'];
    return ctrl;
});