/**
 * Created by wang on 2015-10-20.
 *  `forward`, `back`, `enter`, `exit`, `swap`.
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function ($ionicViewSwitcher) {
        return {
            restrict: 'A',
            priority: 900,
            link: function($scope, $element, $attr) {
                $element.bind('click', function() {
                    $ionicViewSwitcher.nextDirection($attr.tfNavDirection);
                });
            }
        };
    };

    directive.$inject = ['$ionicViewSwitcher'];
    return directive;
});