define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$stateParams,$sce,InfoService) {

        var par = $scope.param = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            par.contentId = $stateParams['contentId'];

            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            })
        };

        function init(){
            //获取cms基金明细
            return InfoService.getContentDetail(par.contentId).then(function(data){
                if(data){
                    $scope.fund = data;
                    if($scope.fund.prodSubscribeDate) {
                        $scope.fund.prodSubscribeDate = $sce.trustAsHtml($scope.fund.prodSubscribeDate);
                    }
                    if($scope.fund.prodRedeemDate){
                        $scope.fund.prodRedeemDate = $sce.trustAsHtml($scope.fund.prodRedeemDate);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$sce','InfoService'];
    return ctrl;
});