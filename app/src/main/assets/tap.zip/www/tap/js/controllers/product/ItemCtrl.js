define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$state,$stateParams,$filter,$ionicHistory,CommonService,InfoService,HistoryNavChartService) {

        var par = $scope.param = new Array();
        par.chartConfig = HistoryNavChartService.historyYieldChart();

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.fund = {};
            par.duration_detail = false; //是否显示期限详情
            par.show_chart = false; //是否展示走势图
            par.contentId = $stateParams['contentId'];
            par.title = '--';

            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        $scope.onBackKeyDown = function(){
            if($scope.param.duration_detail) {
                $scope.param.duration_detail = false;
                par.title = $scope.fund.prodName;
            } else {
                $ionicHistory.goBack();
            }
        };

        function init(){
            //获取cms基金详情
            return InfoService.getFundGeneral(par.contentId).then(function(data){
                if(data){
                    $scope.fund = data;
                    par.title = $scope.fund.prodName;
                    var prodProfitMode= $scope.fund.prodProfitMode;
                    if("0"==prodProfitMode){
                        //绘制七日年化走势图
                        par.show_chart = true;
                        drawChart($scope.fund.prodCode);
                    }else if("1"==prodProfitMode){
                        $state.go("tab.product-item-QDII", {contentId : $scope.fund.contentId});
                    }else if('2,3'.indexOf(prodProfitMode) < 0){
                        CommonService.showConfig({message:"产品收益模式未配置:"+ $scope.fund.prodCode});
                    }
                    if(CommonService.isBuyExperience()){
                        $scope.fund.prodMinSubscribe = $scope.fund.cmsMinSubscribe ? $scope.fund.cmsMinSubscribe : $scope.fund.prodMinSubscribe;
                    }
                    $scope.fund.prodMinSubscribe_show = $filter('prodMinSubscribe')($scope.fund.prodMinSubscribe);
                }
            });
        }

        $scope.showProdDurationDetail = function(){
            if(!CommonService.isStrEmpty($scope.fund.prodDurationExtend)){
                par.title = "期限说明";
                par.duration_detail = true;
            }
        };

        function drawChart(code){
            InfoService.getHistoryYield(code,20).then(function(data){
                if(data){
                    //绘制七日年化走势图
                    par.chartConfig = HistoryNavChartService.historyYieldChart(data);
                }
            });
        };
    }

    ctrl.$inject = ['$scope','$state','$stateParams','$filter','$ionicHistory','CommonService','InfoService','HistoryNavChartService'];
    return ctrl;
});