define(function () {
    'use strict';

    function ctrl($scope,$q,InfoService,HistoryNavChartService) {

        $scope.channel = {};
        $scope.goldChartConfig = HistoryNavChartService.historyIndexChart(null);

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            return $q.all([queryIndexProfit(), queryHistoryIndex(), queryContentBriefs()]);
        }


        //查询指数收益率
        function queryIndexProfit(){
            var p = InfoService.getIndexProfit($scope.channel.title);
            p.then(function(data){
                if(data){
                    $scope.gold = data[0];
                }
            });
            return p;
        }

        //绘制走势图
        function queryHistoryIndex(){
            var p = InfoService.getHistoryIndex($scope.channel.title,60);
            p.then(function(data){
                if(data){
                    //画收盘走势图
                    $scope.goldChartConfig = HistoryNavChartService.historyIndexChart(data);
                    $scope.data_date = data[data.length - 1].date;
                }
            });
            return p;
        }

        //查询基金概况
        function queryContentBriefs(){
            var p = InfoService.getContentBriefs($scope.channel.channelId,1);
            p.then(function(data){
                if(data){
                    $scope.funds = data;
                }
            });
            return p;
        }

    }

    ctrl.$inject = ['$scope','$q','InfoService','HistoryNavChartService'];
    return ctrl;
});