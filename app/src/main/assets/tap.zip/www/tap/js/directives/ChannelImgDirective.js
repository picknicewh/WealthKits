/**
 * Created by wang on 2015-10-15.
 * 栏目图片
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function (InfoService) {
        return {
            restrict: "E",
            replace : true,
            template: '<div class="promo"><img ng-src="{{channel.imgSrc}}" alt="{{channel.imgAlt}}"/></div>',
            link: function(scope, element, attrs) {
                var channelId;
                if(attrs["channelId"]) {
                    channelId = attrs["channelId"];
                } else {
                    channelId = scope.channel.channelId;
                }

                if(channelId) {
                    getChannelInfos(channelId, scope);
                } else {
                    scope.$watch("channel.channelId", function(newValue, oldValue){
                        if(newValue) {
                            getChannelInfos(newValue, scope);
                        }
                    });
                }
            }
        }

        function getChannelInfos(channelId, scope){
            InfoService.getChannelInfos(channelId).then(function(data){
                if(data){
                    var channel = data[0];
                    scope.channel.imgSrc = channel.content_img;
                    scope.channel.imgAlt = channel.channel_name;
                    scope.channel.channel_name = channel.channel_name;
                    scope.channel.description = channel.description;
                }
            });
        }
    };

    directive.$inject = ['InfoService'];
    return directive;
});