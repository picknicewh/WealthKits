define(['angular'], function (angular) {
    "use strict";

    var directive = function ($rootScope) {
        return {
            restrict:'AE',
            link:function($scope){
                $rootScope.hideTabs = 'tabs-item-hide';
                $scope.$on('$destroy',function(){
                    $rootScope.hideTabs = ' ';
                });

            }
        }
    };

    directive.$inject = ['$rootScope'];
    return directive;
});