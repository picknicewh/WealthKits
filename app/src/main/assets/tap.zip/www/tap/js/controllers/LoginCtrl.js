define(function () {
    'use strict';

    function ctrl($rootScope,$scope,$state,$stateParams,DictionaryService,$ionicLoading,
                  $ionicHistory,CommonService,LocalCacheService,ConcernService,WebService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.login.password = null;
            init();
        });

        function init(){
            //alert($rootScope.ip+'ipipipipip');
          //  alert($stateParams["fromParams"]+'fromParams');
         //   alert(JSON.parse($stateParams["toParams"]).name+'$stateParams["toParams"]111111111111');
           // $rootScope.log_out1();
            $scope.login.account_content = JSON.parse($stateParams["toParams"]).name;

            $scope.from_token = JSON.parse($stateParams["toParams"]).token;

            $scope.from_key = JSON.parse($stateParams["toParams"]).key;

            console.log($scope.from_token+ $scope.from_key+ $scope.login.account_content);
            $scope.branchs = DictionaryService.getBranchs();

            //公告获取
            WebService.getNotice("index").then(function (notice) {
                if (notice.error_no == 0 && notice.isColsed != 1 && notice.title && notice.content) {
                    CommonService.showNotice(notice.title + "&&" + notice.content, "tf_system_notice_show");
                }
            });
            // btn_s1 理财体验活动新增 可以直接买基金
            $scope.openUrl = "#/open-prepare/"+$scope.login.account_content+"/"+$scope.from_token+"/"+$scope.from_key;
            if(CommonService.isBuyExperience()) {
                $scope.openUrl = "#/open-prepare/"+$scope.login.account_content+"/"+$scope.from_token+"/"+$scope.from_key;
            }

            var user = LocalCacheService.getUser();
            if(user) {
                var from = $stateParams["from"];
                if(from && from != "login"){
                    $state.go(from, angular.fromJson($stateParams["fromParams"]));
                } else {
                    $state.go("tab.account-index");
                }
            }
        }

        $scope.login = function (){

            var account_content = $.trim($scope.login.account_content);
            var password =$.trim($scope.login.password);
            if("" == account_content || "" == password){
                CommonService.showAlert({message:"请输入账号和密码"});
            }
            if($("#image_code").size() > 0 && "" == $.trim($("#image_code").val())){
                CommonService.showAlert({message:"请输入验证码"});
            }
            if(phoneRegex.test(account_content)){
                loginEvent();
            }else{
                if($scope.branchs == ""){
                    CommonService.showAlert({message:"营业部信息获取失败，请重试"});
                }else{
                    var isAccount = false;
                    var branArr = $scope.branchs.split(",");
                    for(var i=0;i<branArr.length;i++){
                        var branch_no = branArr[i];
                        if(!isNaN(account_content) && account_content.indexOf(branch_no) == 0){
                            loginEvent();
                            isAccount = true;
                            break;
                        }
                    }
                    if(!isAccount){
                        CommonService.showAlert({message:"手机号或客户号输入有误！"});
                    }
                }
            }

        };

        function loginEvent(){
            var params = buildParams();
            $ionicLoading.show();
            //登陆请求
            console.log('发送登录请求');
            WebService.login(params).then(
                function(data){
                    if(typeof Messenger != 'undefined') {
                        Messenger.sendMsg("ym_profileSignIn",{PUID: $scope.login.account_content} ,null,null);
                    }
                   // console.log(JSON.stringify(data)+'data333333333333333333');
                    var user = {};
                    user.token = data.token;
                    LocalCacheService.setUser(user);
                    WebService.getUserInfo().then(
                        function (result){
                            LocalCacheService.setUser(result);
                            $ionicLoading.hide();
                            WebService.qryConduitInfo({mobile_tel: result.mobile_tel}).then(function(data){
                                //用户有渠道信息 包没渠道号
                                if(!CommonService.isStrEmpty(data.conduit_no)
                                    && CommonService.isStrEmpty(LocalCacheService.getRecommendInfos())){
                                    LocalCacheService.setRecommendInfos(data.conduit_no);
                                }
                            });

                            var to = $stateParams["to"];
                     //       alert(to+'to');

                            if(to && to.indexOf("open-") == -1){
                                $state.go(to, angular.fromJson($stateParams["toParams"]));

                            } else if(sessionStorage["login_next_page"]){
                                var next_url = sessionStorage["login_next_page"];
                                $state.go(next_url);
                            } else if($ionicHistory.backView() && $ionicHistory.backView().stateName.indexOf("open-") == -1) {
                                $ionicHistory.goBack();
                            } else {
                                $state.go("tab.account-index");
                            }
                        }, function(result){
                            LocalCacheService.removeUser();
                            CommonService.showConfig({message:"获取用户信息失败"});
                        }
                    )
                }
            );
            //同步用户关注信息
            WebService.syncUserCare(params);
        }

        var phoneRegex = /^1[0-9][0-9]\d{8}$/;

        function buildParams(){
            var params = {};
            var account_content = $.trim($scope.login.account_content);
            $.extend(params,{account_content:account_content,password:$.trim($scope.login.password)});
            var input_content = "1";
            if (phoneRegex.test(account_content)){
                input_content = "b";
            }
            $.extend(params,{input_content:input_content});
            if($("#image_code").size() > 0){
                $.extend(params,{image_code:$("#image_code").val()});
            }

            $.extend(params,{cares_str:ConcernService.getConcernList()});
            return params;
        }

        $scope.close_android = function(){
            Messenger.send('close');
        };

        $scope.onBackKeyDown = function () {
//            var from = $stateParams["from"];
            if($.cookie("back_url_2") || ($.cookie("_r_u_l") && $.cookie("_r_u_l").indexOf("from=2") !=-1)) {
                Messenger.send("close");
            } else if(CommonService.isBuyExperience()) { //理财体验活动
                var to_state = LocalCacheService.get("lcty_state");
                $state.go(to_state.stateName, to_state.stateParams);
            }else if($ionicHistory.backView() && "sessionOut" != $stateParams["w"]) {
                $ionicHistory.goBack();
            } else {
                $state.go("tab.index");
            }
        };
    }

    ctrl.$inject = ['$rootScope','$scope','$state','$stateParams','DictionaryService','$ionicLoading',
        '$ionicHistory','CommonService','LocalCacheService','ConcernService','WebService'];
    return ctrl;
});