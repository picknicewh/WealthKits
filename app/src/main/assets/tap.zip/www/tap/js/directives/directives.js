/*global define */

define(function (require) {

    'use strict';

    var angular = require('angular'),
        services = require('services/services'),
        directives = angular.module('app.directives', ['app.services']);


    directives.directive('backButton', require('directives/BackButtonDirective'));
    directives.directive('exitButton', require('directives/ExitButtonDirective'));
    
    directives.directive('appVersion', require('directives/VersionDirective'));
//    directives.directive('hideTabs', require('directives/HideTabsDirective'));
    directives.directive('buyButton', require('directives/BuyButtonDirective'));
    directives.directive('sellButton', require('directives/SellButtonDirective'));
    directives.directive('concern', require('directives/ConcernDirective'));
    directives.directive('channelImg', require('directives/ChannelImgDirective'));
    directives.directive('digitalKeyboard', require('directives/DigitalKeyboardDirective'));
    directives.directive('accessRecord', require('directives/AccessRecordDirective'));
//    directives.directive('tfNavDirection', require('directives/TfNavDirectionDirective'));


    return directives;
});