define(function () {
    'use strict';

    function ctrl($scope,$ionicPopup,LocalCacheService,InfoService,HistoryNavChartService) {

        $scope.channel = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.showAds();
            init();
        });


        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            $scope.charts = new Array();
            var indexCodes = $scope.channel.title.split(",");
            indexCodes.forEach(function(indexCode){
                $scope.charts[indexCode] = {};
                $scope.charts[indexCode].config = HistoryNavChartService.historyIndexChart(null);

            });
            //查询产品收益
            $scope.indexJson = new Array();
            return queryIndexProfit();
        }

        $scope.showAds = function(type){
            InfoService.getAdSpace($scope.channel.adId).then(function(data){
                if(data) {
                    $scope.ads = data;
                    var adKey = "ad_" + $scope.channel.adId;
                    if((type || !LocalCacheService.get(adKey)) && $scope.ads.length > 0) {
                        var myPopup = $ionicPopup.show({
                            cssClass: 'popup-head-hide ',
                            templateUrl: "product/ads.html",
                            scope: $scope,
                            buttons: [
                                { text: '确定' }
                            ]
                        });
                        LocalCacheService.set(adKey, true);
                    }
                }
            });
        }

        function queryIndexProfit(){
            return InfoService.getChildChannelInfos($scope.channel.channelId).then(function(data){
                if(data){
                    for(var i=0; i< data.length; i++) {
                        var channel = data[i];
                        var channelJson = {};
                        channelJson.channelId = channel.channel_id;
                        channelJson.title = channel.title;
                        channelJson.titleImg = channel.title_img;
                        channelJson.name = channel.channel_name;
                        channelJson.description = channel.description;
                        channelJson.rrInSingleYear = "";
                        channelJson.rrInSixMonth = "";
                        channelJson.funds = new Array();
                        channelJson.isOpen = false; // 是否展开
                        $scope.indexJson.push(channelJson);
                    }
                    InfoService.getIndexProfit($scope.channel.title).then(function(data){
                        if(data){
                            //对指数栏目数据排序
                            sortIndexChannel(data);
                            //控制基金概况html
                            controlConHtml();
                        }
                    });
                }
            });
        }

        $scope.openItem = function($index, isChart){
            var item = $scope.indexJson[$index];
            var isOpen = item.isOpen;
            if(isOpen) {
                item.isOpen = false;
            } else{
                for(var i=0; i< $scope.indexJson.length; i++) {
                    var channelJson = $scope.indexJson[i];
                    if(i == $index) {
                        channelJson.isOpen = true;
                    } else {
                        channelJson.isOpen = false;
                    }
                }
                if(isChart) {
                    controlIndexChart(item.title);
                }
            }
        };

        var sortIndexChannel = function(data){
            for(var i=0;i<data.length;i++){
                var fund = data[i];
                var indexJson = $scope.indexJson;
                for(var j=0;j<indexJson.length;j++){
                    if(indexJson[j].title == fund.indexCode){
                        indexJson[j].rrInSingleYear = fund.rrInSingleYear;
                        indexJson[j].rrInSixMonth = fund.rrInSixMonth;
                    }
                }
            }
            $scope.indexJson = indexJson.sort(function(a, b){ return parseFloat(a.rrInSingleYear) > parseFloat(b.rrInSingleYear) ? -1 : 1;});
        };

        var controlConHtml = function(){
            InfoService.getContentBriefs($scope.channel.channelId, 2).then(function(data){
                if(data){
                    for(var i=0;i<data.length;i++){
                        var fund = data[i];
                        var indexJson = $scope.indexJson;
                        for(var j=0;j<indexJson.length;j++){
                            if(indexJson[j].channelId == fund.channelId){
                                indexJson[j].funds.push(fund);
                            }
                        }
                    }
                }
            });
        };

        function controlIndexChart(indexCode){
            InfoService.getHistoryIndex(indexCode,60).then(function(data){
                if(data){
                    //画收盘走势图
                    $scope.charts[indexCode].config = HistoryNavChartService.historyIndexChart(data);
                    $scope.charts[indexCode].date = data[data.length - 1].date;
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$ionicPopup','LocalCacheService','InfoService','HistoryNavChartService'];
    return ctrl;
});