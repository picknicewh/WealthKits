define(function () {
    'use strict';

    function ctrl($scope) {

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            if(typeof(Messenger) != "undefined" ) {
                Messenger.request('shellVersion', onShellVersion, null);
            }
        }

        function onShellVersion(info) {
            $scope.version = info.version;
        }

    }

    ctrl.$inject = ['$scope','WebService','CommonService'];
    return ctrl;
});