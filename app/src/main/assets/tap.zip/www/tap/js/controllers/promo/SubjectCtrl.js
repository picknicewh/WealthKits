define(function () {
    'use strict';

    function ctrl($scope, $stateParams, $filter, InfoService) {

        $scope.channel = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.sub = $stateParams["sub"];
            $scope.channel.channelId = $stateParams["id"];

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            //查询产品信息
            InfoService.getContentBriefs($scope.channel.channelId ,1).then(function(data){
                if(data){
                    $scope.items = data;
                    for(var i=0;i<$scope.items.length;i++){
                        var fund = $scope.items[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope', '$stateParams','$filter', 'InfoService'];
    return ctrl;
});