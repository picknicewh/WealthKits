define(function () {
    'use strict';

    function ctrl($scope,$state) {

        $scope.onBackKeyDown = function(){
            $state.go("tab.index");
        };
    }

    ctrl.$inject = ['$scope','$state'];
    return ctrl;
});