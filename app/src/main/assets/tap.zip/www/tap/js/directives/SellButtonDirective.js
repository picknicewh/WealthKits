/**
 * Created by wang on 2015-10-14.
 * 卖出按钮
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function ($state, CommonService, WebService) {
        return {
            restrict: "A",
            link: function( scope, element, attrs) {
                element.bind( "click", function() {
                    goSellHtml(attrs["allotNo"], attrs["prodCode"], attrs["prodSource"]);
                });
            }
        }

        function goSellHtml(allot_no, prod_code, prodSource) { //跳转到卖出页面
            var type = "pay_redeem";
            if (prodSource == 0 || prodSource == 1) {
                type = "pay_redeem";
            } else if (prodSource == 2) {
                type = "deposit_redeem";
            }
            WebService.getNotice(type).then(function (notice) {
                if (notice.error_no == 0) {
                    if (notice.title && notice.content) {
                        CommonService.showNotice(notice.title + "&&" + notice.content);
                    } else {
                        $state.go("trade-sell",{allotNo:allot_no, prodCode: prod_code,prodSource: prodSource});
                    }
                }
            });

        }
    };

    directive.$inject = ['$state','CommonService', 'WebService'];
    return directive;
});