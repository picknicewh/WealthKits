/**
 * Created by wang on 2015-9-22.
 * 最小份额显示
 */
define(['angular'], function (angular) {
    "use strict";

    var filter = function ($sce) {

        return function (text, type) {

            if (null == text || "undefined" == typeof(text) || "" == text) {
                return "--";
            } else {
                if(type == 2) {
                    var prodMinSubscribe = parseFloat(text);
                    if (prodMinSubscribe == 0) {
                        return "0.01元";
                    } else if (prodMinSubscribe < 1) {
                        return prodMinSubscribe.toFixed(2) + "元";
                    } else if (prodMinSubscribe < 10000) {
                        return prodMinSubscribe.toFixed(0) + "元";
                    } else {
                        return prodMinSubscribe.toFixed(0) / 10000 + "万元";
                    }
                } else {
                    var prodMinSubscribe = parseFloat(text);
                    if (prodMinSubscribe == 0) {
                        return "0.01<sub>元</sub>";
                    } else if (prodMinSubscribe < 1) {
                        return prodMinSubscribe.toFixed(2) + "<sub>元</sub>";
                    } else if (prodMinSubscribe < 10000) {
                        return prodMinSubscribe.toFixed(0) + "<sub>元</sub>";
                    } else {
                        var unit = "<sub>万元</sub>";
                        if(type == 3){
                            unit = "<sub>万元起</sub>";
                        }
                        return prodMinSubscribe.toFixed(0) / 10000 + unit;
                    }
                }
            }
        };
    };

    filter.$inject = ['$sce'];
    return filter;
});