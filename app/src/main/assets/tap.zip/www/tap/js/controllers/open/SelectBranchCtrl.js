define(function () {
    'use strict';

    function ctrl($scope,$state,$stateParams,$ionicLoading,LocalCacheService,CommonService,WebService) {
        var enable_province = ',';

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            par.branch= [];
            par.branch_data = [];
            par.province_data = [];
            par.default_branch = $stateParams['default_branch'];

            init();
        });

        function init(){
            //营业部查询
            WebService.qryBranch().then(
                function(data){
                    for(var i=0;i<data.length;i++){
                        var branch = data[i];
                        par.branch.push({"text": branch.branch_name, "val": branch.branch_no,"province_no": branch.province_no});
                        if(enable_province.indexOf(','+branch.province_no+',') < 0){
                            enable_province += branch.province_no + ',';
                        }
                        par.branch_data = par.branch;
                    }
                    //默认营业部
                    defaultBranch();
                    //查询省份数据
                    queryProvince();
                }
            );
        }

        function defaultBranch(){
            if(!CommonService.isStrEmpty(par.default_branch)){
                for(var i=0;i<par.branch_data.length;i++){
                    var branch = par.branch_data[i];
                    if(branch.val == par.default_branch){
                        par.branch_no = par.default_branch;
                        par.province_no = branch.province_no;
                    }
                }
            }
        }

        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };

        function queryProvince(){
            WebService.qryProvince().then(
                function(data){
                    for(var i=0;i<data.length;i++){
                        var province = data[i];
                        if(enable_province.indexOf(","+province.province_no+",") > -1){
                            par.province_data.push({"text": province.province_name, "val": province.province_no});
                        }
                    }
                }
            );
        }

        $scope.provinceChange = function(){
            par.branch_data = [];
            for(var i=0;i<par.branch.length;i++){
                if(par.branch[i].province_no == par.province_no){
                    par.branch_data.push(par.branch[i]);
                }
            }
        };

        $scope.branchChange = function(){
            for(var i=0;i<par.branch_data.length;i++){
                if(par.branch_data[i].val == par.branch_no){
                    par.province_no = par.branch_data[i].province_no;
                }
            }
        };

        $scope.submitBranch = function(){
            if(CommonService.isStrEmpty(par.branch_no)){
                CommonService.showAlert({message:"您还未选择营业部!"});
            }else{
                $ionicLoading.show();
                var params = {branch_no: par.branch_no};
                WebService.selectBranch(params).then(
                    function(data){
                        WebService.getCurrentOpenUser().then(
                            function(result){
                                LocalCacheService.setOpenUser(result);
                                $ionicLoading.hide();
                                $state.go("open-uploadID");
                            }
                        )
                    }
                );
            }
        };
    }

    ctrl.$inject = ['$scope','$state','$stateParams','$ionicLoading','LocalCacheService','CommonService','WebService'];
    return ctrl;
});