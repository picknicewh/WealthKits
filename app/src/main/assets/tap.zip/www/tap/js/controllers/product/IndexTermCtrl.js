define(function () {
    'use strict';

    function ctrl($scope,$ionicPopup,$q,LocalCacheService,InfoService,HistoryNavChartService) {

        $scope.channel = {};
        $scope.vm = {};
        $scope.vm.activeTab=1;
        $scope.csi300ChartConfig = HistoryNavChartService.historyIndexChart();

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            })
        };

        function init(){
            $scope.showAds();
            return $q.all([queryIndexProfit(), queryCSI300Index(), queryContentBriefs()])
        }

        $scope.showAds = function(type){
            InfoService.getAdSpace($scope.channel.adId).then(function(data){
                if(data) {
                    $scope.ads = data;
                    var adKey = "ad_" + $scope.channel.adId;
                    if((!LocalCacheService.get(adKey) || type) && $scope.ads.length > 0) {
                        var myPopup = $ionicPopup.show({
                            cssClass: 'popup-head-hide ',
                            templateUrl: "product/ads.html",
                            scope: $scope,
                            buttons: [
                                { text: '确定' }
                            ]
                        });
                        LocalCacheService.set(adKey, true);
                    }
                }
            });
        }

        //查询指数收益率
        function queryIndexProfit(){
            var p = InfoService.getIndexProfit($scope.channel.title);
            p.then(function(data){
                if(data){
                    $scope.index = data[0];
                }
            });
            return p;
        }

        //绘制沪深300走势图
        function queryCSI300Index(){
            var p = InfoService.getHistoryIndex($scope.channel.title,60);
            p.then(function(data){
                if(data){
                    //画收盘走势图
                    $scope.csi300ChartConfig = HistoryNavChartService.historyIndexChart(data);
                    $scope.data_date = data[data.length - 1].date;
                }
            });
            return p;
        }

        //获取营地基金概况
        function queryContentBriefs(){
            var p = InfoService.getContentBriefs($scope.channel.channelId,2);
            p.then(function(data){
                if(data){
                    $scope.funds = data;
                }
            });
            return p;
        }

    }

    ctrl.$inject = ['$scope','$ionicPopup','$q','LocalCacheService','InfoService','HistoryNavChartService'];
    return ctrl;
});