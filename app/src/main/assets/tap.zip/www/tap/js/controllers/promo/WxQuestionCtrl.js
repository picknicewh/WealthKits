define(function () {
    'use strict';

    function ctrl($scope,$ionicLoading,CommonService,$ionicScrollDelegate,WebService) {

        $scope.wx = {};
        $scope.wx.isSuccess = false;

        $scope.submitPaper = function (){
            if(checkInput()){
                $ionicLoading.show();
                var answer1 = $scope.wx.q1;
                var answer2 = $scope.wx.q2;
                var answer3 = $scope.wx.client_name + '^' + $scope.wx.client_id + '^' + $scope.wx.client_mobile;
                var answer4 = $scope.wx.recommend_name + '^' + $scope.wx.recommend_id + '^' + $scope.wx.recommend_mobile;
                var paper_answer = "1&" + answer1 + '|2&' + answer2 + '|3&' + answer3 + '|4&' + answer4;

                WebService.submitChannelRiskPaper({client_id:$scope.wx.client_id,source:"weixin",
                    conduit_no:"weixin",answer_content:paper_answer, paper_id: "230"}).then(
                    function (data){
                        $ionicLoading.hide();
                        $scope.wx.isSuccess = true;
                        $ionicScrollDelegate.scrollTop();
                    }
                );
            }
        };

        function checkInput(){
            if(!$scope.wx.q1){
                CommonService.showAlert({message:"请选择问题1"});
                return false;
            }
            if(!$scope.wx.q2){
                CommonService.showAlert({message:"请选择问题2"});
                return false;
            }
            if(CommonService.isStrEmpty($scope.wx.client_name)){
                CommonService.showAlert({message:"请填写客户姓名"});
                return false;
            }
            var client_id = $scope.wx.client_id;
            if(CommonService.isStrEmpty(client_id)){
                CommonService.showAlert({message:"请填写客户号"});
                return false;
            }
            var client_mobile = $scope.wx.client_mobile;
            if(CommonService.isStrEmpty(client_mobile)){
                CommonService.showAlert({message:"请填写开户手机号"});
                return false;
            }
            if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$", client_mobile)) {
                CommonService.showAlert({message: "开户手机号格式错误"});
                return false;
            }
            if(CommonService.isStrEmpty($scope.wx.recommend_name)){
                CommonService.showAlert({message:"请填写推荐人姓名"});
                return false;
            }
            var recommend_id = $scope.wx.recommend_id;
            if(CommonService.isStrEmpty(recommend_id)){
                CommonService.showAlert({message:"请填写推荐人客户号"});
                return false;
            }
            var recommend_mobile = $scope.wx.recommend_mobile;
            if(CommonService.isStrEmpty(recommend_mobile)){
                CommonService.showAlert({message:"请填写推荐人手机号"});
                return false;
            }
            if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$", recommend_mobile)) {
                CommonService.showAlert({message: "推荐人手机号格式错误"});
                return false;
            }
            if(client_id == recommend_id){
                CommonService.showAlert({message: "推荐人客户号不能与开户客户号相同"});
                return false;
            }
            if(client_mobile == recommend_mobile){
                CommonService.showAlert({message: "推荐人手机号不能与开户手机号相同!"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$ionicLoading','CommonService','$ionicScrollDelegate','WebService'];
    return ctrl;
});