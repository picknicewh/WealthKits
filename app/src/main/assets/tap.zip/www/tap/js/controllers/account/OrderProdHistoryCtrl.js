define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$state,$timeout,$stateParams,$ionicScrollDelegate,WebService,CommonService) {

        var par = $scope.param = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast('scroll.refreshComplete');
        };

        function init() {

            $scope.dateMap = new Object();
            $scope.dates = new Array();

            par.prodCode = $stateParams["prodCode"];
            par.prodSource = $stateParams["prodSource"];
            par.trans_account = $stateParams["trans_account"];

            //匹配月份进行显示
            WebService.queryOrdersByProd(par.prodCode, par.prodSource, par.trans_account).then(
                function (data) {
                    groupWithmonth(data);
                }
            );
        }

        function groupWithmonth(data){
            for (var i = data.length-1; i >= 0; i--) {
                var time = data[i].entrust_time;
                var date = time.substr(0,4) + "年" + time.substr(4,2) + "月";
                if($scope.dateMap[date] == null || typeof($scope.dateMap[date]) == "undefined"){

                    $scope.dateMap[date] = new  Array();
                    if(i == data.length-1){
                        $scope.dateMap[date].isExpand = true;
                    }
                    $scope.dates.push(date);
                }
                var record = data[i];
                $scope.dateMap[date].push(getHtml(record));
            }
        }

        function getHtml(record){
            var flag = record.current ? "1" : "0";
            //废单没有详情页
            if(("1,2".indexOf(record.prodSource) > -1 && '9' != record.entrust_status) || ("0" == record.prodSource && "3" != record.entrust_status)){
                record.url = '#/tab/account-orderDetail?allotNo='+record.allot_no+'&&prodSource='+record.prodSource+'&&isCurrent='+flag;
            }
            //三方支付废单原因查询
            if("1,2".indexOf(record.prodSource) > -1 && '9' == record.entrust_status && record.pay_kind == 1) {
                record.url = '#/tab/account-orderDetail?co_serial_no='+ record.co_serial_no +'&allotNo='+record.allot_no+'&&prodSource='+record.prodSource+'&&isCurrent='+flag;
            }
            record.entrust_time = CommonService.formatTime(record.entrust_time);

            if("V,7,8,Q".indexOf(record.entrust_status) > -1){
                record.success_class = "succeed";
            }else if("0,1,2".indexOf(record.entrust_status) > -1){
                record.success_class = "";
            }else{
                record.success_class = "failed";
            }
            return record;
        }
    }

    ctrl.$inject = ['$scope','$state','$timeout','$stateParams','$ionicScrollDelegate','WebService','CommonService'];
    return ctrl;
});