define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$ionicLoading,$ionicHistory,CommonService,WebService) {

        //防重复提交
        var isUnbinding = false;

        var par = $scope.param = {};
        par.unbind = true;
        par.bank_no = $stateParams["bank_no"];
        par.bank_account = $stateParams["bank_account"];
        par.bank_account_msg = par.bank_account.substr(par.bank_account.length-4);
        par.bank_name = decodeURI($stateParams["bank_name"]);
        par.bank_msg = par.bank_name + "（尾号" + par.bank_account_msg +"）";

        $scope.onBackKeyDown = function(){
            $ionicHistory.goBack();
        };

        $scope.unbindBank = function(){
            if (checkPwd() && !isUnbinding) {
                $ionicLoading.show();
                isUnbinding = true;
                WebService.unbindBank(par.bank_no, par.bank_account, par.password).then(
                     function (result) {
                        $ionicLoading.hide();
                        par.unbind=false;
                        par.success=true;
                    },
                    function (result) {
                        $ionicLoading.hide();
                        par.error_info=CommonService.getErrorInfo(result);
                        par.unbind=false;
                        par.success=false;
                    }
                );
            }
        };

        function checkPwd (){
            if(!CommonService.checkRegex("^[0-9]{6}$",par.password)){
                CommonService.showAlert({message:'请输入6位资金密码!'});
                return false;
            }
            return true;
        }
    }
    ctrl.$inject = ['$scope','$stateParams','$ionicLoading','$ionicHistory','CommonService','WebService'];
    return ctrl;
});