/*global define, console */

define(['angular','store'], function (angular, store) {
    "use strict";

    var factory = function ($location, $http, $rootScope) {

        var storeWithExpiration = {
            set: function(key, val, exp) {
                store.set(key, { val:val, exp:exp, time:new Date().getTime() })
            },
            get: function(key) {
                var info = store.get(key);
                if (!info) { return null }
                if (new Date().getTime() - info.time > info.exp) { return null }
                return info.val
            }
        };

        return {
            setRecommendInfos : function(recommendInfos){  //渠道号设置
                if(recommendInfos) {
                    if(recommendInfos.length > 5) {
                        recommendInfos = recommendInfos.substr(0, 5);
                    }
                    store.set('recommendInfos', recommendInfos);
                }
            },
            getRecommendInfos : function(){ //渠道号获取
                var recommendInfos = store.get('recommendInfos');
                if(recommendInfos && recommendInfos != "" && recommendInfos != "undefined") {
                    return recommendInfos;
                }
                return "";
            },
            setUser : function(user){ //保存用户信息
                var old_user = store.get('user');
                if(null != old_user){
                    user.token = old_user.token;
                }
                store.set('user', user);
            },
            getUser : function(){ //获取用户信息
                return store.get('user');
            },
            removeUser : function() { //删除用户信息
                store.remove('user')
            },
            setOpenUser : function(user){
                store.set('openUser', user);
            },
            getOpenUser : function(){
                return store.get('openUser');
            },
            removeOpenUser : function() {
                store.remove('openUser');
            },
            set : function(key, value) {
                store.set(key, value);
            },
            get : function(key) {
                return store.get(key);
            },
            remove : function(key) {
                store.remove(key)
            }
        }
    };

    factory.$inject = ['$location', '$http', '$rootScope'];
    return factory;
});