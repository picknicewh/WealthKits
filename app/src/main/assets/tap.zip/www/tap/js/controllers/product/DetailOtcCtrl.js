define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$stateParams,$sce,InfoService) {

        var par = $scope.param = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            par.contentId = $stateParams['contentId'];
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            })
        };


        function init(){
            //获取cms基金明细
            return InfoService.getOTCDetail(par.contentId).then(function(data){
                if(data){
                    $scope.fund = data;
                   //根据产品状况，控制按钮
                    if("0,3".indexOf($scope.fund.prodStatus) > -1){
                        if("1" == $scope.fund.otcStatus){
                            $scope.fund.sellStatus = 1; // 可购买
                        }else if("2,3".indexOf($scope.fund.otcStatus) > -1){
                            $scope.fund.sellStatus = 3; // 已售罄
                        }else{
                            $scope.fund.sellStatus = 2;
                        }
                    }else if("2"==$scope.fund.prodStatus){
                        $scope.fund.sellStatus = 4; //暂停申购
                    }else{
                        if("2,3".indexOf($scope.fund.otcStatus) > -1){
                            $scope.fund.sellStatus = 3;
                        }else{
                            $scope.fund.sellStatus = 5; //暂停交易
                        }
                    }
                    if($scope.fund.prodSubscribeDate) {
                        $scope.fund.prodSubscribeDate = $sce.trustAsHtml($scope.fund.prodSubscribeDate);
                    }
                    if($scope.fund.prodRedeemDate){
                        $scope.fund.prodRedeemDate = $sce.trustAsHtml($scope.fund.prodRedeemDate);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$sce','InfoService'];
    return ctrl;
});