/**
 * Created by wang on 2015-10-16.
 *
 */
define(['angular'], function (angular) {
    "use strict";

    var animation = function ($ionicScrollDelegate, $ionicPosition, $timeout) {

        return {
            addClass: function(elem, done){
                $timeout(function(){
                    var quotePosition = $ionicPosition.position(elem);
                    $ionicScrollDelegate.scrollTo(quotePosition.left, quotePosition.top, true);
                }, 240);
//                var nOfs = elem[0].offsetTop;
//                $ionicScrollDelegate.scrollTo(0, nOfs, true);
//                $("ion-content").animate({scrollTop : nOfs +"px"}, 500)
            },
            removeClass: function(elem, done){
                 $ionicScrollDelegate.scrollTop(true);
//                $("ion-content").animate({scrollTop : "0px"}, 500);
            }
        };
    };

    animation.$inject = ['$ionicScrollDelegate', '$ionicPosition', '$timeout'];
    return animation;
});
