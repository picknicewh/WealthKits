define(function () {
    'use strict';

    function ctrl(LocalCacheService,$scope,$state,$ionicLoading,$ionicModal,$q,CommonService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function(){
            par.econtract_type ='1';
            par.fund_sel = true;
            par.agreement_sel = true;
            par.ta_array = new Array();

            init();
        });
        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };
        function init(){
            //查询多金TA
            WebService.qryDjTa().then(
                function(data){
                    for(var i=data.length-1;i>=0;i--){
                        var ta = data[i];
                        ta.checked=true;
                        par.ta_array.push(ta);
                    }
                }
            );

            createModel();
        }

        function createModel(){
            var deferred = $q.defer();
            if(!$scope.company_modal) {
                $ionicModal.fromTemplateUrl("open/fundCompanyList.html", {
                    scope: $scope,
                    animation: "slide-in-up"
                }).then(function(modal) {
                    $scope.company_modal = modal;
                    deferred.resolve();
                });
            } else {
                deferred.resolve();
            }
            return deferred.promise;
        }


        $scope.closeModal = function() {
            $scope.company_modal.hide();
        };

        $scope.$on("$destroy", function() {
            $scope.company_modal.remove();
        });


        $scope.fundCompanyList = function(){
            $scope.company_modal.show();
        };

        $scope.selFundCompany = function(){
            var flag=false;
            for(var i=0;i<par.ta_array.length;i++){
                if(par.ta_array[i].checked){
                    flag=true;
                }
            }
            if(!flag){
                CommonService.showAlert({message:"请选择至少一个基金公司"});
            }else{
                $scope.company_modal.hide();
            }
        };

        $scope.signAgreement = function(){
            if(checkSelect()){
                $ionicLoading.show();
                var openAct = "";
                for(var i=0;i<par.ta_array.length;i++){
                    if(par.ta_array[i].checked){
                        if(i == 0){
                            openAct += par.ta_array[i].fund_company;
                        }else{
                            openAct += par.ta_array[i].fund_company;
                        }
                    }
                }
                //签署协议
                WebService.saveEcontract().then(
                    function(data){
                        $ionicLoading.hide();
                        $state.go('open-revisitPaper');
                    }
                );
            }
        };

        function checkSelect(){
            if(!par.fund_sel){
                CommonService.showAlert({message:"请勾选《同意开通相关基金账户》"});
                return false;
            }
            if(!par.agreement_sel){
                CommonService.showAlert({message:"请勾选《我已阅读并同意签署相关开户协议》"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['LocalCacheService','$scope','$state','$ionicLoading','$ionicModal','$q','CommonService','WebService'];
    return ctrl;
});