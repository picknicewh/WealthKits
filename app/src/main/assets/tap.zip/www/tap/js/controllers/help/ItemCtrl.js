define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$timeout,$ionicScrollDelegate,WebService, CommonService) {

        var par = $scope.param = {};
        par.id = $stateParams['id'];
        par.type = $stateParams['type'];
        par.selectId =  $stateParams['selectId'];

        init();

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        $scope.expand = function(index){
            $scope.items[index].active = !$scope.items[index].active;
            if($scope.items[index].active){
                for(var i=0; i< $scope.items.length; i++) {
                    if( $scope.items[i].active && i != index){
                        $scope.items[i].active = false;
                    }
                }
            }
            $timeout(function(){
                $ionicScrollDelegate.resize();
            }, 100);
        };

        function init(){
            if(par.type == "content") {
                WebService.wzContent(par.id).then(function(data){
                    selectItem(data);
                    if(data && data.length > 0){
                        par.title = data[0].title;
                    }
                });
            } else {
                WebService.wzContents(par.id, 1).then(function(data){
                    selectItem(data);
                    if(data && data.length > 0){
                        par.title = data[0].channelName;
                    }
                });
            }
        }

        function selectItem(data){
            $scope.items = data;
            var select = false;
            if($scope.items.length > 0) {
                if(par.selectId) {
                    for(var i=0; i< $scope.items.length; i++) {
                        if($scope.items[i].id == par.selectId){
                            $scope.items[i].active = true;
                            select = true;
                        }
                    }
                }
                if(!select) {
                    $scope.items[0].active = true;
                }
            }
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$timeout','$ionicScrollDelegate','WebService', 'CommonService'];
    return ctrl;
});