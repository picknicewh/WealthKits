define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$state,$stateParams,InfoService,HistoryNavChartService) {

        var par = $scope.param = new Array();
        par.contentId = $stateParams['contentId'];
        par.is_index = $stateParams['is_index'];
        if(par.is_index == '1'){
            //画沪深300基金净值走势图
            par.historyNavChartConfig = HistoryNavChartService.historyNavCSI300Chart();
        }else{
            //画累计净值走势图
            par.historyNavChartConfig = HistoryNavChartService.historyNavChart(null);
        }

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.fund = {};

            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            //获取cms基金详情
            return InfoService.getFundGeneral(par.contentId).then(function(data){
                if(data){
                    $scope.fund = data;
                    if("0,2,3".indexOf($scope.fund.prodProfitMode) > -1){
                        $state.go("tab.product-item", {contentId : $scope.fund.contentId});
                    }
                    //画图
                    drawChart($scope.fund.prodCode);
                }
            });
        }

        function drawChart(code){
            if(par.is_index == '1'){
                InfoService.getComparisonData(code,60).then(function(data){
                    if(data){
                        //画沪深300基金净值走势图
                        par.historyNavChartConfig = HistoryNavChartService.historyNavCSI300Chart(data.history_nav,data.CSI300);
                    }
                });
            }else{
                InfoService.getHistoryNav(code,60).then(function(data){
                    if(data){
                        //画累计净值走势图
                        par.historyNavChartConfig = HistoryNavChartService.historyNavChart(data);
                    }
                });
            }
        };
    }

    ctrl.$inject = ['$scope','$state','$stateParams','InfoService','HistoryNavChartService'];
    return ctrl;
});