define(function () {
    'use strict';

    function ctrl($scope,WebService) {

        $scope.items = {};

        init();

        $scope.$on('transferDetailsRefresh', function(d,data) {
            init();
        });

        function init(){
            //查询资金流水
            WebService.queryTransferDetails().then(
                function (data){
                    $scope.items = data;
                }
            );
        }
    }

    ctrl.$inject = ['$scope','WebService'];
    return ctrl;
});