define(function () {
    'use strict';

    function ctrl($rootScope,$scope,$state,$stateParams,$ionicLoading,$ionicModal,$ionicHistory,$q,LocalCacheService,CommonService,WebService) {
        var par = $scope.param = {};
        par.b = $stateParams["b"];//$stateParams["b"]
        par.step= 1;

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.qucik_banks = new Array();
            par.b = $stateParams["b"];
            par.step= 1;
            par.agreement=true;
            par.bind_success=false;
            par.bank_name='请选择银行';
            par.from='open';
            par.to_state ={stateName : "open-signAgreement"};
            $scope.name = $stateParams['name'];
            $scope.token_ = $stateParams['token'];
            $scope.key_ = $stateParams['key'];

            //控制url
            par.from_url = location.href;
            if('2' == par.b) {
                var buy_state = LocalCacheService.get("buy_state"); //购买链接
                if(buy_state) {
                    par.to_state = buy_state;
                } else {
                    par.to_state = LocalCacheService.get("lcty_state");
                }
            }

            init();
        });
        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"];
            }else{
                Messenger.send('close');
            }

        };
        $scope.close_android = function(){
          Messenger.send('close');
        };

        $scope.back_android = function(){
            //alert(1);
            history.back();
        };

        function init(){
            //查询银行列表
            WebService.qeyAllPayBank().then(
                function(data){
                    for(var i=0; i < data.length; i++){
                        $scope.qucik_banks.push(data[i]);
                    }
                }
            );
          //  alert(LocalCacheService.get('selectBank'));

            createModel();
            if(LocalCacheService.get('selectBank')){
                $scope.selectBank2(LocalCacheService.get('selectBank'));
            }

        }

        function createModel(){
            var deferred = $q.defer();
            if(!$scope.bank_modal) {
                $ionicModal.fromTemplateUrl("open/quickBankList.html", {
                    scope: $scope,
                    animation: "slide-in-up"
                }).then(function(modal) {
                    $scope.bank_modal = modal;
                    deferred.resolve();
                });
            } else {
                deferred.resolve();
            }
            return deferred.promise;
        }

        $scope.$on("$destroy", function() {
            $scope.bank_modal.remove();
        });

        $scope.onBackKeyDown = function(){
            $ionicHistory.goBack();
        };

        $scope.closeModal = function() {
            $scope.bank_modal.hide();
        };

        $scope.showBankClick = function(){
            $scope.bank_modal.show();
        };

        $scope.selectBank = function(bank){
            LocalCacheService.set('selectBank',bank);
            par.bank_no = bank.bank_no;
            par.econtract_id = bank.econtract_id;
            console.log(par.econtract_id+'bank_id');
            par.bank_name = bank.bank_name;
            $scope.bank_modal.hide();
        };

        $scope.selectBank2 = function(bank){
            LocalCacheService.set('selectBank',bank);
            par.bank_no = bank.bank_no;
            par.econtract_id = bank.econtract_id;
            console.log(par.econtract_id+'bank_id');
            par.bank_name = bank.bank_name;
           // $scope.bank_modal.hide();
        };

        $scope.bindBankClick = function(){
            //已开户 理财体验 绑定三方支付
            if(CommonService.isStrEmpty(par.b)){
                par.from='manager';
               // alert('yyyyyyyyyyyyy');
            }
            if(checkMsg()){
                $ionicLoading.show();
                //var params = {bank_no:par.bank_no,bank_account: par.bank_account,econtract_id:par.econtract_id};
                var params = {bank_no:par.bank_no,bank_account: par.bank_account,econtract_id:par.econtract_id,from:par.from};
              //  alert(JSON.stringify(params));
                WebService.signBankMsg(params).then(
                    function(data){
                   //     alert(1);
                        var cp = new ChinaPay();
                        cp.auth([data.json], authOK, function(error) {
                            $ionicLoading.hide();
//                            CommonService.showAlert({message: error.msg});
                        });
                    },
                    function(result){
                        $ionicLoading.hide();
                    //    alert(2);
                        if("XCM-300001" == result.error_no) {//显示通知
                            CommonService.showNotice(result.error_info);
                        } else {
                            CommonService.showAlert({message: result.error_info});
                        }
                    }
                );
            }
        };

        $scope.reBind = function(){
            par.step= 1;
            par.agreement=true;
            par.bind_success=false;
            par.bank_name='请选择银行';
            par.bank_no='';
            par.bank_account='';
        };

        function authOK(result){
            //1成功 0 识别
            if("0000" == result.code){
                var params = {bank_no:par.bank_no,bank_account: par.bank_account,bank_name: par.bank_name,from: par.from,
                    fromUrl:par.from_url,toUrl:par.to_state,source:CommonService.getSource(), is_ajax: 'ajax',
                    conduit_no: LocalCacheService.getRecommendInfos()};
                WebService.signSuccess(params).then(
                    function (data){
                        $ionicLoading.hide();
                        if(data.error_info){
                            par.step= 2;
                            par.error_info = data.error_info;
                            console.log('erroeinfo1');
                        }else {
                            if(data.from == "open") { //开户直接跳转下一步
                                $state.go(par.to_state.stateName, par.to_state.stateParams);
                            } else {
                                par.step= 2;
                                par.success_info='快捷支付银行卡：'+data.bank_name+'   尾号<em>'+data.bank_account.substr(data.bank_account.length-4);
                                par.bind_success = true;

                                WebService.getUserQuickBankCards().then(
                                    function (result){

                                  //      alert(JSON.stringify(LocalCacheService.get('data1'))+'jjjjjjjjjjjj');
                                        $.ajax({
                                            type: 'POST',
                                            url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                                            data:{
                                                token:$scope.token_,
                                                secretKey:$scope.key_,
                                                objective:2,
                                                source:1,
                                                values:JSON.stringify(LocalCacheService.get('data1'))
                                            },

                                            dataType : 'json',
                                            //contentType : "application/json",
                                            success : function(data) {
                                                //      alert(JSON.stringify(data)+'111111111111111');
                                                if(data.resultCode!='0'){
                                                    //LocalCacheService.set('error2','has');
                                                    //LocalCacheService.set('errorInfo',data.resultDesc);
                                                    // CommonService.showAlert({message:data.resultDesc});
                                                    $ionicLoading.hide();
                                                }
                                                else{
                                                    //LocalCacheService.set('error2','no');
                                                }
                                                //add_ajax();
                                            },
                                            error : function(XMLHttpRequest, textStatus, errorThrown) {
                                             //      alert(JSON.stringify(XMLHttpRequest, textStatus, errorThrown)+'111111111111111');
                                                alert("系统异常,加载失败1");
                                            }

                                        });



                                    }, function(result){
                                        LocalCacheService.removeUser();
                                        CommonService.showConfig({message:"获取用户信息失败"});
                                    }
                                );

                            }
                            console.log('erroeinfo2');
                        }
                    },
                    function(result){
                        $ionicLoading.hide();
                        CommonService.showNotice(result.error_info);
                    }
                );
            }else{
                $ionicLoading.hide();
                CommonService.showAlert({message: result.msg});
            }
        }

        function checkMsg(){
            if(CommonService.isStrEmpty(par.bank_no)){
                CommonService.showAlert({message:"请选择银行"});
                return false;
            }
            if(CommonService.isStrEmpty(par.bank_account)){
                CommonService.showAlert({message:"请输入银行卡号"});
                return false;
            }
            par.bank_account=CommonService.trim(par.bank_account);
            if(!/^\d{16,19}$/.test(par.bank_account)) {
                CommonService.showAlert({message:"请输入正确银行卡号16-19位"});
                return false;
            }
            if(!par.agreement){
                CommonService.showAlert({message:"请勾选我已阅读并同意签署《天风证券快捷支付协议》"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$rootScope','$scope','$state','$stateParams','$ionicLoading','$ionicModal','$ionicHistory','$q','LocalCacheService','CommonService','WebService'];
    return ctrl;
});