/*global define */

define(['angular'], function (angular) {
	'use strict';

	return angular.module('app.config', [])
		.constant('VERSION', '0.1')
        .constant("BASE_PATH", "http://60.191.5.133:80/tap/v1")
        .constant("WT_BASE_PATH", "/tfzq-web")
        .constant("WZ_BASE_PATH", "/")
        .constant("HELP_CHANNEL_ID", "228")
        .constant("CACHE_MAX_AGE", 60000)
        .constant("PULLING_TEXT", "下拉刷新")
        .constant("REFRESHING_TEXT", "松开并刷新")
        .constant("IP",'http://zhu.hunme.net:8080');//http://slave.openhunme.com
        //.constant("$ionicLoadingConfig",{ template : "请等待..." })
});