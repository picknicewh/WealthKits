define(function (require, exports, module) {
    'use strict';
    var xdate = require('xdate');

    function ctrl($scope,$state,$timeout,$ionicScrollDelegate,WebService,CommonService) {

        var par = $scope.param = new Array();
        par.isExpand0 = true;
        par.isExpand1 = false;
        par.isExpand2 = false;

        //回退固定为账户首页
        $scope.onBackKeyDown = function(){
            $state.go("tab.account-index");
        };

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast('scroll.refreshComplete');
        };

        $scope.expand = function(){
            $timeout(function(){
                $ionicScrollDelegate.resize();
            }, 500);
        };

        function init() {
            $scope.curOrders = new Array();
            $scope.preMon1Orders = new Array();
            $scope.preMon2Orders = new Array();

            par.curMon = '--';
            par.preMon1 = '--';
            par.preMon2 = '--';
            if(localStorage["redirect_url"]) {
                par.redirect_url = localStorage["redirect_url"];
            }
            //查询当前委托
            WebService.queryCurOrders().then(
                function (data){
                    for (var i = 0; i < data.length; i++) {
                        showRecord(data[i],"0");
                    }
                    //查询3个月的历史记录
                    queryHisOrders();
                }
            );
        }

        function queryHisOrders(){
            //匹配日期进行显示
            WebService.queryHisOrders().then(
                function (data) {
                    for (var i = 0; i < data.length; i++) {
                        showRecord(data[i],"1");
                    }
                    if ($scope.curOrders.length == 0) {
                        par.curMon = new XDate(new Date()).toString("yyyy年MM月");
                    }
                }
            );
        }

        function showRecord(record,flag){
            if(record.isCurRecord == '0'){
                if($scope.curOrders.length == 0){
                    var time = record.entrust_time;
                    par.curMon = time.substr(0,4) + "年" + time.substr(4,2) + "月";
                }
                getHtml(record,flag);
                $scope.curOrders.push(record);
            } else if(record.isCurRecord == '1'){
                if($scope.preMon1Orders.length == 0){
                    var time = record.entrust_time;
                    par.preMon1 = time.substr(0,4) + "年" + time.substr(4,2) + "月";
                }
                getHtml(record,flag);
                $scope.preMon1Orders.push(record);
            } else if(record.isCurRecord == '2'){
                if($scope.preMon2Orders.length == 0){
                    var time = record.entrust_time;
                    par.preMon2 = time.substr(0,4) + "年" + time.substr(4,2) + "月";
                }
                getHtml(record,flag);
                $scope.preMon2Orders.push(record);
            }
        }

        function getHtml(record,flag){
            //废单没有详情页
            if(("1,2".indexOf(record.prodSource) > -1 && '9' != record.entrust_status) || ("0" == record.prodSource && "3" != record.entrust_status)){
                record.url = '#/tab/account-orderDetail?allotNo='+record.allot_no+'&&prodSource='+record.prodSource+'&&isCurrent='+flag;
            }
            //三方支付废单原因查询
            if("1,2".indexOf(record.prodSource) > -1 && '9' == record.entrust_status && record.pay_kind == 1) {
                record.url = '#/tab/account-orderDetail?co_serial_no='+ record.co_serial_no +'&allotNo='+record.allot_no+'&&prodSource='+record.prodSource+'&&isCurrent='+flag;
            }
            record.entrust_time = CommonService.formatTime(record.entrust_time);

            if("V,7,8,Q".indexOf(record.entrust_status) > -1){
                record.success_class = "succeed";
            }else if("0,1,2".indexOf(record.entrust_status) > -1){
                record.success_class = "";
            }else{
                record.success_class = "failed";
            }
        }

        $scope.changeUrl = function(url){
            location.href = url;
        };
    }

    ctrl.$inject = ['$scope','$state','$timeout','$ionicScrollDelegate','WebService','CommonService'];
    return ctrl;
});