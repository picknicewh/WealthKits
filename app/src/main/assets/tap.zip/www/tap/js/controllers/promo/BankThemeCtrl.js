define(function () {
    'use strict';

    function ctrl($scope, $filter, InfoService) {
        $scope.term = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.funds = new Array();

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init() {
            //获取营地基金概况并添加事件
            queryContentBriefs();
        }

        function queryContentBriefs(){
            //0: 栏目ID 1：产品分级 2：留取条数
            var str = ($scope.term.channel).split(',');
            //查询并处理产品信息
            InfoService.getContentBriefs(str[0], str[1]).then(function(data){
                if(data){
                    data = bankThemeQus(data);
                    for(var i=0;i<data.length && i< str[2];i++){
                        var fund = data[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                        $scope.funds.push(fund);
                    }
                }
            });
        }

        //银行理财产品追加描述信息
        function bankThemeQus(data){
            data = data.sort((function(a, b){return parseFloat(a.prodDuration) > parseFloat(b.prodDuration) ? -1 : 1;}));
            for (var i=0;i<data.length;i++){
                if(i==0) {
                    data[i].theme_qus = '存钱买房，要求收益安全、稳健？';
                }else if (i==1){
                    data[i].theme_qus = '近半年都不需用，追求安全、省心、方便？';
                }else if (i==2){
                    data[i].theme_qus = '今年市场琢磨不定，想观望一段时间再做定夺？';
                }else if(i==3){
                    data[i].theme_qus = '年终奖到手，待春节后再做打算？';
                }else if(i==4){
                    data[i].theme_qus = '闲钱短期不用，或逃离股市暂时避险？';
                }else{
                    data[i].theme_qus = '';
                }
            }
            data = data.sort((function(a, b){return parseFloat(a.expYearYield) > parseFloat(b.expYearYield) ? -1 : 1;}));
            return data;
        }
    }

    ctrl.$inject = ['$scope','$filter', 'InfoService'];
    return ctrl;
});