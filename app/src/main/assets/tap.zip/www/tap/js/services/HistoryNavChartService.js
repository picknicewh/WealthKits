define(['angular', 'store'], function (angular, store) {
    "use strict";

    var factory = function ($location, $http, $rootScope) {
        return {
            /**
             * 货基七日年化走势图
             * @param divId
             * @param data
             */
            historyYieldChart: function (yield_data) {
                var totalYieldData = [];
                if(yield_data) {
                    for (var i = 0; i < yield_data.length; i++) {
                        totalYieldData.push([
                            parseInt(yield_data[i]['time']),
                            parseFloat(yield_data[i]['yield'])
                        ]);
                    }
                }
                var historyYieldOption = {
                    size: {
                        height: 220
                    },
                    chart: {
                        type: 'line',
                        plotBorderColor: '#868686',
                        plotBorderWidth: 1
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        type: 'datetime',
                        gridLineWidth: 1,
                        dateTimeLabelFormats: {
                            second: '%H:%M:%S',
                            minute: '%H:%M',
                            hour: '%H:%M',
                            day: '%m-%d',
                            week: '%m-%d',
                            month: '%y-%m',
                            year: '%Y年'
                        },
                        labels: {
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    yAxis: [
                        {
                            title: {
                                text: ' '
                            },
                            alternateGridColor: '#F7F7F7',
                            labels: {
                                formatter: function () {
                                    return (this.value).toFixed(2) + '%';
                                },
                                style: {
                                    color: '#000000'
                                }
                            }
                        }
                    ],
                    navigator: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    tooltip: {
                        shared: true,
                        followTouchMove: true,
                        xDateFormat: "%Y-%m-%d",
                        valueDecimal: 2,
                        crosshairs: {
                            width: 2,
                            color: '#9999FF',
                            dashStyle: 'shortdot'
                        },
                        borderColor: '#be8c4b',
                        useHTML: true,
                        formatter: function () {
                            var date = new Date(this.x);
                            var text = '<b>' + date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + '</b>';
                            text += '<br/><font color="' + this.point.series.color + '">七日年化收益率: ' + (this.point.y).toFixed(2) + '%</font>';
                            return text;
                        }
                    },
                    plotOptions: {
                        line: {
                            marker: {
                                enabled: false
                            },
                            lineWidth: 0.75
                        }
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [
                        {
                            type: 'line',
                            color: '#F00',
                            name: '七日年化走势图',
                            marker: {
                                radius: 1,  //曲线点半径，默认是4
                                symbol: 'circle'//曲线点类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
                            },
                            data: totalYieldData
                        }
                    ]
                };

                return historyYieldOption;
            },

            /**
             * 基金净值走势图
             * @param divId
             * @param data
             */
            historyNavChart: function (data) {
                var totalNavData = [];
                if(data){
                    for (var i = 0; i < data.length; i++) {
                        totalNavData.push([
                            parseInt(data[i]['time']),
                            parseFloat(data[i]['totalNav'])
                        ]);
                    }
                }

                var historyNavOption = {
                    size: {
                        height: 180
                    },
                    chart: {
                        type: 'line',
                        plotBorderColor: '#868686',
                        plotBorderWidth: 1
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        type: 'datetime',
                        gridLineWidth: 1,
                        dateTimeLabelFormats: {
                            second: '%H:%M:%S',
                            minute: '%H:%M',
                            hour: '%H:%M',
                            day: '%m-%d',
                            week: '%m-%d',
                            month: '%y-%m',
                            year: '%Y年'
                        },
                        labels: {
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    yAxis: {
                        title: {
                            text: ' '
                        },
                        alternateGridColor: '#F7F7F7',
                        labels: {
                            formatter: function () {
                                return this.value.toFixed(2);
                            },
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    navigator: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    tooltip: {
                        followTouchMove: true,
                        xDateFormat: "%Y-%m-%d",
                        valueDecimal: 2,
                        crosshairs: {
                            width: 2,
                            color: '#9999FF',
                            dashStyle: 'shortdot'
                        },
                        borderColor: '#be8c4b',
                        useHTML: true,
                        formatter: function () {
                            var date = new Date(this.x);
                            var text = '<b>' + date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + '</b>';
                            text += '<br/><font color="' + this.point.series.color + '">累计净值: ' + (this.point.y).toFixed(4) + '元</font>';
                            return text;
                        }
                    },
                    plotOptions: {
                        line: {
                            marker: {
                                enabled: false
                            },
                            lineWidth: 0.75
                        }
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [
                        {
                            type: 'line',
                            color: '#F00',
                            name: '累计净值',
                            marker: {
                                radius: 1,  //曲线点半径，默认是4
                                symbol: 'circle'//曲线点类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
                            },
                            data: totalNavData
                        }
                    ]
                };
                return historyNavOption;
            },

            /**
             * 指数净值走势图
             * @param divId
             * @param data
             */
            historyIndexChart: function (data) {
                var totalIndexData = [];
                if(data) {
                    for (var i = 0; i < data.length; i++) {
                        totalIndexData.push([
                            parseInt(data[i]['time']),
                            parseFloat(data[i]['indexClose'])
                        ]);
                    }
                }

                var historyIndexOption = {
                    size: {
                        width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
                        height: 180
                    },
                    chart: {
                        type: 'line',
                        plotBorderColor: '#868686',
                        plotBorderWidth: 1
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        //ordinal :true ,
                        type: 'datetime',
                        gridLineWidth: 1,
                        dateTimeLabelFormats: {
                            second: '%H:%M:%S',
                            minute: '%H:%M',
                            hour: '%H:%M',
                            day: '%m-%d',
                            week: '%m-%d',
                            month: '%y-%m',
                            year: '%Y年'
                        },
                        labels: {
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    legend: {
                        enabled: false
                    },
                    yAxis: {
                        title: {
                            text: ' '
                        },
                        alternateGridColor: '#F7F7F7',
                        labels: {
                            formatter: function () {
                                return this.value.toFixed(2);
                            },
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    navigator: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    tooltip: {
                        followTouchMove: true,
                        xDateFormat: "%Y-%m-%d",
                        valueDecimal: 2,
                        crosshairs: {
                            width: 2,
                            color: '#9999FF',
                            dashStyle: 'shortdot'
                        },
                        borderColor: '#be8c4b',
                        useHTML: true,
                        formatter: function () {
                            var date = new Date(this.x);
                            var text = '<b>' + date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + '</b>';
                            text += '<br/><font color="' + this.point.series.color + '">收盘指数: ' + (this.point.y).toFixed(2) + '</font>';
                            return text;
                        }
                    },
                    plotOptions: {
                        line: {
                            marker: {
                                enabled: false
                            },
                            lineWidth: 0.75
                        }
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [
                        {
                            type: 'line',
                            color: '#F00',
                            name: '收盘指数',
                            marker: {
                                radius: 1,  //曲线点半径，默认是4
                                symbol: 'circle'//曲线点类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
                            },
                            data: totalIndexData
                        }
                    ]
                };

                return historyIndexOption;
            },

            /**
             * 沪深300 基金净值 整合走势图
             * @param divId
             * @param data
             */
            historyNavCSI300Chart: function (nav_data, CSI300_data) {
                var totalNavData = [];
                var totalCSI300Data = [];
                if(nav_data) {
                    for (var i = 0; i < nav_data.length; i++) {
                        totalNavData.push([
                            parseInt(nav_data[i]['time']),
                            parseFloat(nav_data[i]['growthRate'])
                        ]);
                    }
                }
                if(CSI300_data){
                    for (var i = 0; i < CSI300_data.length; i++) {
                        totalCSI300Data.push([
                            parseInt(CSI300_data[i]['time']),
                            parseFloat(CSI300_data[i]['growthRate'])
                        ]);
                    }
                }

                var historyFundCSI300Option = {
                    size: {
                        height: 220
                    },
                    chart: {
                        type: 'line',
                        plotBorderColor: '#868686',
                        plotBorderWidth: 1
                    },
                    title: {
                        text: ''
                    },
                    xAxis: {
                        type: 'datetime',
                        gridLineWidth: 1,
                        dateTimeLabelFormats: {
                            second: '%H:%M:%S',
                            minute: '%H:%M',
                            hour: '%H:%M',
                            day: '%m-%d',
                            week: '%m-%d',
                            month: '%y-%m',
                            year: '%Y年'
                        },
                        labels: {
                            style: {
                                color: '#000000'
                            }
                        }
                    },
                    legend: {
                        enabled: true
                    },
                    yAxis: [
                        {
                            title: {
                                text: ' '
                            },
                            alternateGridColor: '#F7F7F7',
                            labels: {
                                formatter: function () {
                                    return (this.value * 100).toFixed(1) + '%';
                                },
                                style: {
                                    color: '#000000'
                                }
                            }
                        }
                    ],
                    navigator: {
                        enabled: false
                    },
                    credits: {
                        enabled: false
                    },
                    tooltip: {
                        shared: true,
                        followTouchMove: true,
                        xDateFormat: "%Y-%m-%d",
                        valueDecimal: 2,
                        crosshairs: {
                            width: 2,
                            color: '#9999FF',
                            dashStyle: 'shortdot'
                        },
                        borderColor: '#be8c4b',
                        useHTML: true,
                        formatter: function () {
                            var date = new Date(this.x);
                            var text = '<b>' + date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate() + '</b>';
                            text += '<br/><font color="' + this.points[0].series.color + '">累计净值涨跌幅: ' + (this.points[0].y * 100).toFixed(2) + '%</font>';
                            text += '<br/><font color="' + this.points[1].series.color + '">沪深300涨跌幅: ' + (this.points[1].y * 100).toFixed(2) + '%</font>';
                            return text;
                        }
                    },
                    plotOptions: {
                        line: {
                            marker: {
                                enabled: false
                            },
                            lineWidth: 0.75
                        }
                    },
                    exporting: {
                        enabled: false
                    },
                    series: [
                        {
                            type: 'line',
                            color: '#F00',
                            name: '累计净值',
                            marker: {
                                radius: 1,  //曲线点半径，默认是4
                                symbol: 'circle'//曲线点类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
                            },
                            //style:"color:555;font-size:12px;font-weight:;cursor:pointer;fill:#333333;",
                            data: totalNavData
                        },
                        {
                            type: 'line',
                            color: 'blue',
                            name: '沪深300',
                            marker: {
                                radius: 1,  //曲线点半径，默认是4
                                symbol: 'circle'//曲线点类型："circle", "square", "diamond", "triangle","triangle-down"，默认是"circle"
                            },
                            data: totalCSI300Data
                        }
                    ]
                };
                return historyFundCSI300Option;
            }
        }
    };

    factory.$inject = ['$location', '$http', '$rootScope'];
    return factory;
});