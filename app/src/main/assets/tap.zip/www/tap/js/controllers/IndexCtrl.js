define(function() {
    'use strict';

    function ctrl($scope,$ionicNavBarDelegate,$stateParams,$timeout,$rootScope,$ionicSlideBoxDelegate,$q,
                  LocalCacheService,CommonService,WebService) {

        var par = $scope.param = new Array();
        par.recommendInfos = $stateParams["recommendInfos"];
        LocalCacheService.setRecommendInfos(par.recommendInfos);
        par.tf_op_station =  $stateParams["tf_op_station"]; //打开app

        $scope.profit = {};
        $scope.homeSub = {};
        par.isAndroid = ionic.Platform.isAndroid();
        par.isClose = false;
        par.ads = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            par.notice_content = '';
            par.proValue = '';
            par.backButtonPressedOnceToExit = false;
            $scope.user = LocalCacheService.getUser();
        });

        initParams();
        init();
        initAd();

        $scope.doRefresh = function() {
            initAd().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            WebService.getNotice("system").then(
                function(notice){
                    if(notice.error_no==0 &&  notice.isColsed == 1) { //系统关闭公告
                        WebService.qryProdWhite().then(function(data){
                            if(!data  || !data.isProdWhite) {
                                par.notice_content = notice.content;
                                par.isClose = true;
                                $ionicNavBarDelegate.showBar(false);
                                $rootScope.hideTabs = true;
                                $scope.exitApp = function(){
                                    navigator.app.exitApp();
                                };
                            }
                        });
                    } else {
                        //公告获取
                        WebService.getNotice("index").then(function (notice) {
                            if (notice.error_no == 0 && notice.isColsed != 1 && notice.title && notice.content) {
                                CommonService.showNotice(notice.title + "&&" + notice.content, "tf_system_notice_show");
                            }
                        });
                    }
                }
            );

            //首页双击退出
            $scope.onBackKeyDown = function(){
                if(par.backButtonPressedOnceToExit){
                    ionic.Platform.exitApp();
                }else{
                    par.backButtonPressedOnceToExit = true;
                    CommonService.showAlert({message:'再按一次退出系统'});
                    $timeout(function(){
                        par.backButtonPressedOnceToExit = false;
                    }, 2000);
                }
            };

            $timeout(function() {
                if(navigator && navigator.splashscreen) {
                    navigator.splashscreen.hide();
                }
            }, 1000);
        }


        function initAd(){
            var adPromise1 = WebService.wtAd("xcm_index_1");
            var adPromise2 = WebService.wtAd("xcm_index_2");
            adPromise1.then(function(data){
                par.ads[0] = data;
                $ionicSlideBoxDelegate.update();
            });
            adPromise2.then(function(data){
                par.ads[1] = data;
            });
            return $q.all([adPromise1, adPromise2]);
        }

        function initParams() {
            if(!CommonService.isStrEmpty(par.tf_op_station) && par.tf_op_station.indexOf("]") != -1) {
                var ops = par.tf_op_station.split("[");
                var uuid = ops[ops.length-1].split("]")[0];
                LocalCacheService.set("UUID", uuid);
                LocalCacheService.set("op_station", par.tf_op_station);
                if(par.recommendInfos) {
                    WebService.activate({conduit_no: par.recommendInfos, source: CommonService.getSource(), app_uuid : uuid});
                }
            }
        }

    }

    ctrl.$inject = ['$scope','$ionicNavBarDelegate','$stateParams','$timeout','$rootScope','$ionicSlideBoxDelegate','$q',
        'LocalCacheService', 'CommonService', 'WebService'];
    return ctrl;
});