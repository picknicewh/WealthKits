define(function () {
    'use strict';

    function ctrl($scope,InfoService) {

        $scope.channel = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            $scope.content = new Array();
            $scope.items = new Array();
            //获取营地基金概况并添加事件
            return InfoService.getChildChannelInfos($scope.channel.channelId).then(function(data){
                if(data){
                    for(var i=0; i< data.length; i++) {
                        var channel = data[i];
                        var channelJson = {};
                        channelJson.channelId = channel.channel_id;
                        channelJson.title = channel.title;
                        channelJson.titleImg = channel.title_img;
                        channelJson.name = channel.channel_name;
                        channelJson.description = channel.description;
                        $scope.items.push(channelJson);
                    }
                    queryContentBriefs();
                }
            });
        }

        function queryContentBriefs(){
            InfoService.getContentBriefs($scope.channel.channelId, 2).then(function(data){
                if(data){
                    for(var i=0;i<data.length;i++){
                        var fund = data[i];
                        for(var j=0;j<$scope.items.length;j++){
                            var title = $scope.items[j];
                            if(fund.channelId == title.channelId){
                                fund.channel = title;
                            }
                        }
                        $scope.content.push(fund);
                    }
                }
            });
        }
    }

    ctrl.$inject = ['$scope','InfoService'];
    return ctrl;
});