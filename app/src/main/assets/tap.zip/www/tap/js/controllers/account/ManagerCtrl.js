define(function () {
    'use strict';

    function ctrl($scope,LocalCacheService) {
        $scope.user = LocalCacheService.getUser();
    }

    ctrl.$inject = ['$scope','LocalCacheService'];
    return ctrl;
});