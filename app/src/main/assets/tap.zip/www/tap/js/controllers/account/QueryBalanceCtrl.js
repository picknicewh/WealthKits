define(function () {
    'use strict';

    function ctrl($scope,$ionicHistory,$ionicLoading,WebService,CommonService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.bank = {};
            $scope.queryBalance = {};

            init();
        });

        function init(){
            //查询存管银行信息
            WebService.getUserDepositBankCards().then(
                function (data){
                    if(data.length != 0){
                        $scope.bank = data[0];
                        if("1" != $scope.bank.bkaccount_regflag){
                            var bankAccount = $scope.bank.bank_account;
                            $scope.bank.bank_account_show = bankAccount.substr(bankAccount.length-4);
                        }
                    }
                },
                function (result){
                    CommonService.showAlert({message:CommonService.getErrorInfo(result),onUnblock:function (){
                        $ionicHistory.goBack();
                    }});
                }
            );
        }

        $scope.goQueryBalance = function(){
            if(checkInput()){
                $ionicLoading.show();
                WebService.queryBankBanlance($scope.queryBalance.bank_password, $scope.bank.bank_no).then(
                    function (data){
                        switch (data.entrust_status){
                            case "2" : showResult("您卡内的余额为：<em class=\"amount\">"+ data.occur_balance + "</em>元");break;
                            case "3" : showResult(data.bank_error_info);break;
                            default : showResult("银行余额查询失败：请在工作日的9:00-16:00进行查询。");break;
                        }
                    },
                    function (result){
                        //银行非工作时间
                        if(result.error_no == "IFS--61"){
                            showResult("银行余额查询失败：请在工作日的9:00-16:00进行查询");
                        } else {
                            showResult("银行余额查询失败："+result.error_info);
                        }
                    }
                );
            }
        };

        var showResult = function (info){
            $ionicLoading.hide();
            CommonService.showConfig({title: "查询银行卡余额",message : info}).then(function(res) {
                $ionicHistory.goBack();
            });
        };

       function checkInput(){
           if($scope.bank.bank_no == undefined){
               CommonService.showAlert({message:"请选择银行卡"});
               return false;
           }
           if(!CommonService.checkRegex("^[0-9]{6}$",$scope.queryBalance.bank_password)){
               CommonService.showAlert({message:"请输入6位银行卡密码"});
               return false;
           }
           return true;
       }
    }

    ctrl.$inject = ['$scope','$ionicHistory','$ionicLoading','WebService','CommonService'];
    return ctrl;
});