/**
 * Created by wang on 2016-2-15.
 * 意见反馈
 */
define(function () {
    'use strict';

    function ctrl($scope, $ionicHistory, $ionicPopup, WebService, CommonService) {


        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            $scope.feedback = {};
            $scope.feedback.disable = true;
        }

        $scope.$watch("feedback.content", function(newValue, oldValue){
            if(newValue && newValue.length > 0) {
                $scope.feedback.disable = false;
            } else {
                $scope.feedback.disable = true;
            }
        });

        $scope.add = function(){
            var content = $scope.feedback.content;
            if(CommonService.isStrEmpty(content)){
                CommonService.showAlert({message:"请填写反馈内容！"});
                return false;
            }
            var mobile_tel = $scope.feedback.mobile_tel;
            mobile_tel = CommonService.trim(mobile_tel);
            if(mobile_tel) {
                if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$",CommonService.trim(mobile_tel))){
                    CommonService.showAlert({message:"手机号格式错误！"});
                    return false;
                }
            }
            $ionicPopup.confirm({
                cssClass: 'popup-head-hide',
                template: "是否确定发送反馈信息？",
                okText:"确定",
                cancelText:"返回修改"
            }).then(function(res) {
                if(res) {
                    $scope.feedback.disable = true;
                    WebService.wtAddClientOpinion(content, $scope.feedback.mobile_tel).then(function(data){
                        $scope.feedback.disable = false;
                        $ionicHistory.goBack();
                        CommonService.showAlert({message:"感谢您的反馈！"});
                    });
                }
            });
        }
    }

    ctrl.$inject = ['$scope','$ionicHistory','$ionicPopup','WebService','CommonService'];
    return ctrl;
});