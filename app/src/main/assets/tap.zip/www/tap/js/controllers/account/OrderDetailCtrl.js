define(function (require, exports, module) {
    'use strict';
    var xdate = require('xdate');

    function ctrl($scope,$state,$stateParams,$ionicHistory,WebService,CommonService,DictionaryService) {

        var par = $scope.param = new Array();

        $scope.onBackKeyDown = function(){
            var backView = $ionicHistory.backView();
            if(backView && backView.stateName == "tab.account-productOrderHistory"){
                $ionicHistory.goBack();
            }else {
                $state.go("tab.account-orders");
            }
        };

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.failureOrder = {};
            $scope.orderDetail = {};
            $scope.pay_result = null;

            //查询废单原因 三方支付
            par.co_serial_no = $stateParams["co_serial_no"];
            par.allotNo =  $stateParams["allotNo"];
            par.prodSource = $stateParams["prodSource"];
            par.isCurrent = $stateParams["isCurrent"];
            par.isFailureOrder = (par.co_serial_no && par.co_serial_no != "");

            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init() {
            if(par.isFailureOrder) {
                //查询三方支付废单原因
                return queryBankErrorInfo();
            } else {
                //查询交易记录详情
                return queryOrderDetail();
            }
        }

        function queryBankErrorInfo(){
            WebService.getOrderDetail(par.allotNo,par.prodSource,par.isCurrent).then(
                function (data) {
                    if(data){
                        $scope.failureOrder = data;
                    }
                }
            );
            $scope.isLoadingPayResult = true;
            var q = WebService.queryBankTransfer(par.co_serial_no, par.isCurrent);
            q.then(function (data1){
                    $scope.isLoadingPayResult = false;
                    if(data1.status == 0) {
                        $scope.pay_result = "扣款失败，" + data1.bank_error_info;
                    } else {
                        $scope.pay_result = "交易失败，但银行扣款成功，请联系客服400-800-5000";
                    }
                }
            );
            return q;

        }

        function queryOrderDetail(){
            var q = WebService.getOrderDetail(par.allotNo,par.prodSource,par.isCurrent);
            q.then(function (data) {
                    if(data){
                        $scope.orderDetail = data;
                        if("0"==data.buyOrSell){
                            var start_date = data.profitStartDate;
                            var show_date = data.profitShowDate;
                            var begin_date = data.prodBeginDate;

                            $scope.orderDetail.isSpecialBuyOrder = (CommonService.isStrEmpty(start_date) || CommonService.isStrEmpty(show_date));

                            if(!$scope.orderDetail.isSpecialBuyOrder){
                                if(data.sysTime < start_date){
                                }else if (data.sysTime >= start_date && data.sysTime < show_date){
                                    $scope.orderDetail.trade_class = "lit";
                                    $scope.orderDetail.profit_start_class = "lit none";
                                }else{
                                    $scope.orderDetail.trade_class = "lit";
                                    $scope.orderDetail.profit_start_class = "lit";
                                    $scope.orderDetail.profit_show_class = "lit";
                                }
                                var profitStartDate = new Date(start_date.substr(0,4),parseFloat(start_date.substr(4,2))-1,start_date.substr(6,2));
                                var profitShowDate = new Date(show_date.substr(0,4),parseFloat(show_date.substr(4,2))-1,show_date.substr(6,2));
                                $scope.orderDetail.profitStartDate = new XDate(profitStartDate).toString("MM-dd") + " " + weeks[profitStartDate.getDay()];
                                $scope.orderDetail.profitShowDate = new XDate(profitShowDate).toString("MM-dd") + " " + weeks[profitShowDate.getDay()];

                            }else{
                                if(!CommonService.isStrEmpty(begin_date) && begin_date.length >=8){
                                    if(data.sysTime >= begin_date){
                                        $scope.orderDetail.trade_class = "lit";
                                        $scope.orderDetail.prod_begin_class = "lit";
                                    }
                                    var prodBeginDate = new Date(begin_date.substr(0,4),parseFloat(begin_date.substr(4,2))-1,begin_date.substr(6,2));
                                    data.prodBeginDate = new XDate(prodBeginDate).toString("MM-dd") + " " + weeks[prodBeginDate.getDay()];
                                }else{
                                    data.prodBeginDate = "产品成立当日确认购买份额，开始计算收益</br>第二个交易日开始显示收益";
                                }
                            }
                        }else{
                            var redeem_date = data.redeemShowDate;
//                            if(data.sysTime >= redeem_date){
                                $scope.orderDetail.trade_class = "lit";
                                $scope.orderDetail.redeem_show_class = "lit";
//                            }
                            if(!CommonService.isStrEmpty(data.pay_account)){
                                $scope.orderDetail.pay_account = "尾号" + data.pay_account;
                            }
                            if(CommonService.isStrEmpty(redeem_date)){
                                $scope.orderDetail.redeemShowDate = '--';
                            }else{
                                var redeemShowDate = new Date(redeem_date.substr(0,4),parseFloat(redeem_date.substr(4,2))-1,redeem_date.substr(6,2));
                                $scope.orderDetail.redeemShowDate = new XDate(redeemShowDate).toString("MM-dd") + " " + weeks[redeemShowDate.getDay()];
                            }
                        }
                    }
                }
            );
            return q;
        }
        var weeks = DictionaryService.getWeeks();
    }

    ctrl.$inject = ['$scope','$state','$stateParams','$ionicHistory','WebService','CommonService','DictionaryService'];
    return ctrl;
});