define(function () {
    'use strict';

    function ctrl($scope,$timeout,$filter,$ionicPopup,$ionicActionSheet,LocalCacheService,InfoService) {

        $scope.channel = {};
        $scope.vm = {};
        $scope.vm.activeTab=1;

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            $scope.showFilterSel = false;
            $scope.companyJson = new Array();
            //查询广告
            $scope.showAds();
            //查询产品信息
            return InfoService.getChildChannelInfos($scope.channel.channelId).then(function(data){
                if(data){
                    for(var i=0; i< data.length; i++) {
                        var channel = data[i];
                        var channelJson = {};
                        channelJson.channelId = channel.channel_id;
                        channelJson.title = channel.title;
                        channelJson.titleImg = channel.title_img;
                        channelJson.name = channel.channel_name;
                        channelJson.description = channel.description;
                        channelJson.jjgscxpj = channel.cx_grade;
                        channelJson.isOpen = false;
                        $scope.companyJson.push(channelJson);
                    }
                    //控制基金概况html
                    controlConHtml();
                }
            });
        }

        $scope.showAds = function(type){
            InfoService.getAdSpace($scope.channel.adId).then(function(data){
                if(data) {
                    $scope.ads = data;
                    var adKey = "ad_" + $scope.channel.adId;
                    if((!LocalCacheService.get(adKey) || type) && $scope.ads.length > 0) {
                        var myPopup = $ionicPopup.show({
                            cssClass: 'popup-head-hide ',
                            templateUrl: "product/ads.html",
                            scope: $scope,
                            buttons: [
                                { text: '确定' }
                            ]
                        });
                        LocalCacheService.set(adKey, true);
                    }
                }
            });
        }

        var controlConHtml = function(){
            InfoService.getContentBriefs($scope.channel.channelId, 2).then(function(data){
                if(data){
                    $scope.profitFunds = data;
                    for(var i=0;i< $scope.profitFunds.length;i++){
                        var fund =  $scope.profitFunds[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                    }
                }
            });
        };

        $scope.show = function() {
            var hideSheet= $ionicActionSheet.show({
                cancelOnStateChange:true,
                cssClass:'action_s',
                titleText: "排序",
                buttons: [
                    { text: $scope.vm.activeTab == 1 ? "<b>按收益排序</b>" : "按收益排序" },
                    { text: $scope.vm.activeTab == 2 ? "<b>按基金评级排序</b>" : "按基金评级排序" },
                    { text: $scope.vm.activeTab == 3 ? "<b>按基金公司评级排序</b>" : "按基金公司评级排序" },

                ],
                buttonClicked: function(index) {
                    $scope.vm.activeTab= index+1;
                    return true;
                },
                cancelText: "取消",
                cancel: function() {
                    console.log('执行了取消操作');
                    return true;
                }
            });
            $timeout(function() {
                hideSheet();
            }, 4000);
        };
    }

    ctrl.$inject = ['$scope','$timeout','$filter','$ionicPopup','$ionicActionSheet','LocalCacheService','InfoService'];
    return ctrl;
});