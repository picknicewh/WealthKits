define(function () {
    'use strict';

    function ctrl($scope,$state,$timeout,$stateParams,WebService,CommonService,InfoService) {

        var par = $scope.param = new Array();

        //回退固定为持仓页
        $scope.onBackKeyDown = function(){
            $state.go("tab.account-shares");
        };

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.holdFund = {};//持仓信息
            $scope.prodInfo = {}; //产品信息

            par.allotNo = $stateParams['allotNo'];
            par.prodCode = $stateParams['prodCode'];
            par.prodSource = $stateParams['prodSource'];

            par.moreUrl = '';

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast('scroll.refreshComplete');
        };

        function init (){
            //查询份额信息
            WebService.getShares(par.prodSource,par.allotNo,par.prodCode).then(
                function (data) {
                    if(data.length == 1) {
                        $scope.holdFund = data[0];
                        if(par.prodSource != 1){
                            $scope.holdFund.market_value = $scope.holdFund.current_amount;
                        }
                        queryProdInfo();
                    } else {
                        CommonService.showAlert({message:"持仓信息查询失败",onUnblock:function (){
                            $timeout(function(){
                                $scope.onBackKeyDown();
                            },3000);
                        }});
                    }
                }
            );
        }

        function queryProdInfo(){
            InfoService.getChannelByProdCode(par.prodCode).then(function(data){
                if(data){
                    $scope.prodInfo = data;
                    //计算预期收益
                    if(!isNaN(data.prodDuration)){
                        $scope.prodInfo.reIncome=parseFloat($scope.holdFund.current_amount)*parseFloat(data.expYearYield)*parseInt(data.prodDuration)/parseFloat(36500);
                    }
                    if(par.prodSource==1){
                        par.moreUrl ="#/tab/product-detail-otc/"+data.contentId;
                    }else{
                        par.moreUrl ="#/tab/product-detail/"+data.contentId;
                    }

                    productPageUrl();
                }
            });
        }

        function productPageUrl() {
            $scope.prodInfo.url = CommonService.productPageUrl($scope.prodInfo.prodProfitMode, $scope.prodInfo.prodSource);
            if ($scope.prodInfo.url == null || typeof($scope.prodInfo.url) == "undefined"){
                CommonService.showConfig({message: "产品收益模式未配置:" + $scope.prodInfo.prodCode});
            }
        }
    }

    ctrl.$inject = ['$scope','$state','$timeout','$stateParams','WebService','CommonService','InfoService'];
    return ctrl;
});