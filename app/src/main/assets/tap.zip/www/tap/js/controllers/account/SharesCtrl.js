define(function (require, exports, module) {
    'use strict';
    var xdate = require('xdate');

    function ctrl($scope,$state,WebService,CommonService,InfoService) {

        var par = $scope.param = new Array();
        var array = new Array();

        //回退固定为账户首页
        $scope.onBackKeyDown = function(){
            $state.go("tab.account-index");
        };

        $scope.$on('$ionicView.beforeEnter', function() {

            par.prevDate = CommonService.getPrevDate();
            par.sys_time = new XDate(new Date()).toString('yyyyMMdd');
            par.isLoaded = false;

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast('scroll.refreshComplete');
        };

        function init() {
            $scope.shares = new Array();
            array = new Array();
            //查询持仓
            WebService.getAllShares().then(
                function (data) {
                    if(data && data.length > 0){
                        for(var i = 0; i < data.length; i++){
                            var record = data[i];
                            setShares(record);
                        }
                    }
                    par.isLoaded = true;
                }
            );
        }

        function setShares(record){
            InfoService.getChannelByProdCode(record.prod_code).then(
                function (data){
                    if(data && '0,1,2,3'.indexOf(data.prodProfitMode) > -1){
                        //理财体验修改
                        if(!CommonService.isBuyExperience() && !$.cookie("back_url_2")) {
                            record.fund_alias = data.channelName;
                        } else {
                            record.fund_alias = "";
                        }

                        if(record.bank_no == "0"){
                            record.pay_account = "";
                        }
                        record.pay_account_empty = CommonService.isStrEmpty(record.pay_account);
                        record.prodProfitMode = data.prodProfitMode;
                        record.prodType = data.prodType;
                        //产品交易状态
                        record.prodStatus = data.prodStatus;
                        record.isSell = (record.prodStatus == 0 || record.prodStatus == 2) && record.enable_amount > 0;
                        if("0"==record.prodProfitMode) {
                            //万份收益产品 计算昨日收益
                            record.inYestoday = (parseFloat(record.current_amount) / 10000) * parseFloat(data.prodGain);
                            //短债 持仓显示
                            if ("2" == data.prodType) {
                                InfoService.getShortTermFund(record.prod_code, record.trans_account).then(
                                    function (short_term_fund) {
                                        if (short_term_fund && short_term_fund.length > 0) {
                                            //此处考虑到性能问题，不去请求对应的当前委托计算可卖出数量，通过比较26记录剩余数量与持仓可卖出份额，控制当前是否还有可卖
                                            var amount = 0;
                                            for (var i = 1; i < short_term_fund.length; i++) {
                                                amount += parseFloat(short_term_fund[i].availableVol);
                                            }
                                            var short_fund = short_term_fund[0];
                                            record.isSell = (record.prodStatus == 0 || record.prodStatus == 2) && short_fund.isRedeemDate == "1"
                                                && short_fund.sellTime >= "09" && short_fund.sellTime < "15" && record.enable_amount > 0
                                                && CommonService.controlNum(record.enable_amount, 2) != CommonService.controlNum(amount, 2);
                                            //短债记录赋值给该笔持仓
                                            record.short_term_fund = short_term_fund;
                                        }
                                    }
                                );
                            }
                        }else if("2"==record.prodProfitMode){
                            //预期收益产品 计算预期收益 展示描述信息
                            record.reIncome = "--";
                            if(!isNaN(data.prodDuration)){
                                record.reIncome=parseFloat(record.current_amount)*parseFloat(data.expYearYield)*parseInt(data.prodDuration)/parseFloat(36500);
                            }
                            record.prodIncomeDate = data.prodIncomeDate;
                            record.total_income =  record.current_amount;
                        }else if("3"==record.prodProfitMode){
                            //券商资管产品 展示描述信息
                            record.prodIncomeDate = data.prodIncomeDate;
                            record.shareDesc = data.shareDesc;
                        }
                        //prodProfitMode 1 QDII产品 不做处理
                        //产品信息展示
                        array.push(record);
                        $scope.shares = array.sort(function(a,b){return a.prod_code > b.prod_code ? 1: -1});
                    }else{
                        CommonService.showConfig({message:"产品信息有误："+data.prodCode});
                    }
                }
            );
        }

        $scope.shortDetail = function (prod_code,trans_account,prod_source,pay_account){
            //26记录查询
            InfoService.getShortTermFund(prod_code,trans_account).then(
                function(short_term_fund){
                    if(short_term_fund && short_term_fund.length != 0){
                        //当前委托查询
                        WebService.getOrders(prod_source, prod_code, trans_account).then(
                            function (data){
                                var html = "<div>卖出开放日提醒（逾期未卖出份额将自动滚存新一期）<ol>";
                                for(var i=0; i<short_term_fund.length; i++){
                                    var short_fund = short_term_fund[i];
                                    var enable_amount = parseFloat(short_fund.availableVol);
                                    if(i==0 && data && data.length > 0){
                                        if(prod_source=="1"){
                                            for (var j = 0; j < data.length; j++) {
                                                var record = data[j];
                                                enable_amount = enable_amount - parseFloat(record.entrust_amount);
                                            }
                                        }
                                        if(prod_source=="2"){
                                            for (var j = 0; j < data.length; j++) {
                                                var record = data[j];
                                                enable_amount = enable_amount - parseFloat(record.shares);
                                            }
                                        }
                                    }
                                    var sell_time = CommonService.isStrEmpty(pay_account) ? " 9:00-15:00，可卖出" : " 当日15:00前，可卖出";
                                    html += "<li>"+ short_fund.redeemEndDate + sell_time + enable_amount +"份</li>";
                                }
                                html += "</ol></div>";
                                CommonService.showConfig({okText: '关闭',message : html});
                            }
                        )
                    }else{
                        CommonService.showAlert("数据获取失败，请重试");
                    }
                }
            );
        };

        $scope.redeemDetail = function(prod_code,prodIncomeDate,bank_name,pay_account){
            InfoService.getProfitDate(prod_code,prodIncomeDate).then(
                function(redeemDetail){
                    if(redeemDetail){
                        var html = '<div>产品到期时间提醒：<br />';
                        html += CommonService.formatDate(prodIncomeDate) + '到期自动赎回，赎回资金将于' + CommonService.formatDate(redeemDetail.profitStartDate) +
                            '到账至您的' + bank_name ;
                        if(!CommonService.isStrEmpty(pay_account)){
                            html += ' 尾号' + pay_account + '</div>';
                        }else{
                            html += '</div>';
                        }
                        //OTC、银行理财、资管产品持仓中的自动赎回时间提醒优化
                        CommonService.showConfig({okText: '关闭',message : html});
                    }
                }
            );
        };

        $scope.gatherDetail = function(share_desc) {
            CommonService.showConfig({okText: '关闭',message : share_desc});
        };
    }

    ctrl.$inject = ['$scope','$state','WebService','CommonService','InfoService'];
    return ctrl;
});