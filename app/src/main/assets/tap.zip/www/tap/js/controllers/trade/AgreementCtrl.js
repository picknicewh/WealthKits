define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$ionicHistory,$ionicLoading,$timeout,LocalCacheService,WebService) {
        $scope.id = $stateParams["id"];

        $scope.$on('$ionicView.loaded', function() {
            init();
        });

        function init(){
            WebService.getEncontract($scope.id).then(function (data){
                var econtract_content = data.econtract_content;
                data.econtract_content = null;
                $scope.agreement = data;
                console.log(JSON.stringify(data)+'data909090909090909090909090');
                console.log(JSON.stringify($scope.id)+'id');
                $ionicLoading.show();
                $timeout(function(){
                    var utel = angular.element(document.querySelector('#econtract_content'));
                    utel.html(econtract_content);
                    $ionicLoading.hide();
                }, 600);
            });
        }


        $scope.back_android = function(){
            //alert(1);
            history.back();
        };

        $scope.closeAgreementContent = function(){
            var agreeAgreements = LocalCacheService.get("agreeAgreements");
            if(!agreeAgreements) {
                agreeAgreements = "";
            }
            if(agreeAgreements.indexOf($scope.id) == -1) {
                agreeAgreements += "," + $scope.id;
            }
            LocalCacheService.set("agreeAgreements", agreeAgreements);

            $ionicHistory.goBack();
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$ionicHistory','$ionicLoading','$timeout','LocalCacheService','WebService'];
    return ctrl;
});
