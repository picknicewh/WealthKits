define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$ionicHistory,WebService) {
        $scope.econtract_type = $stateParams["econtract_type"];

        $scope.$on('$ionicView.loaded', function() {
            init();
        });

        function init(){
            WebService.getEncontractList($scope.econtract_type).then(
                function (data){
                if(data && data.length > 0){
                    $scope.agreementList = data;
                }
            });
        }

        $scope.closeAgreementList = function(){
            $ionicHistory.goBack();
        };
    }

    ctrl.$inject = ['$scope','$stateParams','$ionicHistory','WebService'];
    return ctrl;
});
