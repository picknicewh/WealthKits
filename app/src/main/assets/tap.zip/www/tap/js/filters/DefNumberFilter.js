/**
 * 数据显示过滤器 有值保留2位小数 没值 --
 * Created by wang on 2015-9-22.
 */
define(['angular'], function (angular) {
    "use strict";

    var filter = function () {
        return function (text, num, suffix) {

            if(null == text || "undefined" == typeof(text) || "" == text){
                return "--";
            }else if(isNaN(text)){
                return text;
            }else {
                var show = text;
                if(num != null) {
                    show = parseFloat(text).toFixed(num);
                }
                if(angular.isDefined(suffix)) {
                    return show + suffix;
                }
               return show;
            }
        };
    };

    filter.$inject = [];
    return filter;
});