/*global define, require */

define(['app'], function (app) {
    'use strict';

    app.config(['$stateProvider', '$urlRouterProvider',
            function ($stateProvider, $urlRouterProvider) {

            $stateProvider
                .state('login', {
                    url: "/login?from&fromParams&to&toParams&w",
                    templateUrl: "../view/login.html",
                    controller: 'LoginCtrl'
                })
                .state('help', { //帮助中心
                    url: '/help',
                    templateUrl: '../view/help/index.html',
                    controller: 'help_IndexCtrl'
                })
                .state('help-item', { //帮助中心详情
                    url: '/help-item/:type/:id?selectId',
                    templateUrl: '../view/help/item.html',
                    controller: 'help_ItemCtrl'
                })
                .state('tab', {
                    url: "/tab",
                    abstract: true,
                    templateUrl: "../view/tabs.html"
                })
                .state('tab.index', {
                    url: '/index?recommendInfos&tf_op_station',
                    views: {
                        'tab-index': {
                            templateUrl: '../view/tab-index.html',
                            controller: 'IndexCtrl'
                        }
                    }
                })
                .state('tab.index-concern', { //我的关注
                    url: '/index-concern',
                    views: {
                        'tab-index': {
                            templateUrl: '../view/product/concern.html',
                            controller: 'account_ConcernCtrl'
                        }
                    }
                })
                .state('tab.account-index', {
                    url: '/account-index',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/index.html',
                            controller: 'account_IndexCtrl'
                        }
                    },
                    loginStatus : true //是否需要登录 默认不需要登录
                })
                .state('tab.account-shares', {
                    url: "/account-shares",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shares.html',
                            controller: 'account_SharesCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-orders', {
                    url: "/account-orders",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/orders.html',
                            controller: 'account_OrdersCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-productOrderHistory', {
                    url: "/account-productOrderHistory?prodCode&prodSource&trans_account",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/orderProdHistory.html',
                            controller: 'account_OrderProdHistoryCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-shareDetail', {
                    url: "/account-shareDetail?allotNo&prodCode&prodSource&trans_account",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shareDetail.html',
                            controller: 'account_ShareDetailCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-shareDetailShort', {
                    url: "/account-shareDetailShort?allotNo&prodCode&prodSource&enable_amount&payAccount&trans_account",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shareDetailShort.html',
                            controller: 'account_ShareDetailShortCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-shareDetailBank', {
                    url: "/account-shareDetailBank?allotNo&prodCode&prodSource&trans_account",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shareDetailBank.html',
                            controller: 'account_ShareDetailBankCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-shareDetailGather', {
                    url: "/account-shareDetailGather?allotNo&prodCode&prodSource",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shareDetailGather.html',
                            controller: 'account_ShareDetailGatherCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-shareDetailQDII', {
                    url: "/account-shareDetailQDII?allotNo&prodCode&prodSource&trans_account",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/shareDetailQDII.html',
                            controller: 'account_ShareDetailQDIICtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-orderDetail', {
                    url: "/account-orderDetail?co_serial_no&allotNo&prodSource&isCurrent",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/orderDetail.html',
                            controller: 'account_OrderDetailCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('recharge-and-withdraw', { //充值提现
                    url: "/recharge-and-withdraw",
                    controller: 'account_RechargeAndWithdrawCtrl',
                    templateUrl: "../view/account/rechargeAndWithdraw.html",
                    loginStatus : true
                })
                .state('query-balance', {
                    url: '/query-balance',
                    templateUrl: '../view/account/queryBalance.html',
                    controller: 'account_QueryBalanceCtrl',
                    loginStatus : true
                })
                .state('trade-buy', {
                    url: "/trade/buy?prodCode&prodSource&add&name&token&key",
                    templateUrl: "../view/trade/buy.html",
                    controller: 'trade_BuyCtrl',
                    loginStatus : true
                })
                .state('agreementList', {
                    url: "/trade/agreementList?econtract_type",
                    templateUrl: "../view/trade/agreementList.html",
                    controller: 'trade_AgreementListCtrl'
                })
                .state('agreement', {
                    url: "/trade/agreement?id",
                    templateUrl: "../view/trade/agreement.html",
                    controller: 'trade_AgreementCtrl'
                })
                .state('selectPayWay', {
                    url: "/trade/selectPayWay",
                    templateUrl: "../view/trade/selectPayWay.html",
                    controller: 'trade_SelectPayWayCtrl',
                    loginStatus : true
                })
                .state('trade-sell', {
                    url: "/trade/sell?allotNo&prodCode&prodSource&name&token&key",
                    templateUrl: "../view/trade/sell.html",
                    controller: 'trade_SellCtrl',
                    loginStatus : true
                })

                /***********设置模块begin*****************/
                .state('tab.account-manager', {
                    url: '/account-manager',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/manager.html',
                            controller: 'account_ManagerCtrl'
                        }
                    },
                    loginStatus : true
                })
                .state('tab.account-userInfo', {
                    url: '/account-userInfo',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/userInfo.html',
                            controller: 'account_UserInfoCtrl'
                        }
                    },
                    loginStatus : true
                })
                //修改手机号页面
                .state('tab.account-modifyPhone', {
                    url: '/account-modifyPhone?name&token&key',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/modifyPhone.html',
                            controller: 'account_ModifyPhoneCtrl'
                        }
                    },
                    loginStatus : true
                })
                //修改密码
                .state('tab.account-modifyPwd', {
                    url: '/account-modifyPwd?name&token&key',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/modifyPwd.html',
                            controller: 'account_ModifyPwdCtrl'
                        }
                    },
                    loginStatus : true
                })
                //风险测评
                .state('tab.account-risk', {
                    url: '/account-risk',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/risk.html',
                            controller: 'account_RiskCtrl'
                        }
                    },
                    loginStatus : true
                })
                //银行卡页面
                .state('tab.account-bank', {
                    url: '/account-bank',
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/bank.html',
                            controller: 'account_BankCtrl'
                        }
                    },
                    loginStatus : true
                })
                //补绑三方存管
                .state('tab.account-bindDepositBank', {
                    url: "/account-bindDepositBank",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/bindDepositBank.html',
                            controller: 'open_BindDepositBankCtrl'
                        }
                    },
                    loginStatus : true
                })
                //绑定快捷支付
                .state('tab.account-bindQuickBank', {
                    url: "/account-bindQuickBank?name&token&key",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/bindQuickBank.html',
                            controller: 'open_BindQuickBankCtrl'
                        }
                    },
                    loginStatus : true
                })
                //解绑银行卡
                .state('tab.account-unbindBank', {
                    url: "/account-unBindBank?bank_no&bank_account&bank_name",
                    views: {
                        'tab-account-index': {
                            templateUrl: '../view/account/unbindBank.html',
                            controller: 'account_UnbindBankCtrl'
                        }
                    },
                    loginStatus : true
                })
                /***********设置模块end*****************/

                /***********开户相关begin*****************/
                //开户准备页
                .state('open-prepare', {
                    url: "/open-prepare/:name/:token/:key?source&recommendInfos",
                    templateUrl: '../view/open/prepare.html',
                    controller: 'open_PrepareCtrl'
                })
                //手机号注册页
                .state('open-msgVerify', {
                    url: "/open-msgVerify",
                    templateUrl: '../view/open/msgVerify.html',
                    controller: 'open_MsgVerifyCtrl'
                })
                //营业部选择页
                .state('open-selectBranch', {
                    url: "/open-selectBranch?default_branch",
                    templateUrl: '../view/open/selectBranch.html',
                    controller: 'open_SelectBranchCtrl'//,
                    //openStatus:true
                })
                //身份证上传
                .state('open-uploadID', {
                    url: "/open-uploadID?branch_no",
                    templateUrl: '../view/open/uploadID.html',
                    controller: 'open_UploadIDCtrl'//,
                    //openStatus:true
                })
                //个人信息填写
                .state('open-personInfo', {
                    url: "/open-personInfo",
                    templateUrl: '../view/open/personInfo.html',
                    controller: 'open_PersonInfoCtrl'//,
                   // openStatus:true
                })
                //数字证书安装
                .state('open-installCert', {
                    url: "/open-installCert",
                    templateUrl: '../view/open/installCert.html',
                    controller: 'open_InstallCertCtrl'//,
                   // openStatus:true
                })
                //风险测评
                .state('open-riskAssess', {
                    url: "/open-riskAssess",
                    templateUrl: '../view/open/riskAssess.html',
                    controller: 'open_RiskAssessCtrl'//,
                   // openStatus:true
                })
                //设置密码
                .state('open-setPwd', {
                    url: "/open-setPwd",
                    templateUrl: '../view/open/setPwd.html',
                    controller: 'open_SetPwdCtrl'//,
                   // openStatus:true
                })
                //绑定三方存管
                .state('open-bindOpenDeposit', {
                    url: "/open-bindOpenDeposit?b",
                    templateUrl: '../view/open/bindOpenDeposit.html',
                    controller: 'open_BindDepositBankCtrl'//,
                   // openStatus:true
                })
                //绑定开户银行卡
                .state('open-bindOpenQuick', {
                    url: "/open-bindOpenQuick?b",
                    templateUrl: '../view/open/bindOpenQuick.html',
                    controller: 'open_BindQuickBankCtrl'//,
                    //openStatus:true
                })
                //签署协议
                .state('open-signAgreement', {
                    url: "/open-signAgreement",
                    templateUrl: '../view/open/signAgreement.html',
                    controller: 'open_SignAgreementCtrl'//,
                   // openStatus:true
                })
                //回访问卷
                .state('open-revisitPaper', {
                    url: "/open-revisitPaper",
                    templateUrl: '../view/open/revisitPaper.html',
                    controller: 'open_RevisitPaperCtrl'//,
                    //openStatus:true
                })
                //开户结果
                .state('open-openResult', {
                    url: "/open-openResult?open_status",
                    templateUrl: '../view/open/openResult.html',
                    controller: 'open_OpenResultCtrl'//,
                    //openStatus:true
                })
                //有奖测评
                .state('open-channelRisk', {
                    url: "/open-channelRisk?paper_id&product_no",
                    templateUrl: '../view/open/channelRisk.html',
                    controller: 'open_ChannelRiskCtrl'
                })
                /***********开户相关end*****************/

                /***********产品中心begin*****************/
                .state('tab.product-item', {
                    url: '/product-item/:contentId',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/item.html',
                            controller: 'product_ItemCtrl'
                        }
                    }
                })
                .state('tab.product-detail', {
                    url: '/product-detail/:contentId',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/detail.html',
                            controller: 'product_DetailCtrl'
                        }
                    }
                })
                .state('tab.product-item-otc', {
                    url: '/product-item-otc/:contentId',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/item-otc.html',
                            controller: 'product_ItemOtcCtrl'
                        }
                    }
                })
                .state('tab.product-detail-otc', {
                    url: '/product-detail-otc/:contentId',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/detail-otc.html',
                            controller: 'product_DetailOtcCtrl'
                        }
                    }
                })
                .state('tab.product-item-QDII', {
                    url: '/product-item-QDII/:contentId?is_index',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/item-QDII.html',
                            controller: 'product_ItemQDIICtrl'
                        }
                    }
                })
                .state('tab.product-index', {
                    url: '/product-index',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/index.html',
                            controller: 'product_IndexCtrl'
                        }
                    }
                })
                .state('tab.product-currentTerm', {
                    url: '/product-currentTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/currentTerm.html',
                            controller: 'product_CurrentTermCtrl'
                        }
                    }
                })
                .state('tab.product-more', {
                    url: '/product-more',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/moreProduct.html',
                            controller: 'product_MoreCtrl'
                        }
                    }
                })
                .state('tab.product-starTerm', {
                    url: '/product-starTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/starTerm.html',
                            controller: 'product_StarTermCtrl'
                        }
                    }
                })
                .state('tab.product-shortTerm', {
                    url: '/product-shortTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/shortTerm.html',
                            controller: 'product_ShortTermCtrl'
                        }
                    }
                })
                .state('tab.product-tfTerm', {
                    url: '/product-tfTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/tfTerm.html',
                            controller: 'product_TFTermCtrl'
                        }
                    }
                })
                .state('tab.product-longTerm', {
                    url: '/product-longTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/longTerm.html',
                            controller: 'product_LongTermCtrl'
                        }
                    }
                })
                .state('tab.product-goldTerm', {
                    url: '/product-goldTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/goldTerm.html',
                            controller: 'product_GoldTermCtrl'
                        }
                    }
                })
                .state('tab.product-overseaTerm', {
                    url: '/product-overseaTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/overseaTerm.html',
                            controller: 'product_QDIITermCtrl'
                        }
                    }
                })
                .state('tab.product-goodsTerm', {
                    url: '/product-goodsTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/goodsTerm.html',
                            controller: 'product_QDIITermCtrl'
                        }
                    }
                })
                .state('tab.product-landLordTerm', {
                    url: '/product-landLordTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/landLordTerm.html',
                            controller: 'product_QDIITermCtrl'
                        }
                    }
                })
                .state('tab.product-indexTerm', {
                    url: '/product-indexTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/indexTerm.html',
                            controller: 'product_IndexTermCtrl'
                        }
                    }
                })
                .state('tab.product-stockTerm', {
                    url: '/product-stockTerm',
                    views: {
                        'tab-product-index': {
                            templateUrl: '../view/product/stockTerm.html',
                            controller: 'product_StockTermCtrl'
                        }
                    }
                })
                /***********产品中心end*****************/

                /***********推广begin*****************/
                .state('promo-ue-reward', {
                    url: '/promo-ue-reward/:id',
                    templateUrl: '../view/promo/ueReward.html',
                    css: '../../tap/css/promo/ue-reward.css',
                    controller: 'promo_UeRewardCtrl'
                })
                .state('promo-subject', {
                    url: '/promo-subject/:id',
                    templateUrl: '../view/promo/subject.html',
                    controller: 'promo_SubjectCtrl'
                })
                .state('promo-past-subject', {
                    url: '/promo-past-subject',
                    templateUrl: '../view/promo/pastSubject.html',
                    controller: 'promo_PastSubjectCtrl'
                })
                .state('promo-otc', {
                    url: '/promo-otc/:id',
                    templateUrl: '../view/promo/otc.html',
                    controller: 'promo_OtcCtrl',
                    css: '../../tap/css/promo/otc.css'
                })
                .state('promo-wx-question', {
                    url: '/promo-wx-question',
                    templateUrl: '../view/promo/wxQuestion.html',
                    controller: 'promo_WxQuestionCtrl'
                })
                .state('promo-wx-fans', {
                    url: '/promo-wx-fans',
                    templateUrl: '../view/promo/weixin/fans.html',
                    css: '../../tap/css/promo/weixin/fans.css'
                })
                .state('promo-reward', {
                    url: '/promo-reward',
                    templateUrl: '../view/promo/reward.html',
                    controller: 'promo_RewardCtrl',
                    css: '../../tap/css/promo/reward.css'
                })
                .state('promo-theme-blueChip', {
                    url: '/promo-theme-blueChip/:id',
                    templateUrl: '../view/promo/theme/blueChip.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/blueChip.css'
                })
                .state('promo-theme-bondFund', {
                    url: '/promo-theme-bondFund/:id',
                    templateUrl: '../view/promo/theme/bondFund.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/bondFund.css'
                })
                .state('promo-theme-internetBank', {
                    url: '/promo-theme-internetBank/:id',
                    templateUrl: '../view/promo/theme/internetBank.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/internetBank.css'
                })
                .state('promo-theme-soeReform', {
                    url: '/promo-theme-soeReform/:id',
                    templateUrl: '../view/promo/theme/soeReform.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/soeReform.css'
                })
                .state('promo-theme-tianxiangOne', {
                    url: '/promo-theme-tianxiangOne/:id',
                    templateUrl: '../view/promo/theme/tianxiangOne.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/tianxiangOne.css'
                })
                .state('promo-theme-ziguan', {
                    url: '/promo-theme-ziguan/:id',
                    templateUrl: '../view/promo/theme/ziguan.html',
                    controller: 'promo_ThemeCtrl',
                    css: '../../tap/css/promo/theme/ziguan.css'
                })
                .state('promo-theme-classDeposits', {
                    url: '/promo-theme-classDeposits/:id',
                    templateUrl: '../view/promo/theme/classDeposits.html',
                    controller: 'promo_TermThemeCtrl',
                    css: '../../tap/css/promo/theme/classDeposits.css'
                })
                .state('promo-theme-shortBond', {
                    url: '/promo-theme-shortBond/:id',
                    templateUrl: '../view/promo/theme/shortBond.html',
                    controller: 'promo_TermThemeCtrl',
                    css: '../../tap/css/promo/theme/shortBond.css'
                })
                .state('promo-theme-bankTheme', {
                    url: '/promo-theme-bankTheme/:id',
                    templateUrl: '../view/promo/theme/bankTheme.html',
                    controller: 'promo_BankThemeCtrl',
                    css: '../../tap/css/promo/theme-fund.css'
                })
                //理财体验
                .state('promo-practice', {
                    url: '/promo-practice?from&close&branch_no&recommendInfos&redirect_url',
                    templateUrl: '../view/product/practiceTerm.html',
                    controller: 'promo_PracticeCtrl'
                })
                .state('open-fillCustomerInfo', { //理财体验
                    url: '/open-fillCustomerInfo?b',
                    templateUrl: '../view/open/fillCustomerInfo.html',
                    controller: 'open_FillCustomerInfoCtrl',
                    openStatus:true
                })
                /***********推广end*****************/
                .state('us', { //更多
                    url: '/us',
                    templateUrl: '../view/us/index.html',
                    controller: 'us_IndexCtrl'
                })
                .state('us-feedback', { //意见反馈
                    url: '/us-feedback',
                    templateUrl: '../view/us/feedback.html',
                    controller: 'us_FeedbackCtrl'
                })
                .state('us-contact', { //联系我们
                    url: '/us-contact',
                    templateUrl: '../view/us/contact.html'
                })
                .state('us-about', {
                    url: '/us-about',
                    templateUrl: '../view/us/about.html'
                })

                ;
                $urlRouterProvider.otherwise("/tab/index");
        }
    ]);
});