define(function () {
    'use strict';

    function ctrl($rootScope,$ionicPopup,$scope,$state,$stateParams,DictionaryService,$ionicLoading,
                  $ionicHistory,CommonService,LocalCacheService,ConcernService,WebService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });
        function init(){
            //alert($rootScope.ip+'ipipipipip');
             LocalCacheService.set('from_open_name',$.trim($stateParams['name']));
             LocalCacheService.set('from_open_token',$.trim($stateParams['token']));
             LocalCacheService.set('from_open_key',$.trim($stateParams['key']));
            if($stateParams['source']=='"dbgj"'){
                LocalCacheService.set('source','dbgj');
                //alert('save-source')
               // alert(LocalCacheService.get('source'));
            }
            if(!$stateParams['source']){
                LocalCacheService.remove('source');
               // alert(LocalCacheService.get('source'));
            }

       //     alert($.trim($stateParams['name']));
            var par = $scope.param = {};
            LocalCacheService.setRecommendInfos($stateParams['recommendInfos']);
            par.recommendInfos = LocalCacheService.getRecommendInfos();
            par.mobile_tel = $.trim($stateParams['name']);
            par.source = CommonService.getSource();
            var params2 = {mobile_tel: par.mobile_tel, recommendInfos: par.recommendInfos, source: par.source};
            $scope.deposit_bank = new Array();
            //查询所有存管银行
            WebService.qryAllDepositBank().then(
                function(data){
                    for(var i=0; i < data.length; i++){
                        $scope.deposit_bank.push(data[i]);
                    }
                }
            );
       //     alert($stateParams['source']);
            // $.cookie('url','aaaaaaaaaa');
        //    alert(localStorage["indexUrl"]+'urlgetCookie');
      //      alert($stateParams);
            //alert(location.href.substring(location.href.indexOf('=')+1));
//            WebService.sendCheckCode(params2).then(
//                function(data){
//                    alert('去开户');
//
//
//                },
//                function(result){
//                    if("XCM-300002" == result.error_no){
//                        openAccountSus();
//                    }else{
//                        if(result.error_info){
//                            result.error_info = result.error_info.replace("参数传入错误,", "");
//                        }
//                        CommonService.showConfig({message:result.error_info});
//                    }
//                }
//            );

        }

//        function openAccountSus(){
//            $ionicPopup.confirm({
//                title: "提示",
//                template: "您已是天风证券客户，请直接登录",
//                okText:"去登录",
//                cancelText:"取消"
//            }).then(function(res) {
//                if(res) {
//                   window.location.href = "../../tap_1/view/index.html#/tab/login_android/"+$.trim(LocalCacheService.get('from_open_name'))+"/"+$.trim(LocalCacheService.get('from_open_token'))+"/"+$.trim( LocalCacheService.get('from_open_key'));
//                }
//            });
//        }
        $scope.close_android = function(){
           // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                //alert(JSON.stringify(localStorage["phone_index"])+'localStorage["phone_index"]');
                window.location.href = localStorage["phone_index"]||localStorage['test'];
              //  alert(localStorage["phone_index"]);
            }else{
               Messenger.send('close');
            }

        }
    }


    ctrl.$inject = ['$rootScope','$ionicPopup','$scope','$state','$stateParams','DictionaryService','$ionicLoading',
        '$ionicHistory','CommonService','LocalCacheService','ConcernService','WebService'];
    return ctrl;
});