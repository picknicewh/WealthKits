/**
 * Created by wang on 2015-10-16.
 */
/*global define */

define(function (require) {

    'use strict';

    var angular = require('angular'),
        animations = angular.module('app.animations',['ngAnimate']);

    animations.animation('.QDII-Top', require('animations/QDIITermAnimation'));

    return animations;
});