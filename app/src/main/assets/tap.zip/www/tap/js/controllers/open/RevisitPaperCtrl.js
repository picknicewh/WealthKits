define(function () {
    'use strict';

    function ctrl(LocalCacheService,$scope,$state,$ionicLoading,CommonService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function(){
            par.questions = new Array();

            init();
        });

        function init(){
            //查询回访问卷
            WebService.qryRevisitPaper().then(
                function(data){
                    for(var i=0;i<data.length;i++){
                        var question = data[i];
                        var answers = new Array();
                        $.each(question.answer_content,function (key,value){
                            answers.push({"key":key,"value":value});
                            question.answer_content = answers;
                        });
                        question.paper_answer = '';
                        question.question_idx = i+1;
                        par.questions.push(question);
                    }
                }
            );
        }

        $scope.radioClick = function(question_no,answer,default_answer){
            if(answer != default_answer){
                showMsg(question_no);
            }
        };

        $scope.close_android = function(){
            // alert(LocalCacheService.get('source')+'LocalCacheService.get(source)');
            if(LocalCacheService.get('source')=='dbgj'){
                window.location.href = localStorage["indexUrl"];
            }else{
                Messenger.send('close');
            }

        };
        $scope.back_android = function(){
            //alert(1);
            history.back();
        };

        $scope.submitPaper = function(){
            if(readyToSubmit()){
                $ionicLoading.show();
                var paper_answers = '';
                for(var i=0;i<par.questions.length;i++){
                    var question = par.questions[i];
                    paper_answers += question.question_no + '&' + question.paper_answer + '|';
                }
                var params = {paper_answer:paper_answers,source:CommonService.getSource()};
                WebService.submitRevisitPaper(params).then(
                    function(data){
                        $ionicLoading.hide();
                        //存管处理 0:未处理，1：处理成功，9：处理中 其它：处理失败
                        if("0,1,9".indexOf(data.open_status) > -1){
                            $state.go('open-openResult',{open_status:data.open_status});
                        }else{
                            //重新绑定存管
                            $state.go('open-bindOpenDeposit',{b:'0'});
                        }
                    }
                );
            }
        };

        function readyToSubmit(){
            for(var i=0;i<par.questions.length;i++) {
                var question = par.questions[i];
                if (CommonService.isStrEmpty(question.paper_answer)) {
                    CommonService.showAlert({message: '第' + question.question_idx + '题未答！'});
                    return false;
                }
            }
            for(var i=0;i<par.questions.length;i++) {
                var question = par.questions[i];
                if(question.paper_answer != question.default_answer){
                    showMsg(question.question_idx+'');
                    return false;
                }
            }
            return true;
        }

        function showMsg(nItemIdx){
            switch (nItemIdx){
                case '1':TF.Bubble.show("如不是本人意愿，无法成功申请账户！");break;
                case '2':TF.Bubble.show('请仔细阅读协议后，选择"是"，否则无法成功申请账户！');break;
                case '3':TF.Bubble.show("非本人设置密码将影响账户安全，无法成功申请账户！");break;
                case '4':TF.Bubble.show("若工作人员违规操作，请拨打我们客服电话反馈。否则无法成功申请账户！");break;
                case '5':TF.Bubble.show('请选择"是"，非本人操作将无法成功申请账户！');break;
            }
        }
    }

    ctrl.$inject = ['LocalCacheService','$scope','$state','$ionicLoading','CommonService','WebService'];
    return ctrl;
});