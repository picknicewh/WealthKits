define(function () {
    'use strict';

    function ctrl($scope, $filter, InfoService) {
        $scope.channel = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            //获取营地基金概况并添加事件
            return queryContentBriefs();
        }

        function queryContentBriefs(){
            return InfoService.getContentBriefs($scope.channel.channelId, 1).then(function(data){
                if(data){
                    $scope.items = data;
                    for(var i=0;i<data.length;i++){
                        var fund = $scope.items[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                    }
                }
            })
        }
    }

    ctrl.$inject = ['$scope','$filter', 'InfoService'];
    return ctrl;
});