define(function () {
    'use strict';

    function ctrl($scope,$filter,$ionicPopup,$q,CommonService,LocalCacheService,InfoService) {

        $scope.channels = {};
        $scope.vm = {};
        $scope.vm.activeTab=1;

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            //查询广告
            $scope.showAds();
            return $q.all([queryContentBriefs(), showChannelImg(), queryQSZGBriefs()]);
        }

        function showChannelImg(){
            var q = InfoService.getChannelInfos($scope.channels[0].channelId+ ","+ $scope.channels[1].channelId);
            q.then(function(data){
                if(data){
                    $scope.channels[0].imgSrc = data[0].content_img;
                    $scope.channels[0].imgAlt = data[0].channel_name;

                    $scope.channels[1].imgSrc = data[1].content_img;
                    $scope.channels[1].imgAlt = data[1].channel_name;
                }
            });
            return q;
        }

        $scope.showAds = function(type){
            InfoService.getAdSpace($scope.channels[0].adId).then(function(data){
                if(data) {
                    var adKey = "ad_" + $scope.channels[0].adId;
                    $scope.ads = data;
                    if((type || !LocalCacheService.get(adKey))&& $scope.ads.length > 0) {
                        var myPopup = $ionicPopup.show({
                            cssClass: 'popup-head-hide ',
                            templateUrl: "product/ads.html",
                            scope: $scope,
                            buttons: [
                                { text: '确定' }
                            ]
                        });
                        LocalCacheService.set(adKey, true);
                    }
                }
            });
        };

        $scope.showAdQszg = function(type){
            InfoService.getAdSpace($scope.channels[1].adId).then(function(data){
                if(data) {
                    $scope.ads = data;
                    var adKey = "ad_" + $scope.channels[1].adId;
                    if((type || !LocalCacheService.get(adKey)) && $scope.ads.length > 0) {
                        var myPopup = $ionicPopup.show({
                            cssClass: 'popup-head-hide ',
                            templateUrl: "product/ads.html",
                            scope: $scope,
                            buttons: [
                                { text: '确定' }
                            ]
                        });
                        LocalCacheService.set(adKey, true);
                    }
                }
            });
        };

        function queryContentBriefs(){
            //OTC查询
            var q = InfoService.getOTCBriefs($scope.channels[0].channelId , 1);
            q.then(function(data){
                if(data){
                    $scope.otcFunds = data;
                    for(var i=0;i<$scope.otcFunds.length;i++){
                        var fund = $scope.otcFunds[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                        if("0" == fund.otcStatus){
                            fund.bengin_date_show = CommonService.formatDate2(fund.ipoBeginDate);
                        }
                        //根据产品状况，控制按钮
                        if("0,3".indexOf(fund.prodStatus) > -1){
                            if("1" == fund.otcStatus){
                                fund.sellStatus = 1; // 可购买
                            }else if("2,3".indexOf(fund.otcStatus) > -1){
                                fund.sellStatus = 3; // 已售罄
                            }else {
                                fund.sellStatus = 2; //不可购买
                            }
                        }else if("2"==fund.prodStatus){
                            fund.sellStatus = 4; //暂停申购
                        }else{
                            if("2,3".indexOf(fund.otcStatus) > -1){
                                fund.sellStatus = 3;
                            }else{
                                fund.sellStatus = 5; //暂停交易
                            }
                        }
                    }
                }
            });
            return q;
        }

        function queryQSZGBriefs(){
            var q = InfoService.getContentBriefs($scope.channels[1].channelId, 1);
            q.then(function(data){
                if(data){
                    $scope.zgFunds = data;
                    for(var i=0;i<$scope.zgFunds.length;i++){
                        var fund = $scope.zgFunds[i];
                        fund.prodMinSubscribe = $filter('prodMinSubscribe')(fund.prodMinSubscribe);
                    }
                }
            });
            return q;
        }
    }

    ctrl.$inject = ['$scope','$filter','$ionicPopup','$q','CommonService','LocalCacheService','InfoService'];
    return ctrl;
});
