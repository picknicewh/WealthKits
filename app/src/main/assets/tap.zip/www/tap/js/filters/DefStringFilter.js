/**
 * Created by wang on 2015-9-22.
 * 有缺省值的String
 */
define(['angular'], function (angular) {
    "use strict";

    var filter = function () {
        /**
         * 原值 后缀 默认值
         */
        return function (text, suffix, def) {

            if(null == text || "undefined" == typeof(text) || "" == text){
               return "--";
            }else{
                if(angular.isDefined(suffix)) {
                    return text + suffix;
                }
                return text;
            }
        };
    };

    filter.$inject = [];
    return filter;
});