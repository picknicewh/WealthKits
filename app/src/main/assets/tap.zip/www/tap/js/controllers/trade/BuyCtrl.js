define(function() {
    'use strict';

    function ctrl($scope,$timeout,$stateParams,$state,$ionicPopup,$ionicLoading,$ionicHistory,$ionicModal,$rootScope,
                  $q,LocalCacheService,CommonService,InfoService,DictionaryService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
        //    alert($rootScope.ip);
            par.prodCode = $stateParams['prodCode'];
            par.prodSource = $stateParams['prodSource'];
            par.add = $stateParams['add'];

            $scope.name = $stateParams['name'];
            $scope.token_ = $stateParams['token'];
            $scope.key_ = $stateParams['key'];
          //  alert($stateParams['name']);
            init();
        });

        $scope.close_android = function(){
            Messenger.send('close');
        };
        $scope.from_caifu = false;

        function init(){
            par.isSuccess = false; // 是否显示结果页
            par.prodRiskLevel = ''; //产品风险等级
            par.continueBuyUrl = '';

            $scope.buy = {}; //页面值
            $scope.buy.checkProtocol = true;
            $scope.buy.checkRisk = true;
            $scope.pay = {};
            $scope.pay.payAccountStatus = -1;
            $scope.payWays = [];
            $scope.depositBankData = {}; //三方存管银信息
            $scope.quickBankData = {}; //快捷支付银行
            $scope.cmsProdInfo = {};
            $scope.ifsProdInfo = {};
            $scope.buy2 = {};

            createModel().then(afterCreateModel);

            WebService.getUserInfo().then(
                function(user){
                    $scope.user = user;
                    initEvent();
                }, function(){
                    LocalCacheService.removeUser();
                    $rootScope.$emit("userIntercepted","sessionOut");
                }
            );
        }

        function createModel(){
            var deferred = $q.defer();
            if(!$scope.buy2Modal) {
                $ionicModal.fromTemplateUrl("trade/buyStep2.html", {
                    scope: $scope,
                    animation: "slide-in-up"
                }).then(function(modal) {
                    $scope.buy2Modal = modal;
                    deferred.resolve();
                });
            } else {
                deferred.resolve();
            }
            return deferred.promise;
        }

        function afterCreateModel(){
            var pay = LocalCacheService.get("SelectPayWayCtrl_pay");
            var buy = LocalCacheService.get("BuyCtrl_buy");
            var forwardView = $ionicHistory.forwardView();
            if(buy) {
                $scope.buy = buy;
            }
            if(forwardView && (forwardView.stateName == "selectPayWay" || forwardView.stateName == "recharge-and-withdraw")) {
                queryPayInfo(pay);
            }
        }

        function initEvent(){
            //理财体验活动新增 可以直接买基金
            if(CommonService.isBuyExperience()) {
                par.continueBuyUrl = "#" + LocalCacheService.get("lcty_state").url;
            } else {
                par.continueBuyUrl = "#/tab/product-index";
            }
            //产品代码或产品类型为空，提示
            if(CommonService.isStrEmpty(par.prodCode) || CommonService.isStrEmpty(par.prodSource)){
                var alertPopup = CommonService.showConfig({title: "提示", message : "未选择任何产品"});
                $timeout(function() {
                    alertPopup.close();
                    $state.go("tab.product-index");
                }, 3000);
            }
            //查询用户使用已绑定存管银行
            WebService.getUserDepositBankCards().then(
                function (data) {
                    $scope.depositBankData = data;
                    queryQuickBank();
                },function (){
                    queryQuickBank();
                }
            );
        }

        function queryQuickBank(){
            WebService.getUserQuickBankCards().then(
                function (data){
                    $scope.quickBankData = data;
                    var depositBankData = $scope.depositBankData;
                    if("0,2".indexOf(par.prodSource) > -1){
                        if(depositBankData.length == 0){
                            noDepositBank();
                        }else if("1,3".indexOf(depositBankData[0].bkaccount_regflag) > -1){
                            depositBankOnWay(depositBankData[0].bkaccount_regflag);
                        }else{
                            queryProductInfo(par.prodCode, par.prodSource, queryIFSProdInfo);
                        }
                    }else{
                        if((depositBankData.length == 0 || "1,3".indexOf(depositBankData[0].bkaccount_regflag) > -1)
                            && $scope.quickBankData.length == 0 ){
                            noBankInfo();
                        }else{
                            queryProductInfo(par.prodCode, par.prodSource, queryIFSProdInfo);
                        }
                    }
                },function (){
                    noBankInfo();
                }
            )
        }
        $scope.userNum = 0;
        function getuserAll(){
            $scope.userNum++;
            if($scope.userNum==4){
                $.ajax({
                    type: 'POST',
                    url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                    data:{
                        token:$scope.token_,
                        secretKey:$scope.key_,
                        objective:2,
                        source:1,
                        values:JSON.stringify(LocalCacheService.get('data1'))
                    },

                    dataType : 'json',
                    //contentType : "application/json",
                    success : function(data) {
                        console.log(JSON.stringify(data)+'111111111111111');
                        if(data.resultCode=='0'){
//                                LocalCacheService.set('error2','has');
//                                LocalCacheService.set('errorInfo',data.resultDesc);
                            // CommonService.showAlert({message:data.resultDesc});
                      //      alert('传输成功！1');
                            $ionicLoading.hide();
                        }
//                            add_ajax();
                    },
                    error : function(XMLHttpRequest, textStatus, errorThrown) {
                        console.log(JSON.stringify(XMLHttpRequest, textStatus, errorThrown)+'111111111111111');
                        //alert("系统异常,加载失败1");
                    }

                });

                $.ajax({
                    type: 'POST',
                    url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                    data:{
                        token:$scope.token_,
                        secretKey:$scope.key_,
                        objective:1,
                        source:1,
                        values:JSON.stringify(LocalCacheService.get('data2'))
                    },

                    dataType : 'json',
                    //contentType : "application/json",
                    success : function(data) {
                        console.log(JSON.stringify(data)+'222222222222222222');
                        if(data.resultCode=='0'){
//                            LocalCacheService.set('error3','has');
//                            LocalCacheService.set('errorInfo',data.resultDesc);
                            //CommonService.showAlert({message:data.resultDesc});
                       //     alert('操作成功2');
                            $ionicLoading.hide();
                        }
//                        add_ajax();
                    },
                    error : function(w) {
                        console.log(JSON.stringify(w)+'22222222222');
                        //alert("系统异常,加载失败1");
                    }
                });

                $.ajax({
                    type: 'POST',
                    url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                    data:{
                        token:$scope.token_,
                        secretKey:$scope.key_,
                        objective:1,
                        source:1,
                        values:JSON.stringify(LocalCacheService.get('today_orders'))
                    },

                    dataType : 'json',
                    //contentType : "application/json",
                    success : function(data) {
                        console.log(JSON.stringify(data)+'222222222222222222');
                        if(data.resultCode=='0'){
//                            LocalCacheService.set('error3','has');
//                            LocalCacheService.set('errorInfo',data.resultDesc);
                            //CommonService.showAlert({message:data.resultDesc});
                            //     alert('操作成功2');
                            $ionicLoading.hide();
                        }
//                        add_ajax();
                    },
                    error : function(w) {
                        console.log(JSON.stringify(w)+'22222222222');
                        //alert("系统异常,加载失败1");
                    }
                });
                $.ajax({
                    type: 'POST',
                    url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                    data:{
                        token:$scope.token_,
                        secretKey:$scope.key_,
                        objective:0,
                        source:1,
                        values:JSON.stringify(LocalCacheService.get('data3'))
                    },

                    dataType : 'json',
                    //contentType : "application/json",
                    success : function(data) {
                        console.log(JSON.stringify(data)+'333333333333333333');
                        //LocalCacheService.set('success','a');
                        if(data.resultCode=='0'){
//                            LocalCacheService.set('error4','has');
//                            LocalCacheService.set('errorInfo',data.resultDesc);
                            // CommonService.showAlert({message:data.resultDesc});
                         //   alert('传输成功3');
                            $ionicLoading.hide();
                        }
                        //add_ajax();
                    },
                    error : function(w) {
                        console.log(JSON.stringify(w)+'33333333333333333333333');

                        //alert("系统异常,加载失败1");
                    }
                });
                $scope.userNum = 0;
            }

        }

        var queryProductInfo = function (prodCode,prodSource, func){
            InfoService.getChannelByProdCode(prodCode).then(function (data){
                if(data){
                    $scope.cmsProdInfo = data;
                    //显示产品名称及收益数据
                    if("0,1,2,3".indexOf($scope.cmsProdInfo.prodProfitMode) < 0){
                        CommonService.showConfig({message:"产品收益模式未配置:"+cmsProdInfo.prodCode});
                    }
                    //特殊产品，获取协议列表
                    func(prodCode,prodSource, queryEncontract);
                }else{
                    $ionicLoading.hide();
                    CommonService.showAlert({message:"未获取到产品信息"});
                }
            });
        };

        var queryIFSProdInfo =function (prodCode,prodSource, func){
            WebService.queryIFSProdInfo(prodCode,prodSource).then(
                function (ifsProdMsg){
                    if(ifsProdMsg.length == 1){
                        $scope.ifsProdInfo = ifsProdMsg[0];
                        //理财体验活动修改最小份额
                        if(CommonService.isBuyExperience()) {
                            var cmsProdInfo = $scope.cmsProdInfo;
                            if(cmsProdInfo.cmsMinSubscribe && cmsProdInfo.cmsMinSubscribe > $scope.ifsProdInfo.min_share2){
                                $scope.ifsProdInfo.min_share2 = cmsProdInfo.cmsMinSubscribe;
                                $scope.ifsProdInfo.open_share = cmsProdInfo.cmsMinSubscribe;
                                $scope.ifsProdInfo.allot_limitshare2 = cmsProdInfo.cmsMinSubscribe;
                            }
                        }
                        //产品风险等级与客户风险等级比对
                        if(prodSource == "0" || prodSource == "1"){
                            par.prodRiskLevel = prodToCusRiskLevel(prodSource,$scope.ifsProdInfo.prodrisk_level);
                        }else if(prodSource == "2"){
                            par.prodRiskLevel = prodToCusRiskLevel(prodSource,$scope.ifsProdInfo.ofund_risklevel);
                        }

                        //最低申购金额
                        var placeholderString;
                        if(prodSource=='0' || prodSource=='1'){
                            if(par.add=="1"){
                                //2:认购期 3:预约认购期 申购
                                if("2,3".indexOf($scope.ifsProdInfo.prod_status) > -1){
                                    placeholderString = placeholder($scope.ifsProdInfo.allot_limitshare);
                                }else{
                                    placeholderString = placeholder($scope.ifsProdInfo.allot_limitshare2);
                                }
                            }else{
                                placeholderString = placeholder($scope.ifsProdInfo.open_share);
                            }
                        }else{
                            if(par.add=="1"){
                                placeholderString = placeholder($scope.ifsProdInfo.person_pace);
                            }else{
                                placeholderString = placeholder($scope.ifsProdInfo.min_perfapp_balance);
                            }
                        }
                        $scope.buy.entrust_balance_placeholder = placeholderString;
                        func();
                    }else{
                        $ionicLoading.hide();
                        CommonService.showAlert({message:"基金信息查询失败"});
                    }
                }
            );
        };


        var queryEncontract = function (){
            var econtract_type;
            var ifsProdInfo = $scope.ifsProdInfo;
            if(ifsProdInfo.prodta_no){
                econtract_type = ifsProdInfo.prodta_no + "_" + ifsProdInfo.prod_code;
            } else {
                econtract_type = ifsProdInfo.fund_company + "_" + ifsProdInfo.fund_code;
            }
            WebService.getEncontractList(econtract_type).then(
                function (data){
                    if(data && data.length > 0){
                        $scope.agreementList = data;
                        $scope.econtract_type = econtract_type;
                    }
            });
            $ionicLoading.hide();
        };

        $scope.entrustBalanceBlur = function (){
            var entrust_balance = parseFloat($scope.buy.entrust_balance);
            if(isNaN(entrust_balance)){
                var placeholderString;
                if(par.prodSource=="1" || par.prodSource=="0"){
                    if(par.add){
                        placeholderString = placeholder($scope.ifsProdInfo.allot_limitshare2);
                    }else{
                        placeholderString = placeholder($scope.ifsProdInfo.min_share2);
                    }
                }else if(par.prodSource=="2"){
                    if(par.add){
                        placeholderString = placeholder($scope.ifsProdInfo.person_pace);
                    }else{
                        placeholderString = placeholder($scope.ifsProdInfo.min_perfapp_balance);
                    }
                }
                $scope.buy.entrust_balance_placeholder = placeholderString;
            }
        };

        $scope.next = function (){
            if(checkSetp1()){
                queryPayInfo();
            }
        };


        var checkSetp1 = function(){
            if(!$scope.buy.checkProtocol && $scope.agreementList){//选中
                CommonService.showAlert({message:"请勾选我已阅读并同意《"+cmsProdInfo.contentName+"》购买协议"});
                return false;
            }
            if((parseFloat($scope.user.corp_risk_level)<parseFloat(par.prodRiskLevel)) &&
                !$scope.buy.checkRisk){
                CommonService.showAlert({message:"请勾选同意购买的基金风险等级高于风险承受等级"});
                return false;
            }

            if(isNaN(parseFloat($scope.buy.entrust_balance))){
                CommonService.showAlert({message:"请正确输入委托价格"});
                return false;
            }
            if (!CommonService.checkRegex("^[0-9]+(.[0-9]{1,2})?$",$scope.buy.entrust_balance)) {
                $scope.buy.entrust_balance = parseFloat($scope.buy.entrust_balance.toFixed(2));
            }
            var entrust_balance= $scope.buy.entrust_balance;
            if(entrust_balance==0){
                CommonService.showAlert({message:"输入金额必须大于零"});
                return false;
            }
            var ifsProdInfo = $scope.ifsProdInfo;
            if(ifsProdInfo){
                if("0,1".indexOf(par.prodSource) > -1){
                    if(par.add=="1"){//追加
                        if("2,3".indexOf(ifsProdInfo.prod_status) > -1 &&
                            entrust_balance < parseFloat(ifsProdInfo.allot_limitshare)){
                            CommonService.showAlert({message:"输入金额应大于或等于最低追加金额"});
                            return false;
                        }
                        if(entrust_balance < parseFloat(ifsProdInfo.allot_limitshare2)){
                            CommonService.showAlert({message:"输入金额应大于或等于最低追加金额"});
                            return false;
                        }
                    }else{
                        if(entrust_balance < parseFloat(ifsProdInfo.open_share)){
                            CommonService.showAlert({message:"输入金额应大于或等于最低购买金额"});
                            return false;
                        }
                    }
                }else if(par.prodSource=="2"){
                    if(par.add=="1"){//追加
                        if(entrust_balance < parseFloat(ifsProdInfo.person_pace)){
                            CommonService.showAlert({message:"输入金额应大于或等于最低追加金额"});
                            return false;
                        }
                    }else{
                        if(entrust_balance < parseFloat(ifsProdInfo.min_perfapp_balance)){
                            CommonService.showAlert({message:"输入金额应大于或等于最低购买金额"});
                            return false;
                        }
                    }
                }
            }
            return true;
        };

        function queryPayInfo(pay){
            if(pay) {
                $scope.pay = pay;
                showConfirm();
            } else {
                WebService.checkPayStatus($scope.buy.entrust_balance).then(
                    function (data){
                        $scope.pay.payAccountStatus = data.status;
                        if(data.status == -1){
                            CommonService.showAlert({message:"查询支付方式失败,请检查保证金账户和快捷支付是否正常"});
                            return;
                        } else if(data.status == 1){//保证金足
                            $scope.pay.html = '<span class="txt">保证金账户余额支付</span>';
                            $scope.pay.pay_kind=0;
                            $scope.pay.bank_no=0;
                            $scope.pay.pay_account="";
                            $scope.pay.full=true; //保证金足
                        }else if(data.status == 4){//未开保证金和银行卡
                            noBankInfo();
                            return;
                        } else {
                            if(par.prodSource=='1'){
                                if(data.status == 2){//保证金不足
                                    if(data.card){//如果用户绑定了快捷支付卡，选中快捷支付卡
                                        var bankAccount = data.card.bank_account;
                                        $scope.pay.html= '<span class="title">快捷支付</span><span class="txt_m">' + data.card.bank_name + ' 尾号' + bankAccount.substring(bankAccount.length-3) + '</span>';
                                        $scope.pay.pay_kind=1;
                                        $scope.pay.bank_no=data.card.bank_no;
                                        $scope.pay.pay_account=bankAccount;
                                    }else{//无快捷支付卡 提示充值
                                        $scope.pay.html = '<span class="txt"><em>余额不足，请充值</em>保证金账户余额支付</span>';
                                        $scope.pay.pay_kind=0;
                                        $scope.pay.bank_no=0;
                                        $scope.pay.pay_account="";
                                    }
                                }else if(data.status == 3){//快捷支付
                                    var bankAccount = data.card.bank_account;
                                    $scope.pay.html= '<span class="title">快捷支付</span><span class="txt_m">' + data.card.bank_name + ' 尾号' + bankAccount.substring(bankAccount.length-3) + '</span>';
                                    $scope.pay.pay_kind=1;
                                    $scope.pay.bank_no=data.card.bank_no;
                                    $scope.pay.pay_account=bankAccount;
                                }
                            }else if(par.prodSource=='0' || par.prodSource=='2'){
                                if(data.status == 2 || data.status == 3){//保证金不足
                                    $scope.pay.html = '<span class="txt"><em>余额不足，请充值</em>保证金账户余额支付</span>';
                                    $scope.pay.pay_kind=0;
                                    $scope.pay.bank_no=0;
                                    $scope.pay.pay_account="";
                                }
                            }
                        }
                        showConfirm();
                    }
                );
            }
        }

        $scope.closeModal = function() {
            $scope.buy2Modal.hide();
        };

        $scope.$on('$destroy', function() {
            $scope.buy2Modal.remove();
        });

        function showConfirm(){
            $scope.buy2.password = null;
            LocalCacheService.set("BuyCtrl_buy", $scope.buy); //保存购买的金额
            $scope.buy2Modal.show();
        }

        //选择其他支付方式
        $scope.selectOtherPayWay = function() {
            if(par.prodSource=='2' && ($scope.pay.payAccountStatus=='1' || $scope.pay.payAccountStatus=='3')){
                return false;
            }
            LocalCacheService.set("BuyCtrl_pay", $scope.pay);
            LocalCacheService.set("BuyCtrl_quickBankData", $scope.quickBankData);
            $scope.buy2Modal.hide();
            $state.go("selectPayWay");
        };

        $scope.goRecharge = function() {
            LocalCacheService.set("BuyCtrl_pay", $scope.pay);
            LocalCacheService.set("BuyCtrl_quickBankData", $scope.quickBankData);
            $scope.buy2Modal.hide();
            $state.go("recharge-and-withdraw");
        };

        var noDepositBank = function(){
            $ionicPopup.show({
                template: '<p>抱歉，该产品需绑定三方存管银行才可购买。您需要再绑定一张三方存管银行卡。</p>'+
                        '<a href="#/help?key=help/bank/bank_introduce" class="fs0 clr1">为什么要绑定三方存管银行卡？</a>',
                title: '未绑定存管银行',
                buttons: [
                    { text: '取消',
                        onTap: function(e) {
                            $ionicHistory.goBack();
                    }},
                    { text: '<b>立即绑定</b>',
                        type: 'button-positive',
                        onTap: function(e) {
                            $state.go("tab.account-bindDepositBank");
                        }
                    }
                ]
            });
        };

        var depositBankOnWay = function(regflag){
            var title = "绑定存管银行未确认";
            var str = '抱歉，您的三方存取已在受理中，请等待确认后再购买。';
            if("1" == regflag){
                title = "绑定存管银行未激活";
                str = '抱歉，您的三方存取尚未激活，请激活后再购买。';
            }
            $ionicPopup.show({
                template: '<div class="panel"><div class="item">'+str+'	</div></div>',
                title: title,
                buttons: [
                    { text: '确定',
                        onTap: function(e) {
                            $ionicHistory.goBack();
                        }}
                ]
            });
        };

        var noBankInfo = function(){
            $ionicLoading.hide();
            $ionicPopup.show({
                template: '您还未绑定任何银行卡，请绑定银行卡后再进行购买。',
                title: '提示',
                buttons: [
                    { text: '取消',
                        onTap: function(e) {
                            $ionicHistory.goBack();
                        }},
                    { text: '<b>立即绑定</b>',
                        type: 'button-positive',
                        onTap: function(e) {
                            $state.go("tab.account-bank");
                        }
                    }
                ]
            });
        };

        function checkStep2(){
            if($scope.pay.pay_kind == 0 && !$scope.pay.full){
                if(par.prodSource=='0' || par.prodSource=='2') {
                    CommonService.showAlert({message:"保证金余额不足，请充值"});
                } else {
                    CommonService.showAlert({message:"保证金余额不足，请充值或选择其他支付方式"});
                }
                return false;
            }
            var password = $scope.buy2.password;
            if(CommonService.isStrEmpty(password)){
                CommonService.showAlert({message:"请输入交易密码"});
                return false;
            }
            return true;
        }

        $scope.submitBuy = function(){
            if(checkStep2()){
                $ionicLoading.show("正在提交购买请求");
                var buyPromise = null;
                if(par.prodSource=='0'){
                    buyPromise = WebService.buyBankProduct($scope.ifsProdInfo.prod_code, $scope.buy2.password, $scope.buy.entrust_balance, $scope.pay.pay_kind,
                        $scope.pay.bank_no, $scope.pay.pay_account, $scope.ifsProdInfo.prodta_no, $scope.cmsProdInfo.contentName, $scope.cmsProdInfo.prodBeginDate);
                }else if(par.prodSource=='1'){
                    buyPromise = WebService.buyDjProduct($scope.ifsProdInfo.prod_code, $scope.buy2.password, $scope.buy.entrust_balance, $scope.pay.pay_kind,
                        $scope.pay.bank_no, $scope.pay.pay_account, $scope.ifsProdInfo.prodta_no, $scope.cmsProdInfo.contentName, $scope.cmsProdInfo.prodBeginDate);
                }else if(par.prodSource=='2'){
                    buyPromise = WebService.buyUfProduct($scope.ifsProdInfo.fund_code, $scope.ifsProdInfo.fund_company, $scope.buy2.password, $scope.buy.entrust_balance,
                        $scope.ifsProdInfo.charge_type, $scope.cmsProdInfo.contentName, $scope.cmsProdInfo.prodBeginDate);
                }
                buyPromise.then(
                    function (data){
                        $ionicLoading.hide();
                        buySuccess(data);
                    }, function (result){
                        $ionicLoading.hide();
                        if("XCM-300001" == result.error_no) {//显示通知
                            CommonService.showNotice(result.error_info);
                        }else if("XCM-100001" == result.error_no || result.error_no.indexOf("160073") > -1){
                            CommonService.showAlert({message:result.error_info});
                        }else{
                            CommonService.showConfig({message:result.error_info});
                        }
                    }
                );
            }
        };

        function buySuccess(data){
            $scope.buy2Modal.hide();
            LocalCacheService.remove("SelectPayWayCtrl_pay");
            if(CommonService.isBuyExperience()) {//理财体验活动
                location.href = localStorage["redirect_url"];
            }
            //显示收益时间
            par.isSuccess = true;
            $scope.success = data;



            WebService.getUserQuickBankCards().then(function() {
                console.log(JSON.stringify(LocalCacheService.get('data1')) + '银行卡信息');
                getuserAll();
            });
            WebService.queryHisOrders().then(function(){
                console.log(JSON.stringify(LocalCacheService.get('data2'))+'交易记录');
                getuserAll();
            });
            WebService.queryCurOrders().then(function(){
                console.log(JSON.stringify(LocalCacheService.get('today_orders'))+'当日交易记录');
                getuserAll();
            });
            WebService.getAllShares().then(function(){
                console.log(JSON.stringify(LocalCacheService.get('data3'))+'资产');
                getuserAll();
            });



            var start_date = data.profit_start_date;
            var show_date = data.profit_show_date;
            var begin_date = $scope.cmsProdInfo.prodBeginDate;
            //起始收益日 显示收益日
            if(!CommonService.isStrEmpty(start_date) && !CommonService.isStrEmpty(show_date)){
                $scope.success.type = 1;
                var profitStartDate = new Date(start_date.substr(0,4),parseFloat(start_date.substr(4,2))-1,start_date.substr(6,2));
                $scope.success.income_begin_time = new XDate(profitStartDate).toString("MM-dd") + " " + weeks[profitStartDate.getDay()];
                var profitShowDate = new Date(show_date.substr(0,4),parseFloat(show_date.substr(4,2))-1,show_date.substr(6,2));
                $scope.success.income_show_time = new XDate(profitShowDate).toString("MM-dd") + " " + weeks[profitShowDate.getDay()];
                //产品成立日
            }else{
                $scope.success.type = 2;
                $scope.success.begin_time = '产品成立当日确认购买份额，开始计算收益<p>第二个交易日开始显示收益</p>';
                if(!CommonService.isStrEmpty(begin_date) && begin_date.length >=8){
                    var prodBeginDate = new Date(begin_date.substr(0,4),parseFloat(begin_date.substr(4,2))-1,begin_date.substr(6,2));
                    $scope.success.begin_time = new XDate(prodBeginDate).toString("MM-dd") + " " + weeks[prodBeginDate.getDay()];
                }
            }
            //查询渠道是否有问卷
            WebService.getChannelPaper(par.prodCode, $scope.buy.entrust_balance).then(function (data){
                if(data && data.paper_id && data.remaining_number > 0){
                    showChannelRisk(data.paper_id, par.prodCode);
                }
            },function (result){});


        }

        //渠道问卷
        function showChannelRisk(paper_id, prodCode){
            $ionicPopup.show({
                template: '您已完成购买，请填写“理财增值100”问卷即可拿100元红包。',
                cssClass: 'popup-head-hide',
                buttons: [
                    { text: '不参加'},
                    { text: '<b>参加填写</b>',
                        type: 'button-positive',
                        onTap: function(e) {
                            $state.go("open-channelRisk", {paper_id : paper_id, product_no: prodCode});
                        }
                    }
                ]
            });
        }

        function placeholder(share){
            var str = "";
            if(share == 0){
                str = "购买金额需≥0.01元";
            }else{
                str = "购买金额需≥"+ share + "元";
            }
            return str;
        }

        function prodToCusRiskLevel(prodSource,prodrisk_level){
            var prodToCusTiskLevel = 0;
            if(prodSource == 0 || prodSource == 1){
                //银行理财、证券理财
                switch(prodrisk_level){
                    case "0":prodToCusTiskLevel = 0;
                        break;
                    case "1":prodToCusTiskLevel = 1;
                        break;
                    case "2":case "3":prodToCusTiskLevel = 2;
                    break;
                    case "4":prodToCusTiskLevel = 3;
                        break;
                    case "5":case "6":prodToCusTiskLevel = 4;
                    break;
                    default:prodToCusTiskLevel = 0;
                        break;
                }
            }else{
                //集中交易
                switch (prodrisk_level){
                    case "0":prodToCusTiskLevel = 0;
                        break;
                    case "1":case "2":prodToCusTiskLevel = 1;
                    break;
                    case "3":prodToCusTiskLevel = 2;
                        break;
                    case "4":prodToCusTiskLevel = 4;
                        break;
                    default:prodToCusTiskLevel = 0;
                        break;
                }
            }
            return prodToCusTiskLevel;
        }
        var weeks = DictionaryService.getWeeks();
    }

    ctrl.$inject = ['$scope','$timeout','$stateParams','$state','$ionicPopup','$ionicLoading','$ionicHistory','$ionicModal','$rootScope',
        '$q','LocalCacheService','CommonService','InfoService','DictionaryService','WebService'];
    return ctrl;
});
