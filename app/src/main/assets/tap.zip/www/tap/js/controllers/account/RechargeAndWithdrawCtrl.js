define(function () {
    'use strict';

    function ctrl($scope) {

        $scope.vm = {};
        $scope.vm.activeTab = 1;

        $scope.doRefresh = function() {
            $scope.$broadcast('transferDetailsRefresh');
            $scope.$broadcast('scroll.refreshComplete');
        };

    }
    ctrl.$inject = ['$scope'];
    return ctrl;

});
