/**
 * Created by wang on 2015-10-26.
 */
define(function () {
    'use strict';

    function ctrl($scope,$filter,$stateParams,CommonService,InfoService,WebService) {
        var par = $scope.param = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.fund = {};
            par.otc_theme_id =$stateParams['id'];
            par.sellStatus = true;

            init();
        });

        $scope.doRefresh = function() {
            init();
            $scope.$broadcast("scroll.refreshComplete");
        };

        function init(){
            //获取OTC产品信息
            InfoService.getOTCBriefs(par.otc_theme_id , 1).then(
                function(data){
                    if(data && data.length > 0){
                        $scope.fund = data[0];
                        $scope.fund.prodMinSubscribe = $filter('prodMinSubscribe')($scope.fund.prodMinSubscribe,3);
                        if($scope.fund.ipoBeginDate == $scope.fund.ipoEndDate){
                            $scope.fund.sell_time_show = CommonService.formatDate2($scope.fund.ipoBeginDate) + '  仅1天';
                        }else{
                            $scope.fund.sell_time_show = CommonService.formatDate2($scope.fund.ipoBeginDate) +
                                ' ~ ' + CommonService.formatDate2($scope.fund.ipoEndDate);
                        }
                        if("2,3".indexOf($scope.fund.otcStatus) > -1){
                            par.sellStatus = false;
                        }
                    }
                }
            );
        }
    }

    ctrl.$inject = ['$scope','$filter','$stateParams','CommonService','InfoService','WebService'];
    return ctrl;
});