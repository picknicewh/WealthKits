/**
 * 开户退出按钮 指令控制
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function ($ionicPlatform,$ionicPopup,LocalCacheService,$state) {
        return {
            restrict: "E",
            replace:true,
            template: '<a class="header-item btnExit" ng-click="onExitKeyDown()">退出</a>',
            link: function(scope) {
                if(!scope.onExitKeyDown){
                    scope.onExitKeyDown = function(){
                        $ionicPopup.confirm({
                            title: "提示",
                            template: "您确定要退出开户吗？",
                            okText:"确定",
                            cancelText:"取消"
                        }).then(function(res) {
                            if(res) {
                                $state.go("tab.index");
                                //销毁用户信息
                                LocalCacheService.removeOpenUser();
                            }
                        });
                    };
                }
                if(ionic.Platform.isAndroid()){
                    $ionicPlatform.registerBackButtonAction(function (e) {
                        scope.onExitKeyDown();
                        e.preventDefault();
                        return false;
                    }, 101);
                }
            }
        }
    };

    directive.$inject = ['$ionicPlatform','$ionicPopup','LocalCacheService','$state'];
    return directive;
});