define(function (require, exports, module) {
    'use strict';

    function ctrl($scope,$stateParams,$filter,$timeout,InfoService,WebService) {

        var par = $scope.param = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.fund = {};
            $scope.info = {};
            par.contentId = $stateParams['contentId'];

            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            //获取cms基金详情
            return InfoService.getOTCGeneral(par.contentId).then(function(data){
                if(data){
                    $scope.fund = data;
                    $scope.fund.dataDate = new Date().getTime();
                    $scope.fund.prodMinSubscribe_show = $filter('prodMinSubscribe')($scope.fund.prodMinSubscribe);
                    //根据产品状况，控制按钮
                    if("0,3".indexOf($scope.fund.prodStatus) > -1){
                        if("1" == $scope.fund.otcStatus){
                            $scope.fund.sellStatus = 1; // 可购买
                        }else if("2,3".indexOf($scope.fund.otcStatus) > -1){
                            $scope.fund.sellStatus = 3; // 已售罄
                        }else {
                            $scope.fund.sellStatus = 2;
                        }
                        //查询销售信息
                        if($scope.fund.sellStatus == 1 || $scope.fund.sellStatus == 2){
                            querySellInfo($scope.fund.prodCode);
                        }
                    }else if("2"==$scope.fund.prodStatus){
                        $scope.fund.sellStatus = 4; //暂停申购
                    }else{
                        if("2,3".indexOf($scope.fund.otcStatus) > -1){
                            $scope.fund.sellStatus = 3;
                        }else{
                            $scope.fund.sellStatus = 5; //暂停交易
                        }
                    }
                }
            });
        }

        function querySellInfo(prod_code){
            WebService.querySellInfo(prod_code).then(
                function (data){
                    if(data && data.length > 0){
                        $scope.info = data[0];
                        //定时刷新
                        if("1" ==  $scope.fund.sellStatus){
                            $timeout(function(){
                                querySellInfo(prod_code);
                            },30000);
                        }
                        //已售罄
                        if("1" == $scope.info.soldout_flag){
                            $scope.fund.sellStatus = 3; // 已售罄
                        }
                    }
                }
            );
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$filter','$timeout','InfoService', 'WebService'];
    return ctrl;
});