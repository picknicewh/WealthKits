define(function () {
    'use strict';

    function ctrl($scope,$ionicLoading,$timeout,$ionicScrollDelegate,LocalCacheService,CommonService,WebService) {

        var par = $scope.param = {};
        par.risk_step = 3;
        par.questions = new Array();

        $scope.$on('$ionicView.beforeEnter', function() {
            par.risk_step = 3;
            par.questions = new Array();
            $scope.user = LocalCacheService.getUser();

            init();
        });

        function init(){
            WebService.getRiskPaper().then(
                function (data){
                    for(var i = 0; i < data.length; i++){
                        var question = data[i];
                        var answers = new Array();
                        $.each(question.answer_content,function (key,value){
                            answers.push({"key" : key,"value" : value});
                            question.answer_content = answers;
                        });
                        question.paper_answer = '';
                        question.question_idx = i+1;
                        par.questions.push(question);
                    }
                }
            );
        }

        $scope.expandClick = function(){
            par.risk_step=2;
            $timeout(function(){
                $ionicScrollDelegate.resize();
            }, 500);
        };

        $scope.submitClick = function(){
            if(readyToSubmit()){
                $ionicLoading.show();
                var paper_answers = '';
                for(var i=0;i<par.questions.length;i++){
                    var question = par.questions[i];
                    paper_answers += question.question_no + '&' + question.paper_answer + '|';
                }
                //isReSubmit设置为1，标示后台不做修改用户信息操作
                var params = {paper_answer:paper_answers,isReSubmit:"1",source:CommonService.getSource()}
                WebService.submitPaper(params).then(
                    WebService.getUserInfo().then(
                        function (result) {
                            $ionicLoading.hide();
                            LocalCacheService.setUser(result);
                            $ionicScrollDelegate.scrollTop();
                            $scope.user = LocalCacheService.getUser();
                            par.risk_step = 3;
                        }
                    )
                );
            }
        };

        $scope.showLevelDetail = function(){
            //FXJGJS 中台风险等级字典查询
            var params = {dict_entry:'FXJGJS',subentry:$scope.user.corp_risk_level};
            WebService.qryDictInfo(params).then(
                function(data){
                    var msg = "--";
                    if(data && data.length > 0){
                        msg = data[0].dict_prompt;
                    }
                    CommonService.showConfig({okText: '我知道了',message : $scope.user.risk_level_name + "：" + msg});
                }
            );
        };


        $scope.close_android = function(){
            Messenger.send('close');
        };


        function readyToSubmit(){
            for(var i=0;i<par.questions.length;i++){
                var question = par.questions[i];
                if('0' == question.question_kind && CommonService.isStrEmpty(question.paper_answer)){
                    CommonService.showAlert({message:'第' + question.question_idx + '题未答！'});
                    return false;
                }
                if('1' == question.question_kind){
                    var answer_content = question.answer_content;
                    var paper_answer = '';
                    for(var j=0;j<answer_content.length;j++){
                        if(answer_content[j].checked){
                            paper_answer += answer_content[j].key + '&';
                        }
                    }
                    if(CommonService.isStrEmpty(paper_answer)){
                        CommonService.showAlert({message:'第' + question.question_idx + '题未答！'});
                        return false;
                    }else{
                        question.paper_answer = paper_answer.substring(0,paper_answer.length-1);
                    }
                }
            }
            if(!par.risk_warn){
                CommonService.showAlert({message:"请勾选《本人确认已理解上述风险测评内容，愿意承担由此带来的风险。》"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$ionicLoading','$timeout','$ionicScrollDelegate','LocalCacheService','CommonService','WebService'];
    return ctrl;
});