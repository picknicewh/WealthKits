/**
 * Created by wang on 2015-10-16.
 * 关注服务
 */
define(['angular'], function (angular) {
    "use strict";

    var factory = function (LocalCacheService, CommonService) {
        return {
            //是否关注
            isConcern : function(prodCode){
                var userCare = LocalCacheService.get("userCare");
                if(userCare) {
                    for (var i = 0; i < userCare.length; i++) {
                        if (userCare[i] == prodCode) {
                            return true;
                        }
                    }
                }
                return false;
            },
            //关注 or 取消关注
            concern : function(prodCode){
                var userCare = LocalCacheService.get("userCare");
                if(!userCare || userCare.length <= 0) {
                    userCare = new Array();
                    userCare.push(prodCode);
                    LocalCacheService.set("userCare", userCare);
                    CommonService.showAlert({message:"关注成功！"});
                    return true;
                }else{
                    var index = userCare.indexOf(prodCode);
                    if(index > -1){
                        userCare.splice(index, 1);
                        LocalCacheService.set("userCare", userCare);
                        CommonService.showAlert({message:"已取消关注."});
                        return false;
                    }else{
                        userCare.push(prodCode);
                        LocalCacheService.set("userCare", userCare);
                        CommonService.showAlert({message:"关注成功！"});
                        return true;
                    }
                }
            },
            //关注列表
            getConcernList : function(){
                var cares_str = '';
                var userCare = LocalCacheService.get("userCare");
                if(userCare && userCare.length > 0) {
                    cares_str = userCare.join(",");
                }
                return cares_str;
            }
        }
    };

    factory.$inject = ['LocalCacheService', 'CommonService'];
    return factory;
});