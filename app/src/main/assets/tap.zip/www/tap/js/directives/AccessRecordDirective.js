/**
 * Created by wang on 2016-1-16.
 * 友盟提供的访问统计
 */
define(['angular'], function (angular) {
    "use strict";

    var directive = function () {
        return {
            restrict: "A",
            link: function( scope, element, attrs) {
                if(attrs.key && typeof Messenger != 'undefined') {
                    element.bind( "click", function() {
                        var options = attrs.option;
                        var attributes = {};
                        if(options) {
                            var oList = options.split(",");
                            for(var i =0; i<oList.length; i++){
                                var keyValue = oList[i].split(":");
                                attributes[keyValue[0]] = keyValue[1];
                            }
                        }
                        Messenger.sendMsg("ym_event",{eventID:attrs.key, attributes: attributes},null,null);
                    });
                }
            }
        }
    };

    directive.$inject = [];
    return directive;
});