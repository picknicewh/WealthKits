define([ 'app','routes'], function (app) {
    'use strict';

    var onDeviceReady = function () {
            cordova.plugins.Keyboard.disableScroll(true);
            angular.bootstrap(document, [app.name]);
        };
        
        
// ios cordova.js 恢复至本地cache目录
//    var isLoadCordova = false;
//    if(typeof cordova === 'undefined'&& location.href.indexOf("abs_path=") != -1) {
//        var p = location.href.toString().split("abs_path=")[1].split("&")[0];
//        if(p && p != "" ){
//            isLoadCordova = true;
//            var script = document.createElement('script');
//            script.charset="utf-8";
//            script.src = decodeURIComponent(p);
//            script.async = "async";
//            document.head.appendChild(script);
//        }
//    }

    document.addEventListener("deviceready", onDeviceReady, false);

    if (typeof cordova === 'undefined' && !isLoadCordova) {

        angular.element().ready(function () {
            try {
                angular.bootstrap(document, [app.name]);
            } catch (e) {
                var errorInfo = e.stack || e.message || e;
                if(typeof Messenger != 'undefined') {
                    Messenger.sendMsg("ym_reportError",{error:errorInfo} ,null,null);
                }
                console.error(errorInfo);
            }
        });
    }

});