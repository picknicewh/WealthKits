define(function () {
    'use strict';

    function ctrl($scope,$timeout,CommonService,WebService) {

        var par = $scope.param = {};
        par.step1=true;
        par.step2=false;
        par.step3=false;

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            //数字证书协议id特殊标识
            var agreement_no = 'cert';
            WebService.getEncontract(agreement_no).then(
                function(data){
                    par.econtract_name = data.econtract_name;
                    par.econtract_content = data.econtract_content;
                }
            );
        }

        $scope.agree = function(){
            par.step1=false;
            par.step2=true;
            WebService.certInstall().then(
                function(data){
                    $timeout(function (){
                        par.step2=false;
                        par.step3=true;
                    },2000);
                },
                function(result){
                    CommonService.showAlert({message: "证书安装失败，请重试"});
                    par.step1=true;
                    par.step2=false;
                }
            );
        };
    }

    ctrl.$inject = ['$scope','$timeout','CommonService','WebService'];
    return ctrl;
});