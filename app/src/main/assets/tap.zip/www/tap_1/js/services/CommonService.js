/*global define, console */

define(['angular'], function (angular) {
    "use strict";

    var factory = function ($location, $http, $httpParamSerializerJQLike, $rootScope, $state, $q, $ionicLoading, $ionicPopup, LocalCacheService, CacheFactory, CACHE_MAX_AGE) {


        CacheFactory('xcmCache', {deleteOnExpire: 'none', maxAge: CACHE_MAX_AGE, storageMode: 'localStorage', storagePrefix: "tfzq."});

        return {
            productPageUrl: function (prodProfitMode, prodSource) {
                var url = null;
            if ("0,3".indexOf(prodProfitMode) > -1) {
                url = "tab/product-item";
            } else if ("1" == prodProfitMode) {
                url = "tab/product-item-QDII";
            } else if ("2" == prodProfitMode) {
                url = "tab/product-item";
                if ("1" == prodSource) {
                    url = "tab/product-item-otc";
                }
            }
                return url;
        },
            ajax: function (options) {
                return _ajax(options);
            },
            getUrlParams: function () {
                return $location.search();
            },
            position: function () {
                if (ionic.Platform.isIOS()) {
                    $('header').css("position", "absolute");
                    $('.service-tel').css("position", "absolute");
                }
            },
            jsGetAge: function (strBirthday) { //获取周岁
                var returnAge;
                var birthYear = strBirthday.substr(0, 4);
                var birthMonth = strBirthday.substr(4, 2);
                var birthDay = strBirthday.substr(6, 8);

                var d = new Date();
                var nowYear = d.getFullYear();
                var nowMonth = d.getMonth() + 1;
                var nowDay = d.getDate();

                if (nowYear == birthYear) {
                    returnAge = 0;//同年 则为0岁
                } else {
                    var ageDiff = nowYear - birthYear; //年之差
                    if (ageDiff > 0) {
                        if (nowMonth == birthMonth) {
                            var dayDiff = nowDay - birthDay;//日之差
                            if (dayDiff < 0) {
                                returnAge = ageDiff - 1;
                            } else {
                                returnAge = ageDiff;
                            }
                        } else {
                            var monthDiff = nowMonth - birthMonth;//月之差
                            if (monthDiff < 0) {
                                returnAge = ageDiff - 1;
                            } else {
                                returnAge = ageDiff;
                            }
                        }
                    } else {
                        returnAge = -1;//返回-1 表示出生日期输入错误 晚于今天
                    }
                }
                return returnAge;//返回周岁年龄
            },
            checkIdCard: function (num) {

                var bdate; // 生日
                num = num.toUpperCase();
                //身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X。
                if (!(/(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(num))) {
                    //alert('输入的身份证号长度不对，或者号码不符合规定！\n15位号码应全为数字，18位号码末位可以为数字或X。');
                    return false;
                }
                //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                //下面分别分析出生日期和校验位
                var len, re;
                len = num.length;
                if (len == 15) {
                    re = new RegExp(/^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/);
                    var arrSplit = num.match(re);
                    //检查生日日期是否正确
                    var dtmBirth = new Date('19' + arrSplit[2] + '/' + arrSplit[3] + '/' + arrSplit[4]);
                    var bGoodDay;
                    bGoodDay = (dtmBirth.getYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
                    if (!bGoodDay) {
                        //alert('输入的身份证号里出生日期不对！');
                        return false;
                    } else {
                        bdate = '19' + arrSplit[2] + arrSplit[3] + arrSplit[4];
                        //将15位身份证转成18位
                        //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                        var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                        var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                        var nTemp = 0, i;
                        num = num.substr(0, 6) + '19' + num.substr(6, num.length - 6);
                        for (i = 0; i < 17; i++) {
                            nTemp += num.substr(i, 1) * arrInt[i];
                        }
                        num += arrCh[nTemp % 11];
                        return bdate;
                    }
                }
                if (len == 18) {
                    re = new RegExp(/^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/);
                    var arrSplit = num.match(re);
                    //检查生日日期是否正确
                    var dtmBirth = new Date(arrSplit[2] + "/" + arrSplit[3] + "/" + arrSplit[4]);
                    var bGoodDay;
                    bGoodDay = (dtmBirth.getFullYear() == Number(arrSplit[2])) && ((dtmBirth.getMonth() + 1) == Number(arrSplit[3])) && (dtmBirth.getDate() == Number(arrSplit[4]));
                    if (!bGoodDay) {
                        //alert(dtmBirth.getYear());
                        //alert(arrSplit[2]);
                        //alert('输入的身份证号里出生日期不对！');
                        return false;
                    }
                    else {
                        bdate = arrSplit[2] + arrSplit[3] + arrSplit[4];
                        //检验18位身份证的校验码是否正确。
                        //校验位按照ISO 7064:1983.MOD 11-2的规定生成，X可以认为是数字10。
                        var valnum;
                        var arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2);
                        var arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
                        var nTemp = 0, i;
                        for (i = 0; i < 17; i++) {
                            nTemp += num.substr(i, 1) * arrInt[i];
                        }
                        valnum = arrCh[nTemp % 11];
                        if (valnum != num.substr(17, 1)) {
                            //alert('18位身份证的校验码不正确！应该为：' + valnum);
                            return false;
                        }
                        return bdate;
                    }
                }
                return false;
            },
            /**
             * 字符串是否为空
             * @param param
             * @returns {boolean}
             */
            isStrEmpty: function (param) {
                if (null == param || "undefined" == typeof(param) || "" == $.trim(param)) {
                    return true;
                }
                return false;
            },
            controlNum: function (param, num) {
                if (null == param || "undefined" == typeof(param) || "" == param || isNaN(param)) {
                    return "--";
                } else {
                    return parseFloat(parseFloat(param).toFixed(num));
                }
            },
            /**
             * 展示普通弹出框
             * @param options(Json Object){
		 * 		message:弹出层内容 jQuery对象或字符串
		 * 		fixed：是否固定最小高度和宽度，默认true 表示需要固定
		 * 			以下参数只在 fixed 为true时有效
		 *			width:最小宽度 单位：像素
		 * 			height：最小高度 单位：像素
		 * 		}
             * @returns
             */
            getSource: function () { //渠道统计使用
                var source;
                if (ionic.Platform.isAndroid()) {
                    source = "ANDROID";
                } else if (ionic.Platform.isIOS()) {
                    source = "IOS";
                } else if (this.isWeixin()) {
                    source = "WEIXIN";
                } else {
                    source = "OTHER";
                }
                return source;
            },
            showAlert: function (options) {
                var $m = options.message;
                var opts = $.extend({}, options, {message: $m});
                if ($.type($m) === "object") {//对象
                    var css = position(options);
                    $.extend(opts, {css: css});
                }
                show(opts);
            },

            showlogin:function(obj){
                return _showlogin();
            },

            showNotice: function (str, key) {
                var contents = str.split("&&");
                if (!key || (!sessionStorage[key] || sessionStorage[key] != 1)) {
                    $ionicPopup.show({
                        template: contents[1],
                        title: contents[0],
                        buttons: [
                            { text: '关闭'},
                        ]
                    }).then(function () {
                        if (key) {
                            sessionStorage[key] = 1;
                        }
                    });
                }

            },
            showConfig: function (options) {
                return _showConfig(options);
            },
            /**
             * 是否是购买体验活动
             */
            isBuyExperience: function () {
                var lcty_state = LocalCacheService.get("lcty_state");
                if (lcty_state && lcty_state.stateName) {
                    return true;
                }
                return false;
            },
            /**
             * 判断是否为微信
             * @returns {boolean}
             */
            isWeixin: function () {
                var ua = navigator.userAgent.toLowerCase();
                if (ua.match(/MicroMessenger/i) == "micromessenger") {
                    return true;
                } else {
                    return false;
                }
            },
            /**
             * 获取错误信息
             * @param result
             * @returns {*}
             */
            getErrorInfo: function (result) {
                return _getErrorInfo(result);
            },
            stringToDate: function (dateString) {
                var d = new Date();
                d.setFullYear(parseInt(dateString.substr(0, 4)), parseInt(dateString.substr(4, 2)) - 1, parseInt(dateString.substr(6, 2)));
                return d;
            },
            formatDate: function (date) {
                if (null == date || "" == date || "undefined" == typeof(date)) {
                    return '--';
                }
                date = date.substr(0, 4) + "-" + date.substr(4, 2) + "-" + date.substr(6, 2);
                return date;
            },
            formatDate2: function (date) {
                if (null == date || "" == date || "undefined" == typeof(date)) {
                    return '--';
                }
                var m = date.substr(4, 2) < "10" ? date.substr(5, 1) : date.substr(4, 2);
                var d = date.substr(6, 2) < "10" ? date.substr(7, 1) : date.substr(6, 2);
                return m + "月" + d + "日";
            },
            formatTime: function (time) {
                if (null == time || "" == time || "undefined" == typeof(time)) {
                    return '--';
                }
                var d = time.substr(0, 4) + "-" + time.substr(4, 2) + "-" + time.substr(6, 2);
                var t = time.substr(8, 2) + ":" + time.substr(10, 2) + ":" + time.substr(12, 2);
                return d + " " + t;
            },
            checkRegex: function (regex, value) {
                var re = new RegExp(regex);
                if (re.test($.trim(value))) {
                    return true;
                } else {
                    return false;
                }
            },
            trim: function (str) {
                var regExp = new RegExp(" ", "g");
                if (!str) {
                    return null;
                }
                if (angular.isString(str)) {
                    return str.replace(regExp, "");
                } else {
                    return str.toString().replace(regExp, "");
                }
            },
            getPrevDate: function () {
                var d = new Date();
                d.setDate(d.getDate() - 1);
                return d.getMonth() + 1 + "月" + d.getDate() + "日";
            }
        };
        //----------------内部方法------------------------------

        function _ajax(options) {
//            $.ajax({
//                type: 'POST',
//                url : "https://www.jkjrj.com/WAserver/s/json/HS831000",
//                data:{
//                    input_content:'b',
//                    account_content:'18626924972',
//                    password:'199224'
//                },
//
//                dataType : 'json',
//                //contentType : "application/json",
//                success : function(data) {
//                    alert(JSON.stringify(data));
//                },
//                error : function(w) {
//                    alert(JSON.stringify(w));
//                    //alert("系统异常,加载失败1");
//                }
//            });

            var url = (options.basePath || $rootScope.basePath) + options.url;
            var httpOption = {method: options.type || "post", url: url};
            if (httpOption.method == "post") {
                httpOption.data = options.data || {};
            } else {
                var pString = $httpParamSerializerJQLike(options.data || {});
                httpOption.url += pString ? "?" + pString : "";
                httpOption.offline = true;
                if (options.cache) { //缓存
                    httpOption.cache = CacheFactory.get('xcmCache');

                    var cacheDate = httpOption.cache.get(httpOption.url);
                    if (cacheDate && cacheDate[1] && angular.fromJson(cacheDate[1]).error_no != "0") {
                        httpOption.cache.remove(httpOption.url);
                    }
                }
            }
//            console.log(JSON.stringify(httpOption)+'????????????');

            var deferred = $q.defer();
            $http(httpOption).success(function (result, status, headers, config) {
                if (result && result.error_no == "0") {
                    deferred.resolve(result.data);
                } else {
                    if (!options.isReject) {
                        callException(null, result, options.styleType);
                    }
                    deferred.reject(result);
                    $ionicLoading.hide();
                }
                console.log(JSON.stringify(httpOption)+'????????????');
                console.log(httpOption.url+'!!!!!!!!!!!!');

                console.log(JSON.stringify(result)+'data1');
                ///trade/user/login
                if('/trade/user/login'==options.url){
                    if (result.error_no != "0") {
                        LocalCacheService.set('login_error','a');
                    }
                    else{
                        LocalCacheService.remove('login_error');
                    }
                }

                if('/trade/bank/quick_bank_cards'==options.url){
                    LocalCacheService.set('data1',result);
                    //alert(JSON.stringify(result)+'data1data1data1data1data1data1data1data1data1data1data1data1data1data1data1');
                }

                if('/trade/account/total_history_orders'==options.url){
                    //alert(JSON.stringify(result.data));
                    LocalCacheService.set('data2',result);
                }

                if('/trade/account/total_shares'==options.url){
                    LocalCacheService.set('data3',result);
                }
                if('/trade/user/get_user'==options.url){
                    LocalCacheService.set('data4',result);
                }
                if('/trade/account/total_current_orders'==options.url){
                    LocalCacheService.set('today_orders',result);
                }
                LocalCacheService.set('data_',result);
//                console.log(LocalCacheService.get('data1')+'11111111111111111111111111111111111111');
//                console.log(LocalCacheService.get('data2')+'22222222222222222222222222222222222222');
//                console.log(LocalCacheService.get('data3')+'33333333333333333333333333333333333333');
//                //LocalCacheService.set('ttt','aaa');
            }).
                error(function (data, status, headers, config) {
                    if (XMLHttpRequest.readyState == 4) {
                        if (XMLHttpRequest.status == "200" || textStatus == "OK") {
                            if (!options.isReject) {
                                callError(null, XMLHttpRequest.responseText);
                            }
                        } else {
                            _showConfig({message: "调用数据失败,请稍后再试."});
                        }
                    }
                    deferred.reject(XMLHttpRequest.responseText);
                    $ionicLoading.hide();
                });
            console.log(JSON.stringify(deferred.promise)+'data2');
            return deferred.promise;
        }

        /**
         * 异常信息返回时调用，显示错误信息
         * @param result(JSON obj)
         */
        function callException(failure, result, styleType) {
            if (failure) {
                failure(result);
            } else {
                if (styleType && styleType == 1) {
                    show({message: _getErrorInfo(result)});
                } else {
                    _showConfig({message: _getErrorInfo(result)});
                }
            }

        }

        /**
         * 出现异常时调用异常信息
         * @param failure(Function) 失败时回调方法
         * @param errorMessage(String) 异常信息
         *
         */
        function callError(failure, errorMessage) {
            if (failure) {
                failure(errorMessage);
            } else {
                _showConfig({message: errorMessage});
            }
        }

        /**
         * 定位弹出层位置
         * @param options(Json Object) 同 showAlert 参数说明
         * @returns Json Object {
	 * 		left : 左边距离 单位：像素,
	 *		width : 宽度 单位：像素,
	 *		height: 高度 单位：像素,
	 *		top : 距离顶部距离 单位：百分比,
	 * }
         */
        function position(options) {
            var $m = options.message;
            //是否固定最小宽度及高度
            var fixed = options.fixed || true;
            //元素宽度
            var _popWidth = $m.width();
            //元素高度
            var _popHeight = $m.height();
            if (fixed) {//处理固定情况的高度及宽度
                var _minWidth = options.width || 300;
                var _minHeight = options.height || 150;
                _popWidth = _popWidth < _minWidth ? _minWidth : _popWidth;
                _popHeight = _popHeight < _minHeight ? _minHeight : _popHeight;
            }
            //计算 高度和宽度
            var _widowWidth = $(window).width();
            //Loading为要显示的div
            var _popLeft = (_widowWidth - _popWidth) / 2;
            var _windowHeight = $(window).height();
            var _top = (_windowHeight - _popHeight) / 2;
            //最小距离顶部30px;
            _top = _top < 30 ? 30 : _top;
            var _popTop = Math.floor(_top / _windowHeight * 100);
            _popTop = _popTop < 20 ? 20 : _popTop;
            return {
                left: _popLeft + 'px',
                width: _popWidth + 'px',
                height: _popHeight + 'px',
                top: _popTop + '%'
            };
        }

        /**
         * 弹出框
         * @param options
         */
        function show(options) {
            TF.Bubble.show(options.message);
            if (options.onUnblock) {
                options.onUnblock();
            }

//            var myPopup = $ionicPopup.alert({
//                cssClass: 'popup-head-hide ',
//                template: options.message,
//                buttons: []
//            });
//            $timeout(function() {
//                myPopup.close();
//            }, 2000);
        }

        function _showConfig(options) {
            return $ionicPopup.show({
                template: options.message,
                title: options.title ? options.title : '提示',
                buttons: [
                    { text: (options.okText ? options.okText : '确定')},
                ]
            });
        }
        function _showlogin(){
            return $ionicPopup.show({
                template: "<span>请输入天风证券交易密码确认登录，以同步显示您的资产数据</span><input type='password' id='pass' cl autofocus />",
                title: "天风证券",
                buttons: [
                    { text: "取消",
                        type: "button-light",
                        onTap: function(e){


                            Messenger.send('close');
                            return 'no';
                        }
                    },

                    {
                        text: "确认",
                        type: "button-light",
                        onTap: function(e) {
//                            alert(a++);
                            if($("#pass").val()==''){
//                                alert('空');
                                show({message:'密码不能为空'});
                                e.preventDefault();
                            }else{
                                return $("#pass").val();
                            }


                        }
                    }
                ]
            })
        }

        function _hidelogin(){
            $timeout(function() {
                myPopup.close(); //由于某种原因3秒后关闭弹出
            }, 3000);
        }

        /**
         * 获取错误信息
         * @param result
         */
        function _getErrorInfo(result) {
            if (result.error_info) {
                return result.error_info;
            }
            if (typeof  data == "string") {
                return data;
            } else if (typeof data == "object") {
                return  data.errorMessage;
            }
            return "未知错误";
        }
    };

    factory.$inject = ['$location', '$http', '$httpParamSerializerJQLike', '$rootScope', '$state', '$q',
        '$ionicLoading', '$ionicPopup', 'LocalCacheService', 'CacheFactory', 'CACHE_MAX_AGE'];
    return factory;
});