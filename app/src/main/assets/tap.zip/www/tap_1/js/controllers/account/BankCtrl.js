define(function () {
    'use strict';

    function ctrl($scope,$q,CommonService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        $scope.doRefresh = function() {
            init().finally(function(){
                $scope.$broadcast('scroll.refreshComplete');
            });
        };

        function init(){
            console.log('initinit');
            $scope.q_bank = new Array();
            $scope.d_bank = null;
            par.is_hunme = false;
            //理财体验 不显示存管相关
            if(sessionStorage["tf_hunme_from"]=="2" || CommonService.isBuyExperience()){
                par.is_hunme = true;
            }
            return $q.all([qryDeposit(), qryQuick()]);
        }

        //查询用户存管银行
        function qryDeposit(){
            var q = WebService.getUserDepositBankCards();
            q.then(
                function (data) {
                    if(data.length > 0){
                        $scope.d_bank = data[0];
                        //待审核、待激活状态 预指定银行不显示银行卡尾号
                        if("1,3".indexOf($scope.d_bank.bkaccount_regflag) > -1 && "2" == $scope.d_bank.contract_way){
                            $scope.d_bank.bank_account_short = '';
                            $scope.d_bank.un_card = 'unCard';
                        }else{
                            var bank_account = $scope.d_bank.bank_account;
                            $scope.d_bank.bank_account_short = '<p>尾号'+bank_account.substr(bank_account.length-4)+'</p>';
                            $scope.d_bank.un_card = 'unCard';
                        }
                        if("1,3".indexOf($scope.d_bank.bkaccount_regflag) > -1){
                            $scope.d_bank.deposit_class = 'unfinished';
                        }else{
                            $scope.d_bank.deposit_class = '';
                        }
                    }
                },
                function (result){
                    CommonService.showAlert({message:CommonService.getErrorInfo(result)});
                }
            );
            return q;
        }

        //查询用户三方支付
        function qryQuick(){
            var q = WebService.getUserQuickBankCards();
            q.then(
                function (data) {
                    if(data.length > 0){
                        for (var i = 0; i < data.length; i++) {
                            var quick_bank = data[i];
                            var bank_account = quick_bank.bank_account;
                            quick_bank.bank_account_short = bank_account.substr(bank_account.length-4);
                            quick_bank.bank_name_encodeURI = encodeURI(quick_bank.bank_name);
                            $scope.q_bank.push(quick_bank);
                        }
                    }
                }
            );
            return q;
        }

        $scope.showActivateMsg = function(){
            CommonService.showConfig({okText:"关闭", message : $scope.d_bank.brief});
        };
    }

    ctrl.$inject = ['$scope','$q','CommonService','WebService'];
    return ctrl;
});