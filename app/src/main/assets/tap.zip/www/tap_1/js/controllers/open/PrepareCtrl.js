define(function () {
    'use strict';

    function ctrl($scope,WebService) {

        $scope.$on('$ionicView.beforeEnter', function() {
            init();
        });

        function init(){
            $scope.deposit_bank = new Array();
            //查询所有存管银行
            WebService.qryAllDepositBank().then(
                function(data){
                    for(var i=0; i < data.length; i++){
                        $scope.deposit_bank.push(data[i]);
                    }
                }
            );
        }
    }

    ctrl.$inject = ['$scope','WebService'];
    return ctrl;
});