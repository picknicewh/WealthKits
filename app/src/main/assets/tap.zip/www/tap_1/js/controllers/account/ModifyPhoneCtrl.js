define(function () {
    'use strict';

    function ctrl($scope,$ionicLoading,$timeout,LocalCacheService,CommonService,WebService) {

        var par = $scope.param = {};
        var timer = 180;
        var intervaltime;

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.user = LocalCacheService.getUser();
            par.sendCodeClass = 'security-code jSecurityCode';
            par.sendCodeMsg = '获取验证码';
            par.inputCheckCode = false;
            par.newMobileTel = true;
            par.inputDiv = true;
        });

        $scope.sendCodeClick = function(){
            sendCodeClick();
        };

        $scope.modifyClick = function(){
            if(checkInput()){
                var new_mobile_tel = CommonService.trim(par.new_mobile_tel);
                $ionicLoading.show();

                WebService.modifyMobile(new_mobile_tel, $.trim(par.check_code), $.trim(par.password)).then(
                    function(data){
                        WebService.getUserInfo().then(
                            function (result) {
                                LocalCacheService.setUser(result);
                                par.inputDiv = false;
                                $ionicLoading.hide();
                        });
                    }
                );
            }
        };

        function sendCodeClick(){
            if(checkNewMobile() && par.sendCodeClass.indexOf("countdown") < 0){
                var mobile_tel = CommonService.trim(par.new_mobile_tel);
                par.sendCodeClass = "security-code countdown";
                WebService.checkMobile(mobile_tel).then(function (data){
                        timer = 180;
                        par.sendCodeMsg = timer + '秒后重发';
                        $scope.sendCodeClick = function(){};
                        par.inputCheckCode = true;
                        par.newMobileTel = false;
                        intervaltime = $timeout(showCountDown,1000);
                    },
                    function (result){
                        CommonService.showConfig({message: CommonService.getErrorInfo(result)});
                        par.sendCodeClass = 'security-code jSecurityCode';
                    }
                );
            }
        }

        function showCountDown(){
            var currentTime = --timer;
            if(currentTime >=0){
                par.sendCodeMsg = currentTime + '秒后重发';
                $timeout(showCountDown,1000);
            }else{
                if(intervaltime){
                    $timeout.cancel(intervaltime);
                }
                par.sendCodeClass = 'security-code jSecurityCode';
                par.sendCodeMsg = '获取验证码';
                $scope.sendCodeClick = function(){
                    sendCodeClick();
                };
                par.newMobileTel = true;
            }
        }

        function checkNewMobile(){

            if(CommonService.isStrEmpty(par.new_mobile_tel)){
                CommonService.showAlert({message:"请输入新手机号！"});
                return false;
            }else if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$",CommonService.trim(par.new_mobile_tel))){
                CommonService.showAlert({message:"手机号格式错误！"});
                return false;
            }
            return true;
        }

        function checkInput(){
            if(CommonService.isStrEmpty(par.new_mobile_tel)){
                CommonService.showAlert({message:"请输入新手机号！"});
                return false;
            }else if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$", CommonService.trim(par.new_mobile_tel))){
                CommonService.showAlert({message:"手机号格式错误！"});
                return false;
            }
            if(CommonService.isStrEmpty(par.check_code)){
                CommonService.showAlert({message:"请输入手机验证码！"});
                return false;
            }
            if(!CommonService.checkRegex("^[0-9]{6}$",par.password)){
                CommonService.showAlert({message:"请输入6位登录密码！"});
                return false;
            }
            return true;
        }

        $scope.$on('$destroy', function(e) {
            $timeout.cancel(intervaltime);
        });
    }
    ctrl.$inject = ['$scope','$ionicLoading','$timeout','LocalCacheService','CommonService','WebService'];
    return ctrl;
});