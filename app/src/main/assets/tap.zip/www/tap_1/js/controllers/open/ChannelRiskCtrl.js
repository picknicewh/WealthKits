define(function () {
    'use strict';

    function ctrl($scope,$stateParams,$ionicLoading,$ionicScrollDelegate,$state,$ionicPopup,LocalCacheService,CommonService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            par.paper_id = $stateParams['paper_id'];
            par.product_no = $stateParams['product_no'];
            par.questions = new Array();
            par.show_question = true;
            $scope.user = LocalCacheService.getUser();
            init();
        });

        $scope.onExitKeyDown = function(){
                $ionicPopup.confirm({
                    cssClass: 'popup-head-hide',
                    template: "您确定要退出问卷填写吗？",
                    okText:"确定",
                    cancelText:"取消"
                }).then(function(res) {
                    if(res) {
                        $state.go("tab.index");
                    }
                });
        };

        function init(){
            //查询渠道问卷
            var params = {product_no:par.product_no,conduit_no:LocalCacheService.getRecommendInfos(),source:CommonService.getSource()};
            WebService.qryChannelRiskPaper(params).then(
                function (data){
                    for(var i=0;i<data.length;i++){
                        var question = data[i];
                        if('0,1'.indexOf(question.question_kind) > -1){
                            var answers = new Array();
                            $.each(question.answer_content,function (key,value){
                                if('1' == question.question_kind && key == question.default_answer){
                                    answers.push({"key" : key,"value" : value,"checked" : true});
                                }else{
                                    answers.push({"key" : key,"value" : value});
                                }
                                question.answer_content = answers;
                            });
                        }
                        question.paper_answer = question.default_answer;
                        question.question_idx = i+1;
                        par.questions.push(question);
                    }
                }
            );
        }

        $scope.submitClick = function(){
            if(readyToSubmit()){
                $ionicLoading.show();
                var paper_answers = '';
                for(var i=0;i<par.questions.length;i++){
                    var question = par.questions[i];
                    paper_answers += question.question_no + '&' + question.paper_answer + '|';
                }
                var params = {client_id:$scope.user.client_id,conduit_no:LocalCacheService.getRecommendInfos(),answer_content:paper_answers,
                    source: CommonService.getSource(), paper_id: par.paper_id, product_no:par.product_no};
                //提交渠道问卷
                WebService.submitChannelRiskPaper(params).then(
                    function(){
                        $ionicLoading.hide();
                        paper_answers = '';
                        par.show_question = false;
                        $ionicScrollDelegate.scrollTop();
                    }
                );
            }
        };

        function readyToSubmit(){
            for(var i=0;i<par.questions.length;i++){
                var question = par.questions[i];
                if('0' == question.question_kind && CommonService.isStrEmpty(question.paper_answer)){
                    CommonService.showAlert({message:'第' + question.question_idx + '题未答！'});
                    return false;
                }
                if('1' == question.question_kind){
                    var answer_content = question.answer_content;
                    var paper_answer = '';
                    for(var j=0;j<answer_content.length;j++){
                        if(answer_content[j].checked){
                            paper_answer += answer_content[j].key + '&';
                        }
                    }
                    if(CommonService.isStrEmpty(paper_answer)){
                        CommonService.showAlert({message:'第' + question.question_idx + '题未答！'});
                        return false;
                    }else{
                        question.paper_answer = paper_answer.substring(0,paper_answer.length-1);
                    }
                }
                if('2' == question.question_kind){
                    var paper_answer = question.paper_answer;
                    if(CommonService.isStrEmpty(paper_answer)) {
                        var user = LocalCacheService.getUser();
                        if(user){
                            question.paper_answer = user.mobile_tel;
                        }
                    } else{
                        if(!CommonService.checkRegex("^1[0-9][0-9]\\d{8}$", CommonService.trim(paper_answer))) {
                            CommonService.showAlert({message:'第' + question.question_idx + '题请输入正确的手机号格式！'});
                            return false;
                        }
                    }
                }
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$stateParams','$ionicLoading','$ionicScrollDelegate','$state','$ionicPopup','LocalCacheService','CommonService','WebService'];
    return ctrl;
});