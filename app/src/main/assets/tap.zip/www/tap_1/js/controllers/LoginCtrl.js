define(function () {
    'use strict';

    function ctrl($rootScope,$scope,$state,$stateParams,DictionaryService,$ionicLoading,
                  $ionicHistory,CommonService,LocalCacheService,ConcernService,WebService) {

        $scope.$on('$ionicView.beforeEnter', function() {
           // alert($rootScope.ip+'aaaaaaaaaaaaa');
           // alert(IP+'IPIPIPIPIPIPIPIP');
            $scope.login.password = null;
            LocalCacheService.removeUser();
            init();
            $scope.num = 0;
            CommonService.showlogin().then(function(data){
//            alert('success');
//            alert(data);
                $scope.num++;
                if(data!='no'){
                    $scope.vv = data;
                    $scope.login();
                }

           // alert()
       });
        });
        $scope.account_content_ = $stateParams['name'];
        $scope.token_ = $stateParams['token'];
        $scope.key_ = $stateParams['key'];
       // alert($scope.account_content_ );
       // alert($scope.token_);
       // alert($scope.key_);
        function init(){
            //alert(LocalCacheService.get('source'));
          //  alert($rootScope.ip);

            $scope.branchs = DictionaryService.getBranchs();

            //公告获取
            WebService.getNotice("index").then(function (notice) {
                if (notice.error_no == 0 && notice.isColsed != 1 && notice.title && notice.content) {
                    CommonService.showNotice(notice.title + "&&" + notice.content, "tf_system_notice_show");
                }
            });
            // btn_s1 理财体验活动新增 可以直接买基金
            $scope.openUrl = "#/open-prepare";
            if(CommonService.isBuyExperience()) {
                $scope.openUrl = "#/open-msgVerify";
            }

            var user = LocalCacheService.getUser();
            if(user) {
                var from = $stateParams["from"];
                if(from && from != "login"){
                    $state.go(from, angular.fromJson($stateParams["fromParams"]));
                } else {
                    $state.go("tab.account-index");
                }
            }
           // alert(localStorage["from_dbgj"]+'localStorage["from_dbgj"]localStorage["from_dbgj"]localStorage["from_dbgj"]');
        }

        $scope.login = function (){
//            var phoneNum = $stateParams['name'];
//            console.log(phoneNum+'::::::::::::::::name');

            var account_content = $scope.account_content_;
            var password = $scope.vv;
          //  alert(password+'password');
            var token_ = $scope.token_;
            var key_ = $scope.key_;
//            alert($scope.token_);
//            alert($scope.key_);
           // var password = $.trim($("#password").val());
            console.log(account_content+"::::::::::::::$scope.account_content_");
            console.log(password+'::::::::::::::::password');
            if("" == account_content || "" == password){
                CommonService.showAlert({message:"请输入账号和密码"});
                //CommonService.showlogin();
            }
            if($("#image_code").size() > 0 && "" == $.trim($("#image_code").val())){
                CommonService.showAlert({message:"请输入验证码"});

            }
            if(phoneRegex.test(account_content)){

               loginEvent(account_content,password,token_,key_);


            }else{
                if($scope.branchs == ""){
                    CommonService.showAlert({message:"营业部信息获取失败，请重试"});
                }else{
                    var isAccount = false;
                    var branArr = $scope.branchs.split(",");
                    for(var i=0;i<branArr.length;i++){
                        var branch_no = branArr[i];
                        if(!isNaN(account_content) && account_content.indexOf(branch_no) == 0){
                            //getbank();
                            loginEvent(account_content,password,token_,key_);
                            isAccount = true;
                            break;
                        }
                    }
                    if(!isAccount){
                        CommonService.showAlert({message:"手机号或客户号输入有误！"});
                        CommonService.showlogin();
                    }
                }
            }
            //alert('!!!!!!!!!');
        };

//        $scope.login2 = function (e){
//            $(e).css('background','red');
//        };

        function loginEvent(account_content,password,token_,key_){
           // Messenger.send("close");
            var params = buildParams(account_content,password);
            $ionicLoading.show();
            //登陆请求
            console.log('发送登录请求22222222222');
            WebService.login(params).then(
                function(data){
                    if(typeof Messenger != 'undefined') {
                        Messenger.sendMsg("ym_profileSignIn",{PUID: $scope.login.account_content} ,null,null);
                    }
                    //alertError(data.error_no);
                    var user = {};
                    user.token = data.token;
             //       alert(data.token+'data.token');
                    LocalCacheService.setUser(user);
                    WebService.getUserInfo().then(function(result){
                        LocalCacheService.setUser(result);

                        WebService.qryConduitInfo({mobile_tel: result.mobile_tel}).then(function(data){
                            //用户有渠道信息 包没渠道号
                            if(!CommonService.isStrEmpty(data.conduit_no)
                                && CommonService.isStrEmpty(LocalCacheService.getRecommendInfos())){
                                LocalCacheService.setRecommendInfos(data.conduit_no);
                            }
                        });
                        //CommonService.showConfig({message:LocalCacheService.get('data4').data.id_no+'获取data4'});
              //          alert(token_+'token_::::::::::'+key_+'key_:::::::::::'+LocalCacheService.get('data4').data.client_name+'realName:::::::::::');
                        console.log(JSON.stringify(LocalCacheService.get('data4').data.id_no)+':::::::::::::::::::!!!!!!!!!!data4');
                        $.ajax({
                            type: 'POST',
                            url : $rootScope.ip+"/wealthKits/userMessage/saveTfUserInfo",
                            data:{
                                token:token_,
                                secretKey:key_,
                                idNumber:LocalCacheService.get('data4').data.id_no,
                                realName:LocalCacheService.get('data4').data.client_name,
                                tfToken:LocalCacheService.get('data4').data.client_id,
                                tfTokenSecret:LocalCacheService.get('data4').data.fund_account,
                                mobile:LocalCacheService.get('data4').data.mobile_tel,
                                source:'1'
                            },

                            dataType : 'json',
                            //contentType : "application/json",
                            success : function(data) {
                            //    alert(JSON.stringify(data)+'4444444444444444');
                                //if(data.resultCode!='0'){
                                LocalCacheService.set('error1','no');
                                //LocalCacheService.set('errorInfo',data.resultDesc);
                                //CommonService.showAlert({message:data.resultDesc});
                                $ionicLoading.hide();
                                add_ajax();

                            },
                            error : function(XMLHttpRequest, textStatus, errorThrown) {
                                console.log(JSON.stringify(XMLHttpRequest, textStatus, errorThrown)+'4444444444444444');
                                alert("系统异常,加载失败1");
                            }

                        });
                    });///userMessage/saveUserInfo




                    WebService.getUserQuickBankCards().then(
                        function (result){

                            console.log(JSON.stringify(LocalCacheService.get('data1'))+'jjjjjjjjjjjj');
                            $.ajax({
                                type: 'POST',
                                url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                                data:{
                                    token:token_,
                                    secretKey:key_,
                                    objective:2,
                                    source:1,
                                    values:JSON.stringify(LocalCacheService.get('data1'))
                                },

                                dataType : 'json',
                                //contentType : "application/json",
                                success : function(data) {
                                //    alert(JSON.stringify(data)+'111111111111111');
                                    if(data.resultCode!='0'){
                                        LocalCacheService.set('error2','has');
                                        LocalCacheService.set('errorInfo',data.resultDesc);
                                        // CommonService.showAlert({message:data.resultDesc});
                                        $ionicLoading.hide();
                                    }
                                    else{
                                        LocalCacheService.set('error2','no');
                                    }
                                    add_ajax();
                                },
                                error : function(XMLHttpRequest, textStatus, errorThrown) {
                                  //  alert(JSON.stringify(XMLHttpRequest, textStatus, errorThrown)+'111111111111111');
                                    alert("系统异常,加载失败1");
                                }

                            });



                        }, function(result){
                            LocalCacheService.removeUser();
                            CommonService.showConfig({message:"获取用户信息失败"});
                        }
                    );



                    WebService.queryHisOrders().then(function(){
                        console.log(JSON.stringify(LocalCacheService.get('data2'))+'交易记录');
                        $.ajax({
                            type: 'POST',
                            url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                            data:{
                                token:token_,
                                secretKey:key_,
                                objective:1,
                                source:1,
                                values:JSON.stringify(LocalCacheService.get('data2'))
                            },

                            dataType : 'json',
                            //contentType : "application/json",
                            success : function(data) {
                             //  alert(JSON.stringify(data)+'222222222222222222');
                                if(data.resultCode!='0'){
                                    LocalCacheService.set('error3','has');
                                    LocalCacheService.set('errorInfo',data.resultDesc);
                                    //CommonService.showAlert({message:data.resultDesc});
                                    $ionicLoading.hide();
                                }else{
                                    LocalCacheService.set('error3','no');
                                }
                                add_ajax();
                            },
                            error : function(w) {
                             //  alert(JSON.stringify(w)+'22222222222');
                                alert("系统异常,加载失败1");
                            }
                        });
                    });

                    WebService.queryCurOrders().then(function(){
                        console.log(JSON.stringify(LocalCacheService.get('today_orders'))+'当日交易记录');
                        $.ajax({
                            type: 'POST',
                            url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                            data:{
                                token:token_,
                                secretKey:key_,
                                objective:1,
                                source:1,
                                values:JSON.stringify(LocalCacheService.get('today_orders'))
                            },

                            dataType : 'json',
                            //contentType : "application/json",
                            success : function(data) {
                                  //   alert(JSON.stringify(data)+'222222222222222222');
                                if(data.resultCode!='0'){
                                    LocalCacheService.set('error5','has');
                                    LocalCacheService.set('errorInfo',data.resultDesc);
                                    //CommonService.showAlert({message:data.resultDesc});
                                    $ionicLoading.hide();
                                }else{
                                    LocalCacheService.set('error5','no');
                                }
                                add_ajax();
                            },
                            error : function(w) {
                               //  alert(JSON.stringify(w)+'22222222222');
                                alert("系统异常,加载失败1");
                            }
                        });
                    });

                    WebService.getAllShares().then(function(){
                        console.log(JSON.stringify(LocalCacheService.get('data3'))+'资产');
                        $.ajax({
                            type: 'POST',
                            url : $rootScope.ip+"/wealthKits/userMessage/clientSubmitData",
                            data:{
                                token:token_,
                                secretKey:key_,
                                objective:0,
                                source:1,
                                values:JSON.stringify(LocalCacheService.get('data3'))
                            },

                            dataType : 'json',
                            //contentType : "application/json",
                            success : function(data) {
                               // alert(JSON.stringify(data)+'333333333333333333');
                                LocalCacheService.set('success','a');
                                if(data.resultCode!='0'){
                                    LocalCacheService.set('error4','has');
                                    LocalCacheService.set('errorInfo',data.resultDesc);
                                    // CommonService.showAlert({message:data.resultDesc});
                                    $ionicLoading.hide();
                                }else{
                                    LocalCacheService.set('error4','no');
                                }
                                add_ajax();
                            },
                            error : function(w) {
                              //  alert(JSON.stringify(w)+'33333333333333333333333');

                                alert("系统异常,加载失败1");
                            }
                        });
                    });

          //  alert(JSON.stringify(LocalCacheService.get('data2'))+'hhhhhhhhhhhhhhhhh')
                  //  alert(JSON.stringify(LocalCacheService.get('today_orders'))+'hhhhhhhhhhhhhhhhh')

                  //  console.log(JSON.stringify(LocalCacheService.get('data2').data).index(1,JSON.stringify(LocalCacheService.get('data2').data).length-1)+'                     zzzz');
                },function(error){
                    CommonService.showAlert({message:'登录出错'});
                    CommonService.showAlert({message:JSON.stringify(error)});
                    CommonService.showlogin().then(function(data){
//                        alert('success');
//                        alert(data);
                        if(data!='no'){
                            $scope.vv = data;
                            $scope.login();
                        }

                        // alert()
                    });
                }



            );


           // return [LocalCacheService.get('error4'),LocalCacheService.get('error3'),LocalCacheService.get('error2'),LocalCacheService.get('error1')];

         // Messenger.send('close');
        }
        function getbank(){
            console.log('initinit');
            $scope.q_bank = new Array();
            $scope.d_bank = null;
            par.is_hunme = false;
            //理财体验 不显示存管相关
            if(sessionStorage["tf_hunme_from"]=="2" || CommonService.isBuyExperience()){
                par.is_hunme = true;
            }
            return $q.all([qryQuick()]);
        }


        $scope.add = 0;
        function add_ajax(){
            $scope.add++;
            if($scope.add==5){
                    if(LocalCacheService.get('error5')!='no'||LocalCacheService.get('error4')!='no'||LocalCacheService.get('error3')!='no'||LocalCacheService.get('error2')!='no'){
                        CommonService.showAlert({message:LocalCacheService.get('errorInfo')||'出错啦'});
                        //if($scope.num==1){
                        CommonService.showlogin().then(function(datas){
                            $scope.num++;
                            if(datas!='no'){
                                $scope.vv = datas;
                                //alert($scope.vv+'$scope.vv');
                                $scope.login();
                            }
                        });
                    }else{

//                        if(undefined!=localStorage["from_dbgj"]){
//                            CommonService.showAlert({message:'操作成功'});
//                             alert(localStorage["from_dbgj"]+'Y');
//                            window.location.href = localStorage["indexUrl"];
//                        }
//                        else{
                            CommonService.showAlert({message:'操作成功'});
                         //   alert('success');
                             Messenger.send('close');
                        //return;
                        //}

                    }
                $scope.add=0;
            }
        }


        function qryQuick(){
            var q = WebService.getUserQuickBankCards();
            q.then(
                function (data) {
                    if(data.length > 0){
                        for (var i = 0; i < data.length; i++) {
                            var quick_bank = data[i];
                            var bank_account = quick_bank.bank_account;
                            quick_bank.bank_account_short = bank_account.substr(bank_account.length-4);
                            quick_bank.bank_name_encodeURI = encodeURI(quick_bank.bank_name);
                            $scope.q_bank.push(quick_bank);
                        }
                    }
                }
            );
            return q;
        }
        var phoneRegex = /^1[0-9][0-9]\d{8}$/;

        function buildParams(account_content_,password_){
            var params = {};
            var account_content = $.trim(account_content_);
            console.log(account_content+'buildParams_account_content');
            $.extend(params,{account_content:account_content,password:$.trim(password_)});
            var input_content = "1";
            if (phoneRegex.test(account_content)){
                input_content = "b";
            }
            $.extend(params,{input_content:input_content});
            if($("#image_code").size() > 0){
                $.extend(params,{image_code:$("#image_code").val()});
            }

            $.extend(params,{cares_str:ConcernService.getConcernList()});

            console.log(JSON.stringify(params)+'pppppp');
            return params;
        }

        $scope.onBackKeyDown = function () {
//            var from = $stateParams["from"];
            if($.cookie("back_url_2") || ($.cookie("_r_u_l") && $.cookie("_r_u_l").indexOf("from=2") !=-1)) {
                Messenger.send("close");
            } else if(CommonService.isBuyExperience()) { //理财体验活动
                var to_state = LocalCacheService.get("lcty_state");
                $state.go(to_state.stateName, to_state.stateParams);
            }else if($ionicHistory.backView() && "sessionOut" != $stateParams["w"]) {
                $ionicHistory.goBack();
            } else {
                $state.go("tab.index");
            }
        };
    }

    ctrl.$inject = ['$rootScope','$scope','$state','$stateParams','DictionaryService','$ionicLoading',
        '$ionicHistory','CommonService','LocalCacheService','ConcernService','WebService'];
    return ctrl;
});