define(function () {
    'use strict';

    function ctrl($scope,$state,$ionicLoading,LocalCacheService,CommonService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.user = LocalCacheService.getUser();
            par.pwd_type = '2';
            par.modify_pwd = true;
            par.modify_tab = true;
            par.modify_result = "";
        });

        $scope.backClick = function(){
            if("2" == sessionStorage["tf_hunme_from"]) {
                par.modify_tab = false;
                if($.cookie("back_url_2")) {
                    $state.go($.cookie("back_url_2"));
                }
            }else{
                $state.go('tab.account-manager');
            }
        };

        $scope.typeCLick = function(){
            if('2' == par.pwd_type){
                par.pwd_type = '1';
            }else{
                par.pwd_type = '2';
            }
            par.old_pwd = "";
            par.new_pwd = "";
            par.confirm_pwd = "";
        };

        $scope.modifyClick = function(){
            if(checkBeforeSubmit()){
                $ionicLoading.show();

                WebService.modifyPwd(par.new_pwd, par.old_pwd, par.pwd_type).then(function (){
                        $ionicLoading.hide();
                        par.modify_pwd = false;
                        if(par.modify_tab){
                            if("2" == par.pwd_type){
                                par.modify_result = '交易密码已修改，请妥善保管！';
                            }else{
                                par.modify_result = '资金密码已修改，请妥善保管！';
                            }
                        }else{
                            par.modify_result = '密码已修改，请妥善保管！';
                        }
                    },
                    function (error){
                        $ionicLoading.hide();
                        //原交易密码错误
                        if("XCM-200002" == error.error_no){
                            par.old_pwd = '';
                        }else{
                            par.old_pwd = '';
                            par.new_pwd = '';
                            par.confirm_pwd = '';
                        }
                        CommonService.showConfig({message: error.error_info});
                    }
                );
            }
        };

        function checkBeforeSubmit(){
            if(par.old_pwd == par.new_pwd){
                CommonService.showAlert({message:"新密码和旧密码不能相同！"});
                par.new_pwd = "";
                par.confirm_pwd = "";
                return false;
            }
            if("2" == par.pwd_type){
                if(!checkPwd(par.new_pwd,par.confirm_pwd,"交易")){
                    return false;
                }
            }else if("1" == par.pwd_type){
                if(!checkPwd(par.new_pwd,par.confirm_pwd,"资金")){
                    return false;
                }
            }
            return true;
        }

        function checkPwd(pass1,pass2,info){
            if(!CommonService.isStrEmpty(pass1) && pass1.length != 6){
                CommonService.showAlert({message:"请输入6位数字"+info+"密码，请重新输入!"});
                return false;
            }else if(!validatePassword(pass1,$scope.user.id_no,$scope.user.mobile_tel)){
                return false;
            }else if(!CommonService.isStrEmpty(pass1) && !CommonService.isStrEmpty(pass2) && pass1 != pass2){
                CommonService.showAlert({message:info+"密码与第一次不符，请重新输入!"});
                return false;
            }
            return true;
        }

        /**
         * 验证密码 6位数字
         */
        function validatePassword(pwd,id_no,mobile_tel){
            var regex =  "^[0-9]{6}$";
            if(!CommonService.checkRegex(regex,pwd) || pwd.length != 6){
                CommonService.showAlert({message:"请输入6位数字密码"});
                return false;
            }
            /**
             * 增加弱密校验
             * 1、出生日期的一部分
             * 2、证件号码的一部分
             * 3、某一字符出现的概率不能占总长度的一半以上
             * 4、顺序递增或者递减
             * 5、弱密表的控制值
             * 6、移动电话的一部分
             * 7、固定电话的一部分
             */
            // 判断是不是出生日期的一部分
            if(pwd == id_no.substring(6,12) || pwd == id_no.substring(8,14)){
                CommonService.showAlert({message:"密码不能是出生日期的一部分！"});
                return false;
            }
            // 判断是不是证件号码的一部分
            if(id_no.indexOf(pwd) != -1){
                CommonService.showAlert({message:"密码不能是证件号码的一部分！"});
                return false;
            }
            // 判断某一字符出现的次数
            for(var i = 0;i < pwd.length;i++){
                var oneChar = pwd.charAt(i),
                    count = 0;
                for(var j = 0;j < pwd.length;j++){
                    if(oneChar == pwd.charAt(j)){
                        count++;
                    }
                }
                if(count >= 3){
                    CommonService.showAlert({message:"密码中&nbsp;"+oneChar+"&nbsp;出现的次数超过了三次！"});
                    return false;
                }
            }
            // 判断顺序递增或者递减
            var orderArray = ['012345','123456','234567','345678','456789','987654','876543','765432','654321','543210'];
            if(orderArray.indexOf(pwd) != -1){
                CommonService.showAlert({message:"密码不能是顺序递增或者递减！"});
                return false;
            }
            // 判断是否是移动电话的一部分
            if(mobile_tel.indexOf(pwd) != -1){
                CommonService.showAlert({message:"密码不能是移动电话的一部分！"});
                return false;
            }
            // 弱密库
            var weakPwdArray = ['111111','222222','333333','444444','555555','666666','777777','888888','999999','101010','202020','303030',
                '404040','505050','606060','707070','808080','909090','101010','121212','131313','141414','151515','161616',
                '171717','181818','191919','202020','212121','232323','242424','252525','262626','272727','282828','292929',
                '303030','313131','323232','343434','353535','363636','373737','383838','393939','404040','414141','424242',
                '434343','454545','464646','474747','484848','494949','505050','515151','525252','535353','545454','565656',
                '575757','585858','595959','606060','616161','626262','636363','646464','656565','676767','686868','696969',
                '707070','717171','727272','737373','747474','757575','767676','787878','797979','808080','818181','828282',
                '838383','848484','858585','868686','878787','898989','909090','919191','929292','939393','949494','959595',
                '969696','979797','989898','123412','234523','345634','456745','567856','678967','123012','123123','234234',
                '345345','456456','567567','678678','789789','112233','111222','123412','123443','234567','123456','876543',
                '111122','222233','333344','444455','555566','666677','777788','888899','999900','111111','111122','111133',
                '111144','111155','111166','111177','111188','111199','111100'];
            if(weakPwdArray.indexOf(pwd) != -1){
                CommonService.showAlert({message:"请勿输入简单组合的密码！"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$state','$ionicLoading','LocalCacheService','CommonService','WebService'];
    return ctrl;
});