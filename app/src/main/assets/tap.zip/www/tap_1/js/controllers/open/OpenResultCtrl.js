define(function () {
    'use strict';

    function ctrl($scope,$state,$stateParams,$ionicPopup,LocalCacheService,WebService) {

        var par = $scope.param = {};

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.user = LocalCacheService.getOpenUser();
            par.open_status = $stateParams["open_status"];
            console.log(par.open_status);
            if(par.open_status == 1) {

                init();
            }

            WebService.saveUserInfo();


        });

        function init(){
            WebService.openActChannelInfo().then(
                function(data){
                    //有活动
                    if(data && data.paper_id) {
                        $ionicPopup.confirm({
                            cssClass: 'popup-head-hide',
                            template: "您已完成开户。现在小财迷正举办“理财增值100”送大礼活动，体验即送100元红包。诚邀您参加活动！",
                            okText:"立即参加",
                            cancelText:"不参加"
                        }).then(function(res) {
                            if(res) {
                                var homeSubs = LocalCacheService.get("IndexCtrl_homeSubs");
                                $state.go('promo-ue-reward', {id : homeSubs[0].channel_id});
                            }
                        });
                    }
                }
            );

            WebService.wtAd("xcm_open_result").then(function(data){
                par.ads = data;
            });
        }
    }

    ctrl.$inject = ['$scope','$state','$stateParams','$ionicPopup','LocalCacheService','WebService'];
    return ctrl;
});