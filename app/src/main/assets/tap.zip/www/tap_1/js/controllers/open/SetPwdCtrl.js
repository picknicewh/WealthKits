define(function () {
    'use strict';

    function ctrl($scope,$state,$ionicLoading,CommonService,WebService) {
        var par = $scope.param = {};
        var idCardNo,mobileNo;

        $scope.$on('$ionicView.beforeEnter', function() {
            par.switch_abc=false;
            par.switch_fund=false;
            init();
        });

        function init(){
            WebService.getCurrentOpenUser().then(
                function(data){
                    idCardNo = data.id_no;
                    mobileNo = data.mobile_tel;
                }, function(){
                    $state.go("open-msgVerify");
                }
            );
        }

        $scope.setPwd = function(){
            if(checkBeforeSubmit()){
                $ionicLoading.show();
                var trade_pwd = par.trade_pwd;
                var fund_pwd = trade_pwd;
                if(par.switch_fund){
                    fund_pwd = par.fund_pwd;
                }
                var params = {password:trade_pwd,fund_password:fund_pwd,source:CommonService.getSource()};
                WebService.setPwd(params).then(
                    function(data){
                        $ionicLoading.hide();
                        $state.go('open-bindOpenDeposit',{b:1});
                    }
                );
            }
        };

        function checkBeforeSubmit(){
            //交易密码校验
            if(!checkPwd(par.trade_pwd,par.trade_pwd_again,"交易")){
                par.trade_pwd = par.trade_pwd_again = '';
                return false;
            }
            //资金密码校验
            if(par.switch_fund){
                if(!checkPwd(par.fund_pwd,par.fund_pwd_again,"资金")){
                    par.fund_pwd = par.fund_pwd_again = '';
                    return false;
                }
            }
            return true;
        }

        function checkPwd(pass1,pass2,info){
            if(CommonService.isStrEmpty(pass1) || pass1.length != 6){
                CommonService.showAlert({message:"请输入6位数字"+info+"密码，请重新输入!"});
                return false;
            }
            if(!validatePassword(pass1,idCardNo,mobileNo)){
                return false;
            }
            if(CommonService.isStrEmpty(pass1) || CommonService.isStrEmpty(pass2) || pass1 != pass2){
                CommonService.showAlert({message:info+"密码与第一次不符，请重新输入!"});
                return false;
            }
            return true;
        }

        /**
         * 验证密码 6位数字
         */
        function validatePassword(password,idCardNo,mobileNo){
            var regex =  "^[0-9]{6}$";
            if(!CommonService.checkRegex(regex,password) || password.length != 6){
                CommonService.showAlert({message:"请输入6位数字密码"});
                return false;
            }
            /**
             * 增加弱密校验
             * 1、出生日期的一部分
             * 2、证件号码的一部分
             * 3、某一字符出现的概率不能占总长度的一半以上
             * 4、顺序递增或者递减
             * 5、弱密表的控制值
             * 6、移动电话的一部分
             * 7、固定电话的一部分
             */
            // 判断是不是出生日期的一部分
            if(password == idCardNo.substring(6,12) || password == idCardNo.substring(8,14)){
                CommonService.showAlert({message:"密码不能是出生日期的一部分！"});
                return false;
            }
            // 判断是不是证件号码的一部分
            if(idCardNo.indexOf(password) != -1){
                CommonService.showAlert({message:"密码不能是证件号码的一部分！"});
                return false;
            }
            // 判断某一字符出现的次数
            for(var i = 0;i < password.length;i++){
                var oneChar = password.charAt(i),
                    count = 0;
                for(var j = 0;j < password.length;j++){
                    if(oneChar == password.charAt(j)){
                        count++;
                    }
                }
                if(count >= 3){
                    CommonService.showAlert({message:"密码中&nbsp;"+oneChar+"&nbsp;出现的次数超过了三次！"});
                    return false;
                }
            }
            // 判断顺序递增或者递减
            var orderArray = ['012345','123456','234567','345678','456789','987654','876543','765432','654321','543210'];
            if(orderArray.indexOf(password) != -1){
                CommonService.showAlert({message:"密码不能是顺序递增或者递减！"});
                return false;
            }
            // 判断是否是移动电话的一部分
            if(mobileNo.indexOf(password) != -1){
                CommonService.showAlert({message:"密码不能是移动电话的一部分！"});
                return false;
            }
            // 弱密库
            var weakPwdArray = ['111111','222222','333333','444444','555555','666666','777777','888888','999999','101010','202020','303030',
                '404040','505050','606060','707070','808080','909090','101010','121212','131313','141414','151515','161616',
                '171717','181818','191919','202020','212121','232323','242424','252525','262626','272727','282828','292929',
                '303030','313131','323232','343434','353535','363636','373737','383838','393939','404040','414141','424242',
                '434343','454545','464646','474747','484848','494949','505050','515151','525252','535353','545454','565656',
                '575757','585858','595959','606060','616161','626262','636363','646464','656565','676767','686868','696969',
                '707070','717171','727272','737373','747474','757575','767676','787878','797979','808080','818181','828282',
                '838383','848484','858585','868686','878787','898989','909090','919191','929292','939393','949494','959595',
                '969696','979797','989898','123412','234523','345634','456745','567856','678967','123012','123123','234234',
                '345345','456456','567567','678678','789789','112233','111222','123412','123443','234567','123456','876543',
                '111122','222233','333344','444455','555566','666677','777788','888899','999900','111111','111122','111133',
                '111144','111155','111166','111177','111188','111199','111100'];
            if(weakPwdArray.indexOf(password) != -1){
                CommonService.showAlert({message:"请勿输入简单组合的密码！"});
                return false;
            }
            return true;
        }
    }

    ctrl.$inject = ['$scope','$state','$ionicLoading','CommonService','WebService'];
    return ctrl;
});