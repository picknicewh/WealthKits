//use this js must import zepto.js
/***********************/
/****Request Package****/
/***********************/

// 请求 open api
function shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, onDone, onFail) {
    var url = 'http://smbclient.openapi/'.concat(uri);
    var xmlRequest = $.ajax({
        type: methodType,
        url: url,
        cache:false,
        data: params,
        dataType: dataType,
        beforeSend: function (xhr, settings) {
            // execute if the client is an android mobile client
            if (!window.urloauth) {
                return;
            }
            var android_createOauthData = function (json) {
                var result = {};
                switch (json.type.toLowerCase()) {
                    case 'post':
                        result = urloauth.createPostData(json.url, json.data);
                        break;

                    case 'get':
                        result = urloauth.createGetData(json.url, json.data);
                        break;
                }
                return shumi_sdk_androidToObject(result);
            };
            var p = android_createOauthData(settings);
            if (p != undefined && p.sendComfirmed == false) {
                return;
            }
            settings.url = p.url;
            settings.data = p.data;
        },
        success: function (data, status, xhr) {
            onDone(data);
        },
        error: function (xhr, errorType, error) {
            var failedCode, failedReason;
            if (!navigator.onLine) {
                failedCode = "-10000";
                failedReason = "网络连接中断,请检查你的网络连接";
            }
            try {
                var responseObj = eval("(" + xhr.responseText + ")");
                failedCode = responseObj.Code;
                failedReason = responseObj.Message;
            } catch (e) {
                failedCode = '-10001';
                failedReason = '服务器出现异常,暂时无法访问';
            }
            onFail(failedCode, failedReason);
        }
    });
    return xmlRequest;
}

// 请求 financial data
function shumi_sdk_sendHttpRequestToFinancialData(uri, methodType, dataType, params, onDone, onFail) {
    var url = 'http://smbclient.financialdata/'.concat(uri);
    var xmlRequest = $.ajax({
        type: methodType,
        url: url,
        cache:false,
        data: params,
        dataType: dataType,
        beforeSend: function (xhr, settings) {
            // execute if the client is an android mobile client
            if (!window.urloauth) {
                return;
            }
            var android_createOauthData = function (json) {
                var result = urloauth.createFinancialData(json.type, json.url, json.data);
                return shumi_sdk_androidToObject(result);
            };
            var p = android_createOauthData(settings);
            if (p != undefined && p.sendComfirmed == false) {
                return;
            }
            settings.url = p.url;
            settings.data = p.data;
        },
        success: function (data, status, xhr) {
            onDone(data);
        },
        error: function (xhr, errorType, error) {
            var failedCode, failedReason;
            if (!navigator.onLine) {
                failedCode = "-10000";
                failedReason = "网络连接中断,请检查你的网络连接";
            }
            try {
                var responseObj = eval("(" + xhr.responseText + ")");
                failedCode = responseObj.Code;
                failedReason = responseObj.Message;
            } catch (e) {
                failedCode = '-10001';
                failedReason = '服务器出现异常,暂时无法访问';
            }
            onFail(failedCode, failedReason);
        }
    });
    return xmlRequest;
}


/*request for oauthApi*/
function shumi_sdk_sendHttpRequestToOauthApi(uri, methodType, dataType, params, onDone, onFail) {
    var url = 'http://smbclient.oauth/'.concat(uri);
    var request = $.when($.ajax({
            url: url,
            cache:false,
            type: methodType,
            'dataType': dataType,
            data: params,
            beforeSend: function (e, xhr) {
                // execute if the client is an android mobile client
                if (!window.urloauth) {
                    return;
                }
                var p = createOauthData(methodType, xhr);
                if (p != undefined && p.sendComfirmed == false) {
                    return;
                }
                xhr.url = p.url;
                xhr.data = p.data;
            }
        }))
        .done(onDone)
        .fail(function (jqXHR, textStatus, errorThrown) {
            var failedCode;
            var failedReason;
            if (!navigator.onLine) {
                failedCode = '-10000';
                failedReason = '网络连接中断,请检查你的网络连接';
            } else {
                console.error(methodType + " " + url + " failed.\n" +
                    "Status: " + textStatus + "\n" +
                    "Response: " + jqXHR.getAllResponseHeaders() + "\n\n" +
                    jqXHR.responseText + "\n" +
                    "errorThrown: " + errorThrown);
                try {
                    var errorResponse = eval("(" + jqXHR.responseText + ")");
                    failedCode = errorResponse.Code;
                    failedReason = errorResponse.Message;
                } catch (e) {
                    failedCode = '-10001';
                    failedReason = '网络或服务器出现异常,暂时无法访问';
                }
            }
            onFail(failedCode, failedReason);
        });
    return request;
}

/*
 *请求 client
 */
function shumi_sdk_requestDataFromLocalClient(uri, methodType, params, onDone, onFail) {
    if (!window.smbproxy) {
        // execute if the client is an iphone mobile client
        var url = 'http://smbclient.client/'.concat(uri);
        $.ajax({
            type: methodType,
            url: url,
            cache:false,
            data: params,
            success: function (data, status, xhr) {
                onDone(data);
            },
            error: function (xhr, errorType, error) {
                var failedCode, failedReason;
                try {
                    var responseObj = eval("(" + xhr.responseText + ")");
                    failedCode = responseObj.Code;
                    failedReason = responseObj.Message;
                } catch (e) {
                    failedCode = '-10001';
                    failedReason = '服务器出现异常,暂时无法访问';
                }
                onFail(failedCode, failedReason);
            }
        });
    } else {
        // execute if the client is an android mobile client
        var android_requestNativeData = function (url, parameter) {
            var obj;
            try {
                var result = smbproxy.smbClient(url, JSON.stringify(parameter));
                obj = shumi_sdk_androidToObject(result);
            } catch (e) {
                //do nothing
            }
            return obj;
        }
        var nativeData = android_requestNativeData(uri, params);
        try {
            if (nativeData.successed == true) {
                onDone(nativeData);
            } else {
                onFail();
            }
        } catch (e) {
            onFail();
        }
    }
}
/*
 * 向客户端发送事件
 */

function shumi_sdk_sendDataToLocalClientOnEvent(uri, params, complete) {
    if (!window.smbproxy) {
        // execute if the client is an iphone mobile client
        var url = 'http://smbclient.event/'.concat(uri);
        $.ajax({
            type: "get",
            url: url,
            cache:false,
            data: params,
            complete: function (xhr, status) {
               if(complete != undefined){
                    complete();
               }
            }
        });
    } else {
        // execute if the client is an android mobile client
        try {
            smbproxy.smbEvent(uri, JSON.stringify(params));
        } catch (e) {
            //do nothing
        } finally {
            if(complete != undefined){
                complete();
            }
        }
    }
}

// 向客户端发送通知
function shumi_sdk_sendNotificationToClient(uri, params, complete) {
    if (!window.smbproxy) {
        // execute if the client is an iphone mobile client
        var url = 'http://smbclient.notification/'.concat(uri);
        $.ajax({
            type: "get",
            url: url,
            cache:false,
            data: params,
            complete: function (xhr, status) {
                complete();
            }
        });
    } else {
        // execute if the client is an android mobile client
        try {
            smbproxy.smbNotification(uri, JSON.stringify(params));
        } catch (e) {
            //do nothing
        } finally {
            complete();
        }
    }
}
// json string to object
function shumi_sdk_toObject(json) {
    var obj = undefined;
    var typeName = typeof json;
    // 判断对象类型
    // 对象
    if (typeName == "object") {
        obj = json;
        // 字符串
    } else if (typeName == "string") {
        try {
            obj = eval("(" + json + ")");
        }
        catch (e) {
            console.warn(e.message);
        }
    }
    return obj;
}

function shumi_sdk_androidToObject(json) {
    try {
        return eval("(" + json + ")");
    } catch (e) {
        return shumi_sdk_toObject(json);
    }
}

// 显示Loading UI
function shumi_sdk_startLoading(message) {
    var loadingDiv = $("#shumi_sdk_loading");
    if (!loadingDiv.get(0)) {
        $(document.body).append("<div id='shumi_sdk_loading'></div>");
        loadingDiv = $("#shumi_sdk_loading");
        loadingDiv.append("<div class='tip-pop-box'><div class='tip-loading'><span class='icon'></span></div><div class='tip-text-desc'><p id='tip_message' class='t'></p><p class='load'></p></div></div><div id='tip-body-bg'></div>");
    }
    $("#tip_message").html(message);
    loadingDiv.show();
    $('#tip-body-bg').show();
    $('.tip-pop-box').show();
    showTipPop();
    function showTipPop() {
        var winW = $(window);//current window
        var tipW = $('.tip-pop-box');//pop window
        var body_bg = $('#tip-body-bg');
        var lrqW = winW.width();
        var lrqH = winW.height();
        var lrqL = winW.scrollLeft();
        var lrqT = winW.scrollTop();
        var curW = tipW.width();
        var curH = tipW.height();
        var left = lrqL + (lrqW - curW) / 2;
        var top = lrqT + (lrqH - curH) / 2;
        body_bg.css({"left": 0, "top": lrqT});
        tipW.css({"left": left, "top": top});
    }

    $(window).resize(function () {
        showTipPop();
    });
    $(document.body).css("overflow", "hidden");
}

// 隐藏Loading UI
function shumi_sdk_endLoading() {
    var loadingDiv = $("#shumi_sdk_loading");
    if (loadingDiv.get(0)) {
        loadingDiv.hide();
        $(document.body).css("overflow", "");
    }
}

// 保存数据至localStorage
function shumi_sdk_saveToLocalStorage(key, value) {
    localStorage.setItem(key, value);
}

// 从localStorage获取保存数据
function shumi_sdk_getDataFromLocalStorage(key) {
    return localStorage.getItem(key);
}

// 保存数据至sessionStorage
function shumi_sdk_saveToSessionStorage(key, value) {
    sessionStorage.setItem(key, value);
}

// 从sessionStorage获取保存数据
function shumi_sdk_getDataFromSessionStorage(key) {
    return sessionStorage.getItem(key);
}

// 截取最后4位显示(其余显示*号)
function shumi_sdk_showLost4Num(num) {
    var newNumber = "***";
    if (num.length >= 4) {
        newNumber = newNumber + num.substr(num.length - 4, 4);
    } else {
        newNumber = newNumber + num;
    }
    return newNumber;
}

//截取手机号前3位和后4位(其余显示*号)
function shumi_sdk_showMobileCiphertext(num){
    var newNumber = "***";
    if(num != undefined){
        newNumber = num.substr(0,3) + newNumber + num.substr(num.length - 4, 4);
    }
    return  newNumber;
}

//截取身份证中的出生日期
function shumi_sdk_IsGetPasswordFromIDcard(IDcard, tradePassword){
    if(IDcard && tradePassword == IDcard.substr(6,8)){
        return true;
    }
    else if(IDcard && tradePassword == IDcard.substr(8,6)){
        return  true;
    }
    return  false;
}

//判断交易密码是否使用相同的字符
function shumi_sdk_isIdenticalCharactor(password){
    var array = password.split("");
    for(var i in array){
        if(array[i] != array[0])
            return false;
    }
    return true;
}

// 检测对象是否是空对象(不包含任何可读属性) -> 方法既检测对象本身的属性，也检测从原型继承的属性(因此没有使hasOwnProperty)
function shumi_sdk_isEmpty(obj) {
    for (var name in obj) {
        return false;
    }
    return true;
};

// 检测对象是否是空对象(不包含任何可读属性) -> 方法只既检测对象本身的属性，不检测从原型继承的属性
function shumi_sdk_isOwnEmpty(obj) {
    for (var name in obj) {
        if (obj.hasOwnProperty(name)) {
            return false;
        }
    }
    return true;
};

// 截取支行多余信息
function shumi_sdk_clipBankBranchName(bankBranchName) {
    var regExp = /中国农业银行股份有限公司|中国农业银行|招商银行股份有限公司|招商银行股份有|招商银行|平安银行股份有限公司|平安银行|中国光大银行股份有限公司|中国光大银行/g;
    return bankBranchName.replace(regExp, "");
}

// 格式化金额 -> 将数字转换成逗号分隔的样式,保留两位小数s:value,n:小数位数
function shumi_sdk_foMoney(s, n) {
    n = n > 0 && n <= 20 ? n : 2;
    s = parseFloat((s + "").replace(/[^\d\.-]/g, "")).toFixed(n) + "";
    var l = s.split(".")[0].split("").reverse();
    var r = s.split(".")[1];
    var t = "";
    for (i = 0; i < l.length; i++) {
        t += l[i] + ((i + 1) % 3 == 0 && (i + 1) != l.length ? "," : "");
    }
    return t.split("").reverse().join("") + "." + r;
}
// 还原金额
function shumi_sdk_reMoney(s) {
    return parseFloat(s.replace(/[^\d\.-]/g, ""));
}

/*验证身份证件*/
function shumi_sdk_validateCardNo(card) {
    if (card === '') {
        alert('请输入身份证号，身份证号不能为空！');
        return false;
    }
    //身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
    var reg = /(^\d{15}$)|(^\d{17}(\d|X)$)/;
    if (reg.test(card) === false) {
        alert('您输入的身份证号不正确，如果含有字母X，请确认X字母为大写');
        return false;
    }
    return true;
}

/*验证真实姓名*/
function shumi_sdk_validateRealName(name) {
    if (name === '') {
        alert('请输入真实姓名，真实姓名不能为空！');
        return false;
    }
    try{
    //真实姓名只能为中文
    var reg = /^[\u0391-\uFFE5]+$/;
    if (reg.test(name) === false) {
        alert('您输入的真实姓名不正确，请确认为中文');
        return false;
    }
    }catch (err){
        alert(err);
    }
    return true;
}

// 验证手机号码格式
function shumi_sdk_validateMobile(mobile) {
    if (mobile.length == 0) {
        alert('请输入手机号码！');
        return false;
    }
    if (mobile.length != 11) {
        alert('请输入有效的手机号码！');
        return false;
    }
    var myreg = /^(((1[0-9][0-9]{1})|159|153)+\d{8})$/;
    if (!myreg.test(mobile)) {
        alert('请输入有效的手机号码！');
        return false;
    }
    return true;
}

// 验证密码
function shumi_sdk_validateTradePass(tradePass){
	var reg = /^([0-9a-zA-Z~!@#$%^&*()-_=+\[\]{}\|;:'".,<>\?\/]{6,8})$/;
	return reg.test(tradePass);
}

// 修正数字输入
function shumi_sdk_reviseNumber(input){
//	input.value = input.value.replace(/[^0-9]/g,"");
}

// 修正数字输入
function shumi_sdk_reviseDecimal(input){
//	input.type = "text";
//	var reg = /(([1-9]\d*)|0)(\.\d{0,2})?/;
//	var newValue = reg.exec(input.value);
//	if(newValue){
//		input.value = newValue[0];
//	}else{
//		input.value = "";
//	}
}

// 修正身份证号码输入
function shumi_sdk_reviseIdCard(input){
	// input.value = input.value.replace(/[^0-9X]/g,"");
	// input.value = input.value.replace(/x/g,"X");
}

// 修正中文输入
function shumi_sdk_reviseChinese(input){
	// input.value = input.value.replace(/[^\u4E00-\u9FA5]/g,"");
}

// 银行卡号Luhm校验
function shumi_sdk_bankCardLuhmCheck(bankno) {
    if (bankno.length == 0) {
        alert("请输入银行卡号!");
        return false;
    }
    var lastNum = bankno.substr(bankno.length - 1, 1);//取出最后一位（与luhm进行比较）
    var first15Num = bankno.substr(0, bankno.length - 1);//前15或18位
    var newArr = new Array();
    for (var i = first15Num.length - 1; i > -1; i--) {    //前15或18位倒序存进数组
        newArr.push(first15Num.substr(i, 1));
    }
    var arrJiShu = new Array();  //奇数位*2的积 <9
    var arrJiShu2 = new Array(); //奇数位*2的积 >9
    var arrOuShu = new Array();  //偶数位数组
    for (var j = 0; j < newArr.length; j++) {
        if ((j + 1) % 2 == 1) {//奇数位
            if (parseInt(newArr[j]) * 2 < 9)
                arrJiShu.push(parseInt(newArr[j]) * 2);
            else
                arrJiShu2.push(parseInt(newArr[j]) * 2);
        } else {
            //偶数位
            arrOuShu.push(newArr[j]);
        }
    }
    var jishu_child1 = new Array();//奇数位*2 >9 的分割之后的数组个位数
    var jishu_child2 = new Array();//奇数位*2 >9 的分割之后的数组十位数
    for (var h = 0; h < arrJiShu2.length; h++) {
        jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
        jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
    }
    var sumJiShu = 0; //奇数位*2 < 9 的数组之和
    var sumOuShu = 0; //偶数位数组之和
    var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
    var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
    var sumTotal = 0;
    for (var m = 0; m < arrJiShu.length; m++) {
        sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
    }
    for (var n = 0; n < arrOuShu.length; n++) {
        sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
    }
    for (var p = 0; p < jishu_child1.length; p++) {
        sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
        sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
    }
    //计算总和
    sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);
    //计算Luhm值
    var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
    var luhm = 10 - k;
    if (lastNum == luhm) {
        return true;
    } else {
        alert("银行卡格式有误，请输入有效的银行卡号!");
        return false;
    }
}

/*
 * OpenApi
 */

// 获取基金风险等级
function shumi_sdk_getfundRiskLevelFromMark(riskMark) {
    var riskLevel = 'H';
    switch (riskMark) {
        case 0:
            riskLevel = 'L';
            break;
        case 1:
            riskLevel = 'M';
            break;
        case 2:
            riskLevel = 'H';
            break;
        default:
            riskLevel = 'H';
    }
    return riskLevel;
}

// 获取用户风险承受能力等级
function shumi_sdk_getUserRiskabilityLevelFromMark(abilityMark) {
    var abilityLevel = 'H';
    switch (abilityMark) {
        case '1':
            abilityLevel = 'L';
            break;
        case '2':
            abilityLevel = 'M';
            break;
        case '3':
            abilityLevel = 'H';
            break;
        default:
            abilityLevel = 'H';
    }
    return abilityLevel;
}

// 获取风险等级转中文
function shumi_sdk_getFundRiskLevelFromMarkToChinese(risklevel) {
    var abilityLevel = '';
    switch (risklevel) {
        case 0:
            abilityLevel = '低风险';
            break;
        case 1:
            abilityLevel = '中风险';
            break;
        case 2:
            abilityLevel = '高风险';
            break;
        default:
            abilityLevel = '高风险';
    }
    return abilityLevel;
}

// 显示禁用Button效果
function shumi_sdk_disableButton(button) {
    button.removeClass("shumi-btn-able");
    button.addClass("shumi-btn-disable");
    var maskID = "mask_id_" + button.attr("id");
    var mask = $("<div id=" + maskID + "></div>");
    mask.css({
        cursor: 'wait',
        position: 'absolute',
        zIndex: '2147483584',
        top: button.offset().top + 'px',
        left: button.offset().left + 'px',
        width: button.width() + 'px',
        height: button.height() + 'px',
        backgroundColor: 'transparent'
    });
    $(document.body).append(mask);
}

// 不显示禁用Button效果
function shumi_sdk_resumeButton(button) {
    button.removeClass("shumi-btn-disable");
    button.addClass("shumi-btn-able");
    var maskID = "mask_id_" + button.attr("id");
    $("#" + maskID).remove();
}

// 定时移除禁用Button效果
function shumi_sdk_resumeButton_later(button) {
    try {
        var time = 0;
        var ID = setInterval(function () {
            if (time == 1) {
                shumi_sdk_resumeButton(button);
                clearInterval(ID);
            }
            time += 1;
        }, 1000);
    } catch (e) {
        alert(e);
    }
}

// 绑定web 后退 和 退出 事件
function shumi_sdk_bindingBackAndQuitInteraction() {
    $("#back").off().on("click", function () {
        shumi_sdk_sendWebGoBackEvent();
    });
    $("#quit").off().on("click", function () {
        shumi_sdk_sendQuitPlugEvent();
    });
}

// 加载指定URL
function shumi_sdk_loadURL(url) {
    location.href = url;
}

/**************************************/
//HTTP Interaction
//OPENAPI
/*向指定手机发送注册验证码*/
/*send verification code to user*/
/*if this phone hasn't been binded,user will receive a verification code*/
function shumi_sdk_sendVerificationCode(phoneNumber, successed, failed) {
    var uri = "trade_common.sendsms";
    var methodType = "get";
    var dataType = "json";
    var params = { mobile: phoneNumber };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

//根据交易密码与验证码修改手机号
function shumi_sdk_changeSDKIPhoneNumber(identityno, tradePassword,phoneNumber,verifyCode,successed,failed){
    var uri = "trade_account.changebindmobile";
    var methodType = "get";
    var dataType = "json";
    var params = {
        identityno: identityno,
        tradepassword:tradePassword,
        mobile:phoneNumber,
        code:verifyCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*检测手机号码是否被绑定登录*/
/*check phone whether binded*/
function shumi_sdk_checkPhoneNumberIsLoginPhoneNumber(phoneNumber, successed, failed) {
    var uri = "trade_account.hasloginmobile";
    var methodType = "get";
    var dataType = "json";
    var params = { mobile: phoneNumber };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*验证输入的手机验证码是否匹配*/
function shumi_sdk_checkMobileVerificationCode(mobile, verificationCode, successed, failed) {
    var uri = "trade_common.verifysms";
    var methodType = "get";
    var dataType = "json";
    var params = {
        mobile: mobile,
        code: verificationCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取省份列表*/
function shumi_sdk_getProvinceList(successed, failed) {
    var uri = "trade_common.getprovinces";
    var methodType = "get";
    var dataType = "json";
    var params = undefined;
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取城市列表*/
function shumi_sdk_getCityList(provinceCode, successed, failed) {
    var uri = "trade_common.getcities";
    var methodType = "get";
    var dataType = "json";
    var params = {
        provinceCode: provinceCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}


/*获取全部可以绑定的银行卡列表*/
function shumi_sdk_getBindableBankList(channel, successed, failed) {
    var uri = "trade_payment.getallavailablebankcardsbycapitalmodes";
    var methodType = "get";
    var dataType = "json";
    var params = {
        channel: channel
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取用户可以绑定的银行卡列表，可根据第三方支付过滤*/
function shumi_sdk_getUserBindableBankList(channel, successed, failed) {
    var uri = "trade_payment.getavailablebankcardsbycapitalmodes";
    var methodType = "get";
    var dataType = "json";
    var params = {
        channel: channel
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取用户已绑定的银行卡*/
function shumi_sdk_getUserBindedBankList(successed, failed) {
    var uri = "trade_payment.getbindbankcards";
    var methodType = "get";
    var dataType = "json";
    var params = undefined;
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取交易基金详细信息*/
function shumi_sdk_getFundDetailInfo(fundCode, successed, failed) {
    var uri = "trade_common.getavailablefund";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取用户开户状态*/
function shumi_sdk_checkUserHasOpenedAccount(IDNumber, successed, failed) {
    var uri = "trade_account.checkaccountstatuswithcertificate";
    var methodType = "get";
    var dataType = "json";
    var params = {
        certificateNumber: IDNumber,
        certificateType: 0
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取用户是否已经授权登录*/
function shumi_sdk_hasAuthorized(successed, failed) {
    var uri = "userLoginMark";
    var methodType = "get";
    var params = undefined;
    shumi_sdk_requestDataFromLocalClient(uri, methodType, params, successed, failed);
}

/*获取第三方传入数据*/
function shumi_sdk_getDateFromThirdPart(success, fail) {
    var uri = "providedUserInfo";
    var methodType = "get";
    var params = undefined;
    shumi_sdk_requestDataFromLocalClient(uri, methodType, params, success, fail);
}

/*授权登录*/
function shumi_sdk_startAuthorized(IDNumber, password, successed, failed) {
    //var uri = "trade_account.authorize";
    //var uri = "Quick-Oauth.aspx";
    try{
        var uri =  "trade_account.authorizebyidno";
        var methodType = "get";
        var dataType = "json";
        var params = {
            identityNo: IDNumber,
            tradePassword: password
        };
        shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
    }catch(err){
        alert(err);
    }

}

/*获取指定银行支行*/
function shumi_sdk_getBankBranchList(bankSerial, provinceCode, cityCode, successed, failed) {
    var uri = "trade_payment.getbanksubbranchs";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*开户（内部含有网站用户注册）通用*/
function shumi_sdk_registerShuMiUserAndOpenFundAccount_Universal(realName, identityNo, identityType, mobile, email, bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankmobile, bindWay, capitalMode, successed, failed) {
    var uri = "trade_account.register";
    var methodType = "get";
    var dataType = "json";
    var params = {
        realName: realName,
        identityNo: identityNo,
        identityType: identityType,
        mobile: mobile,
        email: email,
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode,
        branchBankCode: branchBankCode,
        bankmobile: bankmobile,
        bindWay: bindWay,
        capitalMode: capitalMode,
        channel: "2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*开户（内部含有网站用户注册，需要交易密码）*/
function shumi_sdk_registerShuMiUserAndOpenFundAccountWithPassword(realName, identityNo, identityType, mobile, email, bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankmobile, bindWay, capitalMode, tradePassword, successed, failed) {
    var uri = "trade_account.registerwithpassword";
    var methodType = "get";
    var dataType = "json";
    var params = {
        realName: realName,
        identityNo: identityNo,
        identityType: identityType,
        mobile: mobile,
        mail: email,
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode,
        branchBankCode: branchBankCode,
        bankmobile: bankmobile,
        bindWay: bindWay,
        capitalMode: capitalMode,
        tradePassword: tradePassword,
        channel: "2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*注册数米用户并开通基金账号(数米专用)*/
function shumi_sdk_registerShuMiUserAndOpenFundAccount(realName, identityNo, identityType, mobile, bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankmobile, bindWay, capitalMode, successed, failed) {
    var uri = "trade_account.createaccount";
    var methodType = "get";
    var dataType = "json";
    var params = {
        realName: realName,
        identityNo: identityNo,
        identityType: identityType,
        mobile: mobile,
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode,
        branchBankCode: branchBankCode,
        bankmobile: bankmobile,
        bindWay: bindWay,
        capitalMode: capitalMode,
        channel: "2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*开通基金账号*/
function shumi_sdk_openFundAccount(realName, identityNo, identityType, mobile, bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankmobile, bindWay, capitalMode, successed, failed) {
    var uri = "trade_account.accountsigning";
    var methodType = "get";
    var dataType = "json";
    var params = {
        realName: realName,
        identityNo: identityNo,
        identityType: identityType,
        mobile: mobile,
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode,
        branchBankCode: branchBankCode,
        bankmobile: bankmobile,
        bindWay: bindWay,
        capitalMode: capitalMode,
        channel: "2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*设置交易密码*/
function shumi_sdk_setTradePassWord(tradePassWord , successed , failed) {
    var uri = "trade_account.initializepassword";
    var methodType = "get";
    var dataType = "json";
    var params = {
        password: tradePassWord
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*查询银行卡签约结果*/
function shumi_sdk_queryBankSigning(userTokenKey, userTokenSecret, bankCard, successed, failed) {
    var uri = "trade_account.getsignresult";
    var methodType = "get";
    var dataType = "json";
    var params;
    if (userTokenKey && userTokenSecret) {
        params = {
            bankCard: bankCard,
            fund123_oauth_token: userTokenKey,
            fund123_oauth_secret: userTokenSecret
        };
    } else {
        params = {
            bankCard: bankCard
        };
    }

    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*查询银行卡签约结果->数米专用[成功自动绑定手机号码为登录方式]*/
function shumi_sdk_queryBankSigningAndBindMobile(userTokenKey, userTokenSecret, bankSerial, bankCard, capitalMode, successed, failed) {
    var uri = "trade_account.signingresults";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankSerial: bankSerial,
        bankCard: bankCard,
        capitalMode: capitalMode,
        fund123_oauth_token: userTokenKey,
        fund123_oauth_secret: userTokenSecret
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取用户信息*/
function shumi_sdk_getUserInfo(successed, failed) {
    var uri = "trade_account.getaccount";
    var methodType = "get";
    var dataType = "json";
    var params = undefined;
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取申购费用*/
function shumi_sdk_getShenGouFee(fundCode, shareType, amount, successed, failed) {
    var uri = "trade_common.getpurchasefare";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        amount: amount
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取认购费用*/
function shumi_sdk_getRenGouFee(fundCode, shareType, amount, successed, failed) {
    var uri = "trade_common.getsubscribefare";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        amount: amount
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取赎回费用*/
function shumi_sdk_getRedeemFee(fundCode, shareType, tradeAccount, shares, successed, failed) {
    var uri = "trade_common.getredeemfare";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        shares: shares
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

// 获取赎回到账时间
function shumi_sdk_getFundsArriveDateOfFundRedemption(fundCode,successed,failed){
    var uri = "FundRedeemAccountingDate.aspx";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode:fundCode
    };
    shumi_sdk_sendHttpRequestToFinancialData(uri, methodType, dataType, params, successed, failed);
}

/*获取单只可交易基金详细*/
function shumi_sdk_getTradableFundDetailInfo(fundCode, successed, failed) {
    var uri = "trade_common.getavailablefund";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

// 获取可转换基金
function shumi_sdk_getCanTransformToFunds(fundCode,shareType,tradeAccount,success,fail) {
    var uri = "trade_foundation.gettransformfund";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode:fundCode,
        shareType:shareType,
        tradeAccount:tradeAccount
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, success, fail);
}

/*提交申购申请*/
function shumi_sdk_shenGouFund(fundCode, shareType, tradeAccount, applySum, tradePassword, successed, failed) {
    var uri = "trade_foundation.purchasefunds";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*提交认购申请*/
function shumi_sdk_renGouFund(fundCode, shareType, tradeAccount, applySum, tradePassword, successed, failed) {
    var uri = "trade_foundation.subscribefund";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*提交基金转换申请*/
function shumi_sdk_transformFund(fundCode,shareType,tradeAccount,amount,targetFundCode,targetShareType,tradePassword,success,fail) {
    var uri = "trade_foundation.transformfund";
    var methodType = "post";
    var dataType = "json";
    var params = {
        fundCode:fundCode,
        shareType:shareType,
        tradeAccount:tradeAccount,
        shares:amount,
        targetFundCode:targetFundCode,
        targetShareType:targetShareType,
        tradePassword:tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, success, fail);
}

/*查询支付结果*/
function shumi_sdk_queryPayResult(applySerial, successed, failed) {
    var uri = "trade_foundation.getpayresult";
    var methodType = "get";
    var dataType = "json";
    var params = {
        applySerial: applySerial
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取银行预留手机号码*/
function shumi_sdk_getBankReservedMobile(bankCardNo, successed, failed) {
    var uri = "trade_payment.getverifymobilebybankcard";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankcard: bankCardNo
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*验证手机快捷验证的验证码*/
function shumi_sdk_verifyQuickVerification(verifyCode, bankCard, successed, failed) {
    var uri = "trade_payment.verifybankcard1";
    var methodType = "get";
    var dataType = "json";
    var params = {
        code: verifyCode,
        bankCard: bankCard
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*发送打款查询请求*/
function shumi_sdk_sendQueryPayMoney(capitalMode, bankSerial, bankCardNo, successed, failed) {
     var uri = "trade_payment.remittancequerybycapitalmodes";
     var methodType = "get";
     var dataType = "json";
     var params = {
         capitalMode: capitalMode,
         bankSerial: bankSerial,
         bankcard: bankCardNo
     };
     shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*验证输入金额*/
function shumi_sdk_verifyPayMoney(bankCardNo, inputMoney, successed, failed) {
    var uri = "trade_payment.verifybankcard";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankcard: bankCardNo,
        amount: inputMoney
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取快速赎回限制*/
function shumi_sdk_getQuickRedeemLimits(fundCode, successed, failed) {
    var uri = "trade_cash.getrapidwithdrawallimitv3";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode:fundCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*提交普通赎回申请*/
function shumi_sdk_PTRedeem(fundCode, shareType, applySum, tradeAccount, tradePassword, successed, failed) {
    var uri = "trade_foundation.redeemfunds";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*提交快速赎回申请*/
function shumi_sdk_KSRedeem(fundCode, shareType, applySum, tradeAccount, tradePassword, successed, failed) {
    var uri = "trade_foundation.rapidredeemfund";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*修改交易密码*/
function shumi_sdk_modifyTradePassWord(oldP, newP, successed, failed) {
    var uri = "trade_account.modifypassword";
    var methodType = "get";
    var dataType = "json";
    var params = {
        oldPassword: oldP,
        newPassword: newP
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*发送重置交易密码短信验证码*/
function shumi_sdk_sendVerifyCodeToRsetTradePassWord(IDcard, successed, failed) {
    var uri = "trade_common.forgetpassword";
    var methodType = "get";
    var dataType = "json";
    var params = {
        card: IDcard
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*重置交易密码*/
function shumi_sdk_verifyRestTradePassWordVerifyCode(verifyCode, IDcard, tradePassword, successed, failed) {
    var uri = "trade_account.resetpassword";
    var methodType = "get";
    var dataType = "json";
    var params = {
        code: verifyCode,
        card: IDcard,
        newPassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*撤单*/
function shumi_sdk_cancellation(applySerial, tradeAccount, tradePassWord, successed, failed) {
    var uri = "trade_foundation.undoapply";
    var methodType = "get";
    var dataType = "json";
    var params = {
        tradeAccount: tradeAccount,
        applyserial: applySerial,
        tradePassword: tradePassWord
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*新增银行卡[仅支持易宝和汇付渠道]*/
function shumi_sdk_addNewBankCard(bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankmobile, bindWay, capitalMode, successed, failed) {
    var uri = "trade_account.addaccount";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: provinceCode,
        cityCode: cityCode,
        branchBankCode: branchBankCode,
        bankmobile: bankmobile,
        bindWay: bindWay,
        capitalMode: capitalMode,
        channel: "2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

// 新增银行卡[银联chinaPay]
function shumi_sdk_addNewBankCard_ChinaPay(bankCard, bankSerial, bindWay, successed, failed) {
    var uri = "trade_account.addaccountbychinapay";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankCard: bankCard,
        bankSerial: bankSerial,
        provinceCode: "",
        cityCode: "",
        bankBranchCode: "",
        bindWay: bindWay
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

// 新增银行卡[联动优势]
function shumi_sdk_addNewBankCard_UM(bankCard, bankSerial, provinceCode, cityCode, branchBankCode, bankMobile, bindWay, successed, failed) {
    var uri = "trade_account.addaccountbyumpay";
    var methodType = "get";
    var dataType = "json";
    var params = {
        bankCard:bankCard,
        bankSerial:bankSerial,
        provinceCode:provinceCode,
        cityCode:cityCode,
        branchBankCode:branchBankCode,
        bankMobile: bankMobile,
        bindWay:bindWay,
        channel:"2"
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*解绑银行卡*/
function shumi_sdk_unbundlingBankCard(tradeAccount, tradePassWord, successed, failed) {
    var uri = "trade_payment.unsign";
    var methodType = "get";
    var dataType = "json";
    var params = {
        tradeAccount: tradeAccount,
        tradePassword: tradePassWord
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*设置分红方式*/
function shumi_sdk_setDividend(fundCode, shareType, tradeAccount, melonMethod, tradePassword, successed, failed) {
    var uri = "trade_foundation.setdividend";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        melonMethod: melonMethod,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*根据基金代码获取指定基金的持仓*/
function shumi_sdk_getSingleFundPositionsInfo(fundCode, successed, failed) {
    var uri = "trade_foundation.getfundsharesbycode";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

// 获取交易记录详细
function shumi_sdk_getTradeRecordContentByApplyNo(applySerial,success,fail) {
    var uri = "trade_foundation.getapplyrecord";
    var methodType = "get";
    var dataType = "json";
    var params = {
        applySerial:applySerial
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, success, fail);
}

/*现金宝持仓列表*/
function shumi_sdk_getTradeCashPositionList(successed, failed) {
    var uri = "trade_cash.getcashsharelistv3";
    var methodType = "get";
    var dataType = "json";
    var params = undefined;
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*现金宝充值限制*/
function shumi_sdk_tradeCashRechargeLimits(fundCode, shareType, successed, failed) {
    var uri = "trade_cash.getrechargelimit";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fund: fundCode,
        shareType: shareType
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*现金宝充值*/
function shumi_sdk_tradeCashRecharge(fundCode, shareType, tradeAccount, applySum, tradePassword, successed, failed) {
    var uri = "trade_cash.recharge";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*现金宝普通取现*/
function shumi_sdk_tradeCashNormalRedeem(fundCode, shareType, tradeAccount, applySum, tradePassword, successed, failed) {
    var uri = "trade_cash.withdrawals";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*现金宝快速取现[支持转账功能]*/
function shumi_sdk_tradeCashQuickRedeem(fundCode, shareType, tradeAccount, applySum, tradePassword, successed, failed) {
    var uri = "trade_cash.rapidwithdrawals";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode,
        shareType: shareType,
        tradeAccount: tradeAccount,
        applySum: applySum,
        tradePassword: tradePassword
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*延用风险调查问卷*/
function shumi_sdk_agreeRiskContinue(successed, failed){
    var uri = "trade_account.agreeriskcontinue";
    var methodType = "get";
    var dataType = "json";
    var params = undefined;
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}

/*获取申购确认时间*/
function shumi_sdk_confirmDateForPurchaseFund(fundCode, successed, failed){
    var uri = "trade_common.getpurchasedate";
    var methodType = "get";
    var dataType = "json";
    var params = {
        fundCode: fundCode
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}
                  
                  
/*获取普通赎回确认时间*/
function shumi_sdk_confirmDateForNormalRedeem(fundCode, successed, failed){
     var uri = "trade_common.getredeemdate";
     var methodType = "get";
     var dataType = "json";
     var params = {
         fundCode: fundCode
     };
     shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}
                  
/** For Android **/
// process oauth data by native
function createOauthData(methodType, xhr) {
    var result = {};
    switch (methodType.toLowerCase()) {
        case 'post':
            result = urloauth.createPostData(xhr.url, xhr.data);
            break;

        case 'get':
            result = urloauth.createGetData(xhr.url, xhr.data);
            break;
    }
    return shumi_sdk_toObject(result);
}


/*
 * Financial Data
 */

// 校验银行卡卡柄
function shumi_sdk_checkBankCardHandle(bankCardNo, successed, failed) {
        var uri = "BankCardValidation.aspx";
        var methodType = "get";
        var dataType = "json";
        var params = {
            bankcardno: bankCardNo
        };
        shumi_sdk_sendHttpRequestToFinancialData(uri, methodType, dataType, params, successed, failed);
}

/*
 * 事件
 */

// web后退事件
function shumi_sdk_sendWebGoBackEvent() {
    var uri = "webGoBack";
    var params = undefined;
    shumi_sdk_sendDataToLocalClientOnEvent(uri, params, undefined);
}

// 退出插件时间
function shumi_sdk_sendQuitPlugEvent() {
    var uri = "quitSDK";
    var params = undefined;
    shumi_sdk_sendDataToLocalClientOnEvent(uri, params, undefined);
}

/*
 * 通知
 */

// 调用chinaPay通知
function shumi_sdk_sendCallChinaPayPlugNotification(merchantId, merchantOrderId, merchantOrderTime, orderKey, sign, complete) {
    var uri = "callChinaPayPlug";
    var params = {
        sign: sign,
        orderKey: orderKey,
        merchantId: merchantId,
        merchantOrderId: merchantOrderId,
        merchantOrderTime: merchantOrderTime
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 添加银行卡成功通知
function shumi_sdk_sendAddBankCardSuccessNotification(bankName, bankCard, bankSerial, complete) {
    var uri = "addBankCardSuccess";
    var params = {
        bankName: bankName,
        bankCard: bankCard,
        bankSerial:bankSerial
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 授权成功通知
function shumi_sdk_sendUserAuthorizedSuccessNotification(realName, idNumber, tokenKey, tokenSecret, newAccount, complete) {
    var uri = "authorizeSuccess";
    var params = {
        realName: realName,
        idNumber: idNumber,
        tokenKey: tokenKey,
        tokenSecret: tokenSecret,
        newAccount: newAccount
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 开户成功通知
function shumi_sdk_sendOpenAccountSuccessNotification(tokenKey, tokenSecret, userName, realName, idNumber, bankName, bankCardNo, bankSerial, phoneNum, email, newAccount, complete) {
    var uri = "openAccountSuccess";
    var params = {
        tokenKey: tokenKey,
        tokenSecret: tokenSecret,
        userName: userName,
        realName: realName,
        idNumber: idNumber,
        bankName: bankName,
        bankCardNo: bankCardNo,
        bankSerial: bankSerial,
        phoneNum: phoneNum,
        email: email,
        newAccount: newAccount
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 申认购订单号成功回调
function shumi_sdk_sendApplySerialSuccessNotification(applySerial, complete){
    var uri = "paymentFundSuccess";
    var params = {
        applySerial: applySerial
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 申购成功通知
function shumi_sdk_sendPurchaseFundSuccessNotification(applySerial, fundCode, fundName, applySum, bankCardInfo, dateTime, complete) {
    var uri = "purchaseFundSuccess";
    var params = {
        fundCode: fundCode,
        fundName: fundName,
        applySum: applySum,
        dateTime: dateTime,
        applySerial: applySerial,
        bankCardInfo: bankCardInfo
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 认购成功通知
function shumi_sdk_sendSubscribeFundSuccessNotification(applySerial, fundCode, fundName, applySum, bankCardInfo, dateTime, complete) {
    var uri = "subscribeFundSuccess";
    var params = {
        fundCode: fundCode,
        fundName: fundName,
        applySum: applySum,
        dateTime: dateTime,
        applySerial: applySerial,
        bankCardInfo: bankCardInfo
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 普通赎回成功通知
function shumi_sdk_sendNormalRedeemFundSuccessNotification(applySerial, fundCode, fundName, applySum, bankCardInfo, dateTime, complete) {
    var uri = "normalRedeemFundSuccess";
    var params = {
        fundCode: fundCode,
        fundName: fundName,
        applySum: applySum,
        dateTime: dateTime,
        applySerial: applySerial,
        bankCardInfo: bankCardInfo
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 快速赎回成功通知
function shumi_sdk_sendQuickRedeemFundSuccessNotification(applySerial, fundCode, fundName, applySum, bankCardInfo, dateTime, complete) {
    var uri = "quickRedeemFundSuccess";
    var params = {
        fundCode: fundCode,
        fundName: fundName,
        applySum: applySum,
        dateTime: dateTime,
        applySerial: applySerial,
        bankCardInfo: bankCardInfo
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 撤单成功通知
function shumi_sdk_sendCancelOrderSuccessNotification(applySerial, fundCode, fundName, amount, shares, bankCardInfo, complete) {
    var uri = "cancelOrderSuccess";
    var params = {
        amount: amount,
        shares: shares,
        fundCode: fundCode,
        fundName: fundName,
        applySerial: applySerial,
        bankCardInfo: bankCardInfo
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

//修改手机号码成功通知
function shumi_sdk_changeMobileSuccessNotification(mobileNumber, complete){
    var uri = "changeMobileSuccess";
    var params = {
        mobileNumber:mobileNumber
    };
    shumi_sdk_sendNotificationToClient(uri, params, complete);
}

// 转换申请提交成功通知
function shumi_sdk_sendTransformFundSuccessNotification(complete) {
    var uri = "transformFundSuccess";
    var params = undefined;
    shumi_sdk_sendNotificationToClient(uri,params,complete);
}

/*发送问卷*/
function shumi_sdk_sendQuestionnaire(actionKey, successed, failed) {
    var uri = "trade_foundation.addactionuserquestion";
    var methodType = "get";
    var dataType = "json";
    var params = {
        isQuestioned : true,
		isShare : false,
		actionKey : actionKey
    };
    shumi_sdk_sendHttpRequestToOpenApi(uri, methodType, dataType, params, successed, failed);
}